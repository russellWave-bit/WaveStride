package com.breadwinner.wavestride

import android.Manifest
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Map
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import java.util.Calendar

@Composable
fun HomeScreen(onRecord: () -> Unit, onOpen: (Long) -> Unit, onMove: () -> Unit, onMaps: () -> Unit) {
    val runs = remember { Runs.list() }
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { Steps.snapshot { tick++ } }
    val today = remember(tick) { Steps.today() }
    val live by RunState.flow.collectAsState()
    val haveMaps = remember { Tiles.sizeBytes() > 0L }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            val st = remember(tick) { Cal.streak(runs) }
            Header("WaveStride", null) {
                Row(
                    Modifier.padding(end = 6.dp).clip(RoundedCornerShape(50)).background(C.card).border(2.dp, C.line, RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.LocalFireDepartment, null, tint = if (st > 0) C.accent else C.steel, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    T(if (st == 1) "1 day" else "$st days", 14, C.text, FontWeight.ExtraBold)
                }
            }
        }
        item { HomeRing(today, runs, onMove) }
        if (live.st != St.IDLE || live.countdown > 0) {
            item {
                Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp), onClick = onRecord) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(C.green))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            T(if (live.st == St.PAUSED) "Run paused" else "Run in progress", 15, C.text, FontWeight.Bold)
                            T(Fmt.km(live.distM) + " km · " + Fmt.dur(live.ms), 13, C.steel)
                        }
                        Icon(Icons.Filled.ChevronRight, null, tint = C.steel)
                    }
                }
            }
        }
        if (!VecMap.ready()) {
            item {
                Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp), onClick = onMaps) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Map, null, tint = C.steelLt)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            T("Get the sharp Harare map", 15, C.text, FontWeight.Bold)
                            T("One download over Wi-Fi. After that the map works with no internet.", 12, C.steel)
                        }
                        Icon(Icons.Filled.ChevronRight, null, tint = C.steel)
                    }
                }
            }
        }
        if (runs.isEmpty()) {
            item { FirstRun(onRecord) }
            item { RidesCard() }
        } else {
            item { WeekCard(runs) }
            item { RidesCard() }
            item { LastRun(runs.first()) { onOpen(runs.first().id) } }
            if (runs.size > 1) {
                item { T("RECENT RUNS", 12, C.steel, FontWeight.ExtraBold, Modifier.padding(start = 20.dp, top = 14.dp, bottom = 4.dp)) }
                items(runs.drop(1).take(40)) { s -> RunCard(s) { onOpen(s.id) } }
            }
        }
    }
}

/** Today at a glance: the same ring as the Movement tab, with health beside it. Tap to open Movement. */
@Composable
private fun HomeRing(today: Day, runs: List<Summary>, onMove: () -> Unit) {
    val ok = permGranted(Manifest.permission.ACTIVITY_RECOGNITION)
    val kcal = Cal.forDay(today, runs)
    val score = Cal.score(today, runs)
    val streak = Cal.streak(runs)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp).clip(RoundedCornerShape(28.dp)).background(C.card)
            .border(2.dp, C.line, RoundedCornerShape(28.dp)).clickable { onMove() }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StepRing(today.steps, Steps.goal(), kcal, 160.dp, 28.dp, false)
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            if (!ok) {
                T("Tap to allow step counting", 15, C.text, FontWeight.Bold)
            } else {
                T("Health", 13, C.steel, FontWeight.Bold)
                T((score * 100).toInt().toString() + "%", 34, C.text, FontWeight.ExtraBold)
                Spacer(Modifier.height(6.dp))
                HealthBar(score, height = 22.dp)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    T(nf2(rememberFill(kcal.toFloat()).toInt()) + "/" + nf2(Cal.goal()), 19, C.accent, FontWeight.ExtraBold)
                    T(" KCAL", 12, C.steel, FontWeight.Bold, Modifier.padding(bottom = 2.dp))
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.LocalFireDepartment, null, tint = if (streak > 0) C.accent else C.steel, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(4.dp))
                    T(if (streak == 1) "1 day streak" else "$streak day streak", 14, if (streak > 0) C.text else C.steel, FontWeight.Bold)
                }
            }
        }
    }
}

private fun nf2(n: Int): String = String.format(java.util.Locale.US, "%,d", n)

/** The latest run, shown big with its route. */
@Composable
private fun LastRun(s: Summary, onClick: () -> Unit) {
    Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp), onClick = onClick) {
        RoutePreview(s.mini, Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(18.dp)))
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                T(s.title, 18, C.text, FontWeight.ExtraBold)
                T(Fmt.date(s.start), 12, C.steel, FontWeight.Bold)
            }
            Column(horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.Bottom) {
                    T(Fmt.km(s.distM), 30, C.accent, FontWeight.ExtraBold)
                    T(" km", 14, C.steel, FontWeight.Bold, Modifier.padding(bottom = 5.dp))
                }
                T(Fmt.dur(s.durMs) + " · " + Fmt.pace(Fmt.paceOf(s.distM, s.durMs)) + " /km", 12, C.steel, FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun FirstRun(onRecord: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(150.dp).clip(CircleShape).background(C.go).clickable { onRecord() },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.DirectionsRun, null, tint = C.onAccent, modifier = Modifier.size(54.dp))
                T("START RUN", 15, C.onAccent, FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(22.dp))
        T("Your first run starts here", 20, C.text, FontWeight.Bold, align = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        T("WaveStride records your route, pace and distance. No account, no sign-up. Runs stay on your phone.", 14, C.steel, align = TextAlign.Center)
    }
}

@Composable
private fun WeekCard(runs: List<Summary>) {
    val now = System.currentTimeMillis()
    val ws = Stats.weekStart(now)
    val per = Stats.perDay(runs, ws, 7)
    val idx = (Calendar.getInstance().get(Calendar.DAY_OF_WEEK) + 5) % 7
    val tot = per.sum()
    val count = Stats.inRange(runs, ws, Long.MAX_VALUE).size
    Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
        T("THIS WEEK", 11, C.steel, FontWeight.Bold)
        Row(verticalAlignment = Alignment.Bottom) {
            T(Fmt.f1(tot), 30, C.accent, FontWeight.ExtraBold)
            T("  km  ·  $count run" + if (count == 1) "" else "s", 14, C.steel, modifier = Modifier.padding(bottom = 5.dp))
        }
        Spacer(Modifier.height(10.dp))
        Bars(per.map { it.toFloat() }, listOf("M", "T", "W", "T", "F", "S", "S"), idx, height = 70.dp)
        // a gentle weekly goal bar, only when a weekly goal has been set
        val wg = Goals.load().firstOrNull { it.period == "week" }
        if (wg != null) {
            val p = Goals.progress(wg, runs)
            val frac = (p / wg.target).toFloat().coerceIn(0f, 1f)
            val unit = if (wg.type == "km") "km" else "runs"
            Spacer(Modifier.height(10.dp))
            FillBar(frac, height = 8.dp, color = if (frac >= 1f) C.green else C.accent)
            Spacer(Modifier.height(4.dp))
            T(Fmt.f1(p).removeSuffix(".0") + " of " + Fmt.f1(wg.target).removeSuffix(".0") + " " + unit + " this week", 12, C.steel)
        }
    }
}

@Composable
fun RunCard(s: Summary, onClick: () -> Unit) {
    Card(Modifier.padding(horizontal = 14.dp, vertical = 5.dp), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RoutePreview(s.mini, Modifier.size(96.dp).clip(RoundedCornerShape(12.dp)))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                T(s.title, 16, C.text, FontWeight.Bold)
                T(Fmt.date(s.start), 12, C.steel)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column { T(Fmt.km(s.distM), 17, C.text, FontWeight.Bold); T("km", 11, C.steel) }
                    Column { T(Fmt.pace(Fmt.paceOf(s.distM, s.durMs)), 17, C.text, FontWeight.Bold); T("/km", 11, C.steel) }
                    Column { T(Fmt.dur(s.durMs), 17, C.text, FontWeight.Bold); T("time", 11, C.steel) }
                }
            }
        }
    }
}
