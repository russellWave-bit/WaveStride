package com.breadwinner.wavestride

import android.graphics.Color as AColor
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.flow.MutableStateFlow
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView as MLMapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.Point
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

class VDl(val running: Boolean = false, val frac: Float = 0f, val msg: String = "")

/** The sharp vector map of Harare: one file on the phone, drawn by MapLibre, light and dark. */
object VecMap {
    val dl = MutableStateFlow(VDl())
    private val tick = mutableStateOf(0)

    fun file(): File = File(App.ctx.filesDir, "maps/harare.pmtiles")

    fun ready(): Boolean {
        @Suppress("UNUSED_VARIABLE") val t = tick.value
        val f = file()
        return f.exists() && f.length() > 1_000_000L
    }

    fun url(): String = "https://github.com/" + BuildConfig.REPO + "/releases/download/harare-map/harare.pmtiles"

    /** 0 follow the app theme, 1 light, 2 dark */
    fun useDark(): Boolean = when (Prefs.i("map_style", 0)) { 1 -> false; 2 -> true; else -> Themes.cur.dark }

    fun styleJson(dark: Boolean): String {
        val name = if (dark) "map/style_dark.json" else "map/style_light.json"
        val txt = App.ctx.assets.open(name).bufferedReader().use { it.readText() }
        return txt.replace("__PMTILES__", file().absolutePath)
    }

    fun delete() {
        try { file().delete() } catch (e: Exception) { }
        tick.value = tick.value + 1
    }

    fun download() {
        if (dl.value.running) return
        dl.value = VDl(true, 0f, "Starting…")
        Thread {
            var msg = "Done. The sharp map is ready."
            try {
                val dest = file()
                dest.parentFile?.mkdirs()
                val tmp = File(dest.path + ".part")
                val c = URL(url()).openConnection() as HttpURLConnection
                c.connectTimeout = 20000
                c.readTimeout = 30000
                c.setRequestProperty("User-Agent", "WaveStride")
                if (c.responseCode != 200) {
                    msg = "Couldn't find the map file (code " + c.responseCode + "). Make it on GitHub first, and the repo must be public."
                } else {
                    val total = c.contentLengthLong
                    var got = 0L
                    c.inputStream.use { ins ->
                        FileOutputStream(tmp).use { out ->
                            val buf = ByteArray(64 * 1024)
                            var lastPost = 0L
                            while (true) {
                                val n = ins.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                got += n
                                val now = System.currentTimeMillis()
                                if (now - lastPost > 300) {
                                    lastPost = now
                                    val fr = if (total > 0) got.toFloat() / total else 0f
                                    dl.value = VDl(true, fr, Fmt.f1(got / 1048576.0) + " MB")
                                }
                            }
                        }
                    }
                    if (tmp.length() < 1_000_000L) {
                        msg = "The file came down too small, try again."
                        tmp.delete()
                    } else {
                        dest.delete()
                        tmp.renameTo(dest)
                    }
                }
            } catch (e: Exception) {
                msg = "Download stopped: " + (e.message ?: "no connection")
            }
            dl.value = VDl(false, 1f, msg)
            tick.value = tick.value + 1
        }.start()
    }
}

/** Download card for the sharp map. Used on the Offline map screen. */
@Composable
fun VecMapCard() {
    val d by VecMap.dl.collectAsState()
    val ready = VecMap.ready()
    var style by remember { mutableStateOf(Prefs.i("map_style", 0)) }
    Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
        T("SHARP MAP · HARARE", 11, C.steel, FontWeight.Bold)
        if (ready) {
            T("Ready on this phone", 20, C.text, FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            T(Fmt.f1(VecMap.file().length() / 1048576.0) + " MB. Works with no internet. Delete the old map pictures below to free space.", 13, C.steel)
            Spacer(Modifier.height(8.dp))
            Chips(listOf("Follow theme", "Light", "Dark"), style, { style = it; Prefs.put("map_style", it) })
            Spacer(Modifier.height(6.dp))
            GhostButton("Remove the sharp map", Modifier.fillMaxWidth(), null) { VecMap.delete() }
        } else {
            T("A cleaner, Google-style map", 20, C.text, FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            T("One download, then it works with no internet. Light and dark. Best over Wi-Fi.", 13, C.steel)
            Spacer(Modifier.height(8.dp))
            if (d.running) {
                Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp)).background(C.card2)) {
                    Box(Modifier.fillMaxWidth(d.frac.coerceIn(0f, 1f)).height(14.dp).clip(RoundedCornerShape(7.dp)).background(C.accent))
                }
                Spacer(Modifier.height(6.dp))
                T("Downloading… " + d.msg, 13, C.steelLt)
            } else {
                PrimaryButton("Download the Harare map", Modifier.fillMaxWidth(), Icons.Filled.Download) { VecMap.download() }
                if (d.msg.isNotEmpty()) { Spacer(Modifier.height(6.dp)); T(d.msg, 12, C.steel) }
            }
        }
    }
}

private fun hex(c: Color): String = String.format("#%06X", 0xFFFFFF and c.toArgb())

private class VHolder {
    var map: MapLibreMap? = null
    var style: Style? = null
    var loadedDark: Boolean? = null
    var loading = false
    var user = false
    var onMoved: (() -> Unit)? = null
    // what the screen wants
    var dark = true
    var lat = 0.0
    var lon = 0.0
    var zoom = 12.0
    var route: List<Pt>? = null
    var ver = 0
    var colors: List<Color>? = null
    var youLat = Double.NaN
    var youLon = Double.NaN
    var markers = true
    var routeSig = -1
    var youSig = ""

    fun render() {
        val m = map ?: return
        if (loadedDark != dark && !loading) {
            loading = true
            style = null
            loadedDark = dark
            m.setStyle(Style.Builder().fromJson(VecMap.styleJson(dark))) { st ->
                st.addSource(GeoJsonSource("route"))
                st.addLayer(
                    LineLayer("route-line", "route").withProperties(
                        PropertyFactory.lineColor(Expression.toColor(Expression.get("c"))),
                        PropertyFactory.lineWidth(4.5f),
                        PropertyFactory.lineCap(Property.LINE_CAP_ROUND),
                        PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND)
                    )
                )
                st.addSource(GeoJsonSource("marks"))
                st.addLayer(
                    CircleLayer("marks-c", "marks").withProperties(
                        PropertyFactory.circleRadius(7f),
                        PropertyFactory.circleColor(Expression.toColor(Expression.get("c"))),
                        PropertyFactory.circleStrokeColor("#FFFFFF"),
                        PropertyFactory.circleStrokeWidth(2.5f)
                    )
                )
                st.addSource(GeoJsonSource("you"))
                st.addLayer(
                    CircleLayer("you-c", "you").withProperties(
                        PropertyFactory.circleRadius(8f),
                        PropertyFactory.circleColor("#2D7DD2"),
                        PropertyFactory.circleStrokeColor("#FFFFFF"),
                        PropertyFactory.circleStrokeWidth(3f)
                    )
                )
                style = st
                loading = false
                routeSig = -1
                youSig = ""
                render()
            }
            return
        }
        val st = style ?: return

        // camera: follow what the screen asks for, unless the finger is moving the map
        if (!user) {
            val cp = m.cameraPosition
            val t = cp.target
            if (t == null || Math.abs(t.latitude - lat) > 1e-7 || Math.abs(t.longitude - lon) > 1e-7 || Math.abs(cp.zoom - zoom) > 1e-3) {
                m.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(lat, lon), zoom))
            }
        }

        // the route
        val r = route
        val sig = (r?.size ?: 0) * 31 + ver * 7 + (if (colors != null) 1 else 0) + (if (markers) 2 else 0)
        if (sig != routeSig) {
            routeSig = sig
            val rs = st.getSourceAs<GeoJsonSource>("route")
            val ms = st.getSourceAs<GeoJsonSource>("marks")
            if (r != null && r.size > 1) {
                val cs = colors
                val feats = ArrayList<Feature>()
                if (cs != null && cs.size >= r.size - 1) {
                    for (i in 1 until r.size) {
                        val f = Feature.fromGeometry(LineString.fromLngLats(listOf(Point.fromLngLat(r[i - 1].lon, r[i - 1].lat), Point.fromLngLat(r[i].lon, r[i].lat))))
                        f.addStringProperty("c", hex(cs[i - 1]))
                        feats.add(f)
                    }
                } else {
                    val f = Feature.fromGeometry(LineString.fromLngLats(r.map { Point.fromLngLat(it.lon, it.lat) }))
                    f.addStringProperty("c", hex(C.route))
                    feats.add(f)
                }
                rs?.setGeoJson(FeatureCollection.fromFeatures(feats))
                if (markers) {
                    val a = Feature.fromGeometry(Point.fromLngLat(r.first().lon, r.first().lat))
                    a.addStringProperty("c", hex(C.green))
                    val b = Feature.fromGeometry(Point.fromLngLat(r.last().lon, r.last().lat))
                    b.addStringProperty("c", hex(C.red))
                    ms?.setGeoJson(FeatureCollection.fromFeatures(listOf(a, b)))
                } else ms?.setGeoJson(FeatureCollection.fromFeatures(ArrayList<Feature>()))
            } else {
                rs?.setGeoJson(FeatureCollection.fromFeatures(ArrayList<Feature>()))
                ms?.setGeoJson(FeatureCollection.fromFeatures(ArrayList<Feature>()))
            }
        }

        // you
        val ys = if (youLat.isNaN() || youLon.isNaN()) "" else youLat.toString() + "," + youLon.toString()
        if (ys != youSig) {
            youSig = ys
            val src = st.getSourceAs<GeoJsonSource>("you")
            if (ys.isEmpty()) src?.setGeoJson(FeatureCollection.fromFeatures(ArrayList<Feature>()))
            else src?.setGeoJson(Feature.fromGeometry(Point.fromLngLat(youLon, youLat)))
        }
    }
}

/** The same call as the old tile map, drawn by MapLibre from the Harare file. */
@Composable
fun VecMapView(
    cam: MapCam,
    modifier: Modifier = Modifier,
    route: List<Pt>? = null,
    ver: Int = 0,
    colors: List<Color>? = null,
    youLat: Double = Double.NaN,
    youLon: Double = Double.NaN,
    fitRoute: Boolean = false,
    markers: Boolean = true,
    interactive: Boolean = true,
    onMoved: (() -> Unit)? = null
) {
    val ctx = LocalContext.current
    val dens = LocalDensity.current.density
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val holder = remember { VHolder() }
    val mv = remember {
        MapLibre.getInstance(ctx.applicationContext)
        MLMapView(ctx).also { it.onCreate(null) }
    }
    var sz by remember { mutableStateOf(IntSize.Zero) }

    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_START -> mv.onStart()
                Lifecycle.Event.ON_RESUME -> mv.onResume()
                Lifecycle.Event.ON_PAUSE -> mv.onPause()
                Lifecycle.Event.ON_STOP -> mv.onStop()
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        onDispose {
            lifecycle.removeObserver(obs)
            try { mv.onPause(); mv.onStop(); mv.onDestroy() } catch (e: Exception) { }
        }
    }

    LaunchedEffect(sz, fitRoute, route?.size) {
        if (fitRoute && route != null && route.size > 1 && sz.width > 0) {
            cam.fit(route.map { doubleArrayOf(it.lat, it.lon) }, sz.width.toFloat(), sz.height.toFloat(), dens, 48f * dens)
        }
    }

    Box(modifier.onSizeChanged { sz = it }) {
        AndroidView(
            factory = { _ ->
                mv.getMapAsync { map ->
                    holder.map = map
                    map.uiSettings.isRotateGesturesEnabled = false
                    map.uiSettings.isTiltGesturesEnabled = false
                    map.uiSettings.isCompassEnabled = false
                    map.uiSettings.isLogoEnabled = false
                    map.uiSettings.isAttributionEnabled = false
                    map.setMinZoomPreference(5.0)
                    map.setMaxZoomPreference(19.0)
                    map.addOnCameraMoveStartedListener { reason ->
                        holder.user = reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE
                        if (holder.user) holder.onMoved?.invoke()
                    }
                    map.addOnCameraMoveListener {
                        if (holder.user) {
                            val cp = map.cameraPosition
                            val t = cp.target
                            if (t != null) {
                                cam.cx = Geo.mx(t.longitude)
                                cam.cy = Geo.my(t.latitude)
                                cam.zoom = cp.zoom + 1.0
                            }
                        }
                    }
                    map.addOnCameraIdleListener { holder.user = false }
                    holder.render()
                }
                mv
            },
            modifier = Modifier.fillMaxSize(),
            update = { _ ->
                holder.onMoved = onMoved
                holder.dark = VecMap.useDark()
                holder.lat = Geo.latOf(cam.cy)
                holder.lon = Geo.lonOf(cam.cx)
                holder.zoom = cam.zoom - 1.0
                holder.route = route
                holder.ver = ver
                holder.colors = colors
                holder.youLat = youLat
                holder.youLon = youLon
                holder.markers = markers
                holder.map?.uiSettings?.setAllGesturesEnabled(interactive)
                holder.map?.uiSettings?.isRotateGesturesEnabled = false
                holder.map?.uiSettings?.isTiltGesturesEnabled = false
                holder.render()
            }
        )
        Box(
            Modifier.align(Alignment.BottomStart).padding(6.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xCCFFFFFF)).padding(horizontal = 5.dp, vertical = 1.dp)
        ) { T("© OpenStreetMap contributors · Protomaps", 9, Color(0xFF444444)) }
    }
}
