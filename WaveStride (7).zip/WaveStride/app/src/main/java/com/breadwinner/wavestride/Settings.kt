package com.breadwinner.wavestride

import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Height
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Person
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun MoreScreen(onMaps: () -> Unit) {
    val ctx = LocalContext.current
    var voice by remember { mutableStateOf(Prefs.b("voice", false)) }
    var every by remember { mutableStateOf(when (Prefs.i("voice_every", 1)) { 2 -> 1; 5 -> 2; else -> 0 }) }
    var awake by remember { mutableStateOf(Prefs.b("awake", true)) }
    var speed by remember { mutableStateOf(Prefs.i("route_speed", 0)) }
    var goal by remember { mutableStateOf(when (Steps.goal()) { 12000 -> 1; 15000 -> 2; 20000 -> 3; else -> 0 }) }
    var stride by remember { mutableStateOf(when (Prefs.f("stride", 0.75f)) { 0.65f -> 0; 0.85f -> 2; else -> 1 }) }
    var calGoal by remember { mutableStateOf(when (Cal.goal()) { 300 -> 0; 500 -> 2; 600 -> 3; else -> 1 }) }
    var weightTxt by remember { mutableStateOf(Cal.weight().let { if (it > 0f) (if (it == Math.floor(it.toDouble()).toFloat()) it.toInt().toString() else it.toString()) else "" }) }
    var heightTxt by remember { mutableStateOf(Cal.height().let { if (it > 0) it.toString() else "" }) }
    var musicOn by remember { mutableStateOf(Music.enabled()) }
    LaunchedEffect(Unit) { while (true) { delay(1500); musicOn = Music.enabled() } }
    val area = remember { Areas.current() }
    var alwaysSteps by remember { mutableStateOf(Prefs.b("always_steps", true)) }
    var rides by remember { mutableStateOf(Rides.enabled()) }
    fun bgLocOk(): Boolean = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
    fun battOk(): Boolean = try { (ctx.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName) } catch (e: Exception) { false }
    var bgLoc by remember { mutableStateOf(bgLocOk()) }
    var batt by remember { mutableStateOf(battOk()) }
    var actOk by remember { mutableStateOf(Steps.allowed()) }
    LaunchedEffect(Unit) { while (true) { delay(1500); bgLoc = bgLocOk(); batt = battOk(); actOk = Steps.allowed() } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("More", null)

        Shelf("Keep it tracking", Icons.Filled.BatteryFull) {
            SwitchRow(
                Icons.Filled.DirectionsWalk, "Count steps all day",
                if (!actOk) "Needs the Physical activity permission" else "A small quiet notification keeps the counter awake",
                "Without this, the phone can put WaveStride to sleep and walks go uncounted. The notification is silent and shows no icon in the status bar.",
                alwaysSteps
            ) {
                alwaysSteps = it; Prefs.put("always_steps", it)
                if (it) StepService.start(ctx) else StepService.stop(ctx)
            }
            Rule()
            SettingRow(
                Icons.Filled.LocationOn, "Location: all the time",
                if (bgLoc) "On. Recording keeps going with the screen off" else "Not on yet. Tap, then Location, then Allow all the time",
                "Choose Allow all the time (not only while using the app) so a walk or run keeps recording when you lock the screen or switch apps.",
                chevron = true,
                onClick = {
                    try { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
                }
            )
            Rule()
            SettingRow(
                Icons.Filled.BatteryFull, "Battery: never put to sleep",
                if (batt) "On. The phone will not stop WaveStride" else "Not on yet. Tap and choose Allow",
                "Samsung phones sleep apps to save power. Allowing this keeps step counting and run recording alive. It uses very little battery.",
                chevron = true,
                onClick = {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                        try { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (x: Exception) { }
                    }
                }
            )
        }

        Shelf("Run", Icons.Filled.DirectionsRun) {
            SwitchRow(
                Icons.Filled.VolumeUp, "Spoken updates", "Tells you distance, time and pace as you run",
                "WaveStride speaks through your phone, so earbuds work too. You choose how often it speaks. Nothing is sent anywhere.", voice
            ) { voice = it; Prefs.put("voice", it) }
            if (voice) {
                Rule()
                Chips(listOf("Every 1 km", "Every 2 km", "Every 5 km"), every, {
                    every = it
                    Prefs.put("voice_every", when (it) { 1 -> 2; 2 -> 5; else -> 1 })
                })
            }
            Rule()
            SwitchRow(
                Icons.Filled.DirectionsCar, "Count car rides",
                if (!bgLoc) "Needs location set to Allow all the time" else "Counts rides and distance. No routes are saved.",
                "Uses the phone's low-power motion sensor. The GPS only wakes for a short check when you move without taking steps, and only stays on while you are in a vehicle. Only the count, time and distance are kept.",
                rides
            ) {
                rides = it
                Prefs.put("rides", it)
                if (it) RideWatcher.start(ctx) else RideWatcher.stop()
            }
            Rule()
            SwitchRow(Icons.Filled.Visibility, "Keep screen on while running", null, null, awake) { awake = it; Prefs.put("awake", it) }
            Rule()
            SettingRow(
                Icons.Filled.Info, "Recording with the screen off",
                "Tap the i if runs stop when your screen locks",
                "On Samsung phones: Settings, Apps, WaveStride, Battery, then choose Unrestricted. That stops the phone putting the app to sleep during a run."
            )
        }

        Shelf("Map", Icons.Filled.Map) {
            SettingRow(
                Icons.Filled.LocationOn, "Offline map", area.name + " · tap to change or download",
                "Maps are saved on your phone once, then work with no data. Harare is the default and you can pick any other city.",
                chevron = true, onClick = onMaps
            )
        }

        Shelf("Look", Icons.Filled.Palette) {
            Box(Modifier.padding(start = 14.dp, top = 12.dp)) { T("Theme", 14, C.text, FontWeight.Medium) }
            Chips(listOf("Dark", "Light", "Neon"), Themes.mode, { Themes.set(it) })
            Rule()
            Chips(listOf("Plain orange route", "Speed colours"), speed, { speed = it; Prefs.put("route_speed", it) })
            Box(Modifier.padding(horizontal = 14.dp).padding(bottom = 12.dp)) {
                T("The line is crisp and solid, never glowing. Speed colours go from blue (slow) to red (fast) against each run's own range.", 12, C.steel)
            }
        }

        Shelf("Daily movement", Icons.Filled.DirectionsWalk) {
            Box(Modifier.padding(start = 14.dp, top = 12.dp)) { T("Daily step goal", 14, C.text, FontWeight.Medium) }
            Chips(listOf("8,000", "12,000", "15,000", "20,000"), goal, {
                goal = it
                Prefs.put("stepgoal", when (it) { 1 -> 12000; 2 -> 15000; 3 -> 20000; else -> 8000 })
            })
            Rule()
            Row(Modifier.fillMaxWidth().padding(start = 14.dp, top = 12.dp, end = 14.dp)) {
                T("Step length", 14, C.text, FontWeight.Medium, Modifier.weight(1f))
                InfoDot("Used to estimate how far you walked from your steps. If you add your height under Calories, that is used instead.")
            }
            Chips(listOf("0.65 m", "0.75 m", "0.85 m"), stride, {
                stride = it
                Prefs.put("stride", when (it) { 0 -> 0.65f; 2 -> 0.85f; else -> 0.75f })
            })
        }

        Shelf("Calories", Icons.Filled.LocalFireDepartment) {
            Box(Modifier.padding(start = 14.dp, top = 12.dp)) { T("Daily calorie goal", 14, C.text, FontWeight.Medium) }
            Chips(listOf("300", "400", "500", "600"), calGoal, {
                calGoal = it
                Prefs.put("calgoal", when (it) { 0 -> 300; 2 -> 500; 3 -> 600; else -> 400 })
            })
            Rule()
            Row(Modifier.fillMaxWidth().padding(start = 14.dp, top = 12.dp, end = 14.dp)) {
                T("About you (optional)", 14, C.text, FontWeight.Medium, Modifier.weight(1f))
                InfoDot("Calories are counted from your steps either way. Adding your weight makes the number closer, and your height sharpens the distance. Both stay on this phone.")
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = weightTxt, onValueChange = { v ->
                        weightTxt = v.take(5)
                        Prefs.put("weight_kg", weightTxt.replace(',', '.').toFloatOrNull()?.takeIf { it in 25f..250f } ?: 0f)
                    }, singleLine = true, modifier = Modifier.weight(1f),
                    label = { Text("Weight (kg)") }, leadingIcon = { Icon(Icons.Filled.Person, null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                OutlinedTextField(
                    value = heightTxt, onValueChange = { v ->
                        heightTxt = v.take(3)
                        Prefs.put("height_cm", heightTxt.toIntOrNull()?.takeIf { it in 100..230 } ?: 0)
                    }, singleLine = true, modifier = Modifier.weight(1f),
                    label = { Text("Height (cm)") }, leadingIcon = { Icon(Icons.Filled.Height, null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }
        }

        Shelf("Music and widgets", Icons.Filled.MusicNote) {
            SettingRow(
                Icons.Filled.MusicNote, "Music control", if (musicOn) "On. Shows what's playing on the run screen" else "Off. Tap to allow notification access",
                "Android only lets an app see what music is playing if you switch on notification access for it. It's a one-time switch, and WaveStride reads nothing else.",
                chevron = !musicOn, onClick = {
                    try { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
                }
            )
            Rule()
            SettingRow(
                Icons.Filled.Widgets, "Home screen widgets", "Steps, health bar, last run, week chart, start run, music",
                "Press and hold an empty spot on your home screen, choose Widgets, then find WaveStride. There are six to pick from."
            )
        }

        Shelf("About", Icons.Filled.Info) {
            SettingRow(Icons.Filled.Speed, "WaveStride 1.0", "Your own run tracker")
            Rule()
            SettingRow(Icons.Filled.Storage, "Privacy", "Runs, steps and goals stay on this phone. Only map pictures come from the internet.")
            Rule()
            SettingRow(Icons.Filled.Map, "Map data", "© OpenStreetMap contributors")
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun MapsScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var place by remember { mutableStateOf(Areas.current()) }
    var km by remember { mutableStateOf(Areas.radiusKm()) }
    var fetch by remember { mutableStateOf(when (Prefs.s("fetch", "wifi")) { "any" -> 1; "never" -> 2; else -> 0 }) }
    val dl by Tiles.dl.collectAsState()
    var bytes by remember { mutableStateOf(0L) }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Place>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var confirmData by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    LaunchedEffect(dl.running) { bytes = withContext(Dispatchers.IO) { Tiles.sizeBytes() } }

    val tiles = Tiles.count(place.lat, place.lon, km.toDouble())
    val estMb = tiles * 15 / 1024

    fun start() { Tiles.download(place.lat, place.lon, km.toDouble()) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Offline map", onBack)

        VecMapCard()

        Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
            T("MAP AREA", 11, C.steel, FontWeight.Bold)
            T(place.name, 22, C.text, FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            T("Covers about $km km around the centre. About $tiles map pieces, roughly $estMb MB.", 13, C.steel)
            Spacer(Modifier.height(8.dp))
            Chips(listOf("5 km", "10 km", "15 km"), when (km) { 5 -> 0; 15 -> 2; else -> 1 }, {
                km = when (it) { 0 -> 5; 2 -> 15; else -> 10 }
                Prefs.put("area_km", km)
            }, Modifier.padding(horizontal = 0.dp))
            Spacer(Modifier.height(6.dp))
            if (dl.running) {
                val frac = if (dl.total > 0) dl.done.toFloat() / dl.total else 0f
                Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp)).background(C.card2)) {
                    Box(Modifier.fillMaxWidth(frac.coerceIn(0f, 1f)).height(14.dp).clip(RoundedCornerShape(7.dp)).background(C.accent))
                }
                Spacer(Modifier.height(6.dp))
                T("Downloading… ${dl.done} of ${dl.total}", 13, C.steelLt)
                Spacer(Modifier.height(8.dp))
                GhostButton("Stop", Modifier.fillMaxWidth(), null) { Tiles.cancelDownload() }
            } else {
                if (!Tiles.onWifi()) {
                    T("You're not on Wi-Fi. Downloading now would use about $estMb MB of mobile data.", 12, C.steelLt)
                    Spacer(Modifier.height(8.dp))
                }
                PrimaryButton(if (bytes > 0) "Download again / fill gaps" else "Download this map", Modifier.fillMaxWidth(), Icons.Filled.Download) {
                    if (Tiles.onWifi()) start() else confirmData = true
                }
                if (dl.msg.isNotEmpty()) { Spacer(Modifier.height(6.dp)); T(dl.msg, 12, C.steel) }
            }
        }

        Shelf("Saved on this phone", Icons.Filled.Storage) {
            SettingRow(Icons.Filled.Storage, Fmt.f1(bytes / 1048576.0) + " MB of map pictures", "Kept until you delete them")
            Rule()
            SettingRow(Icons.Filled.Delete, "Delete downloaded maps", "Frees the space. You can download again later.", onClick = { confirmDelete = true })
        }

        Shelf("When to fetch missing map pieces", Icons.Filled.Wifi) {
            Chips(listOf("Wi-Fi only", "Any network", "Never"), fetch, {
                fetch = it
                Prefs.put("fetch", when (it) { 1 -> "any"; 2 -> "never"; else -> "wifi" })
            })
            Box(Modifier.padding(horizontal = 14.dp).padding(bottom = 12.dp)) {
                T("Outside your downloaded area, the map fills in from the internet only when this allows it. Wi-Fi only keeps your mobile data safe.", 12, C.steel)
            }
        }

        Shelf("Pick another city", Icons.Filled.Search) {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    label = { Text("City or place name") }, modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                PrimaryButton("Find", Modifier, null) {
                    if (query.isNotBlank() && !searching) scope.launch {
                        searching = true
                        note = ""
                        results = withContext(Dispatchers.IO) { Areas.search(query.trim()) }
                        searching = false
                        if (results.isEmpty()) note = "Nothing found. Searching needs the internet."
                    }
                }
            }
            if (searching) Box(Modifier.padding(horizontal = 14.dp).padding(bottom = 10.dp)) { T("Searching…", 13, C.steel) }
            if (note.isNotEmpty()) Box(Modifier.padding(horizontal = 14.dp).padding(bottom = 10.dp)) { T(note, 13, C.steel) }
            for (p in results) {
                Rule()
                SettingRow(Icons.Filled.LocationOn, p.name, null, onClick = { Areas.set(p); place = p; results = emptyList() })
            }
            val me = Gps.last.value
            if (me != null) {
                Rule()
                SettingRow(Icons.Filled.MyLocation, "Where I am now", "Use my current position as the map centre", onClick = {
                    val p = Place("My location", me.latitude, me.longitude)
                    Areas.set(p); place = p
                })
            }
            for (p in Areas.presets) {
                Rule()
                SettingRow(Icons.Filled.LocationOn, p.name, null, onClick = { Areas.set(p); place = p })
            }
        }
        Box(Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
            T("Map pictures © OpenStreetMap contributors. Download the cities you really use and keep them. Please don't download huge areas.", 11, C.steel)
        }
        Spacer(Modifier.height(24.dp))
    }

    if (confirmData) {
        AlertDialog(
            onDismissRequest = { confirmData = false },
            confirmButton = { TextButton(onClick = { confirmData = false; start() }) { Text("Download anyway", color = C.accent) } },
            dismissButton = { TextButton(onClick = { confirmData = false }) { Text("Wait for Wi-Fi", color = C.steelLt) } },
            title = { Text("Use mobile data?", color = C.text) },
            text = { Text("This download is about $estMb MB. You're not on Wi-Fi right now.", color = C.text) },
            containerColor = C.card
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            confirmButton = { TextButton(onClick = { confirmDelete = false; Tiles.clear(); bytes = 0L }) { Text("Delete", color = C.red) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Keep", color = C.steelLt) } },
            title = { Text("Delete downloaded maps?", color = C.text) },
            text = { Text("Maps will stop working offline until you download them again.", color = C.text) },
            containerColor = C.card
        )
    }
}
