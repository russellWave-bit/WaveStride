package com.breadwinner.wavestride

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.TriggerEvent
import android.hardware.TriggerEventListener
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/** One car ride: when it started, how long it lasted and how far it went. No route is kept. */
class Ride(val start: Long, val ms: Long, val distM: Double)

object Rides {
    fun enabled(): Boolean = Prefs.b("rides", true)

    fun list(): List<Ride> {
        val out = ArrayList<Ride>()
        try {
            val a = JSONArray(Prefs.s("rides_log", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Ride(o.getLong("t"), o.getLong("ms"), o.getDouble("d")))
            }
        } catch (e: Exception) { }
        return out
    }

    fun add(r: Ride) {
        val l = ArrayList(list())
        l.add(r)
        val keep = if (l.size > 2000) l.subList(l.size - 2000, l.size) else l
        val a = JSONArray()
        for (x in keep) a.put(JSONObject().put("t", x.start).put("ms", x.ms).put("d", x.distM))
        Prefs.put("rides_log", a.toString())
    }
}

/**
 * Notices car rides without keeping a GPS running all day. The phone's low-power "significant motion" sensor
 * wakes it, and only if you are moving without taking steps does the GPS switch on for a short check.
 * Fast and no steps = a ride: it adds up the distance, throws the points away, and keeps only the total.
 */
object RideWatcher {
    private val h = Handler(Looper.getMainLooper())
    private var ctx: Context? = null
    private var armed = false
    private var probing = false
    private var riding = false
    private var listening = false

    /** Raw step counter value and when it last changed, fed by StepService. */
    @Volatile var rawSteps = -1f
    @Volatile var stepChangeAt = 0L

    private var stepsAtProbe = 0f
    private var fastRun = 0
    private var slowSince = 0L
    private var rideStartWall = 0L
    private var rideStartElapsed = 0L
    private var dist = 0.0
    private var lastLoc: Location? = null

    private val trigger = object : TriggerEventListener() {
        override fun onTrigger(event: TriggerEvent?) {
            armed = false
            h.post { onMotion() }
        }
    }

    private val locL = object : LocationListener {
        override fun onLocationChanged(l: Location) { onFix(l) }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("old callback")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    private val deadline = Runnable { endProbe() }
    private val rearm = Runnable { arm() }

    fun noteSteps(v: Float) {
        if (v != rawSteps) stepChangeAt = SystemClock.elapsedRealtime()
        rawSteps = v
    }

    private fun bgOk(c: Context): Boolean =
        ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun start(c: Context) {
        ctx = c.applicationContext
        if (!Rides.enabled() || !bgOk(c)) { stop(); return }
        arm()
    }

    fun stop() {
        h.removeCallbacks(deadline)
        h.removeCallbacks(rearm)
        try {
            val sm = ctx?.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
            val s = sm?.getDefaultSensor(Sensor.TYPE_SIGNIFICANT_MOTION)
            if (sm != null && s != null) sm.cancelTriggerSensor(trigger, s)
        } catch (e: Exception) { }
        armed = false
        stopGps()
        probing = false
        riding = false
    }

    private fun arm() {
        val c = ctx ?: return
        if (armed || probing || riding || !Rides.enabled()) return
        try {
            val sm = c.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            val s = sm.getDefaultSensor(Sensor.TYPE_SIGNIFICANT_MOTION) ?: return
            armed = sm.requestTriggerSensor(trigger, s)
        } catch (e: Exception) { }
    }

    private fun later(ms: Long) {
        h.removeCallbacks(rearm)
        h.postDelayed(rearm, ms)
    }

    private fun onMotion() {
        val c = ctx ?: return
        if (!Rides.enabled() || !bgOk(c)) return
        // a run is being recorded, or you are on foot (steps just ticked): not a ride
        if (RunState.flow.value.st != St.IDLE) { later(5 * 60_000L); return }
        if (SystemClock.elapsedRealtime() - stepChangeAt < 15_000L) { later(2 * 60_000L); return }
        beginProbe()
    }

    @SuppressLint("MissingPermission")
    private fun startGps(interval: Long) {
        val c = ctx ?: return
        try {
            val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            if (listening) lm.removeUpdates(locL)
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, interval, 0f, locL, Looper.getMainLooper())
            listening = true
        } catch (e: Exception) { listening = false }
    }

    private fun stopGps() {
        try {
            val lm = ctx?.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            lm?.removeUpdates(locL)
        } catch (e: Exception) { }
        listening = false
        lastLoc = null
    }

    private fun beginProbe() {
        probing = true
        fastRun = 0
        stepsAtProbe = rawSteps
        lastLoc = null
        startGps(1000L)
        h.removeCallbacks(deadline)
        h.postDelayed(deadline, 50_000L)
    }

    private fun endProbe() {
        if (!probing) return
        probing = false
        if (!riding) {
            stopGps()
            later(60_000L)
        }
    }

    private fun onFix(l: Location) {
        if (l.hasAccuracy() && l.accuracy > 40f) return
        val speed = if (l.hasSpeed()) l.speed.toDouble() else 0.0
        val prev = lastLoc
        lastLoc = l
        if (probing) {
            fastRun = if (speed >= 6.0) fastRun + 1 else 0
            val stepsMoved = if (rawSteps >= 0f && stepsAtProbe >= 0f) rawSteps - stepsAtProbe else 0f
            if (fastRun >= 12 && stepsMoved <= 15f) {
                // fast, and not on your feet: a ride has begun
                probing = false
                riding = true
                h.removeCallbacks(deadline)
                rideStartWall = System.currentTimeMillis()
                rideStartElapsed = SystemClock.elapsedRealtime()
                dist = speed * 12.0   // the 12 seconds that proved it
                slowSince = 0L
                startGps(3000L)
            }
            return
        }
        if (!riding) return
        if (prev != null) {
            val step = prev.distanceTo(l).toDouble()
            if (step < 400.0) dist += step      // ignore a GPS jump
        }
        val now = SystemClock.elapsedRealtime()
        if (speed < 1.5) {
            if (slowSince == 0L) slowSince = now
            if (now - slowSince >= 150_000L) endRide(now)
        } else {
            slowSince = 0L
        }
        if (now - rideStartElapsed > 8 * 3600_000L) endRide(now)
    }

    private fun endRide(now: Long) {
        riding = false
        stopGps()
        val ms = (now - rideStartElapsed) - 150_000L
        // short hops are not rides
        if (dist >= 1000.0) Rides.add(Ride(rideStartWall, ms.coerceAtLeast(60_000L), dist))
        try { Widgets.updateAll() } catch (e: Exception) { }
        later(30_000L)
    }
}

/** Home card: how many rides, how far, how long. */
@Composable
fun RidesCard() {
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(5000); tick++ } }
    val rides = remember(tick) { Rides.list() }
    if (!Rides.enabled() && rides.isEmpty()) return
    val km = rides.sumOf { it.distM } / 1000.0
    val ms = rides.sumOf { it.ms }
    Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.DirectionsCar, null, tint = C.steelLt)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                T("RIDES", 11, C.steel, FontWeight.Bold)
                Row(verticalAlignment = Alignment.Bottom) {
                    T(rides.size.toString(), 30, C.text, FontWeight.ExtraBold)
                    T(if (rides.size == 1) "  ride" else "  rides", 14, C.steel, modifier = Modifier.padding(bottom = 5.dp))
                }
                T(Fmt.f1(km) + " km  ·  " + Fmt.dur(ms), 13, C.steel)
            }
        }
    }
}
