package com.breadwinner.wavestride

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.min

private fun nf(n: Int): String = String.format(Locale.US, "%,d", n)
private val DAY_L = listOf("S", "M", "T", "W", "T", "F", "S")

private fun parseKey(k: String): Long = try {
    SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(k)?.time ?: 0L
} catch (e: Exception) { 0L }

private fun niceDay(k: String): String =
    if (k == Steps.key()) "Today" else SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(Date(parseKey(k)))

/** This calendar week, Sunday first, as day keys. */
private fun weekKeys(): List<String> {
    val c = Calendar.getInstance()
    c.add(Calendar.DAY_OF_YEAR, -(c.get(Calendar.DAY_OF_WEEK) - 1))
    return (0 until 7).map { i ->
        val x = c.clone() as Calendar
        x.add(Calendar.DAY_OF_YEAR, i)
        Steps.key(x.timeInMillis)
    }
}

/**
 * The big thick ring: steps inside, an arrow on the start of the arc. It fills from zero when the screen opens.
 * Used on the Movement tab (big) and on Home (smaller).
 */
@Composable
fun StepRing(steps: Int, goal: Int, kcal: Int, size: Dp, stroke: Dp, big: Boolean, modifier: Modifier = Modifier) {
    val shown = rememberFill(steps.toFloat()).toInt()
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Ring(steps.toFloat() / goal.coerceAtLeast(1), size, stroke) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.DirectionsWalk, null, tint = C.steelLt, modifier = Modifier.size(if (big) 34.dp else 20.dp))
                T(nf(shown), if (big) 54 else 26, C.text, FontWeight.ExtraBold)
                T(if (big) "steps of " + nf(goal) else "steps", if (big) 15 else 11, C.steel, FontWeight.Bold)
            }
        }
        if (steps > 0) {
            val ai = if (big) 26.dp else 16.dp
            Icon(
                Icons.Filled.ArrowForward, null, tint = C.onAccent,
                modifier = Modifier.align(Alignment.TopCenter).offset(x = 4.dp, y = stroke / 2 - ai / 2).size(ai)
            )
        }
    }
}

@Composable
private fun StatBig(label: String, value: String, unit: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        T(label, 14, C.text, FontWeight.ExtraBold)
        Row(verticalAlignment = Alignment.Bottom) {
            T(value, 28, C.steelLt, FontWeight.ExtraBold)
            if (unit.isNotEmpty()) T(unit, 14, C.steel, FontWeight.Bold, Modifier.padding(start = 3.dp, bottom = 4.dp))
        }
    }
}

@Composable
fun MoveScreen() {
    var tick by remember { mutableStateOf(0) }
    var ok by remember { mutableStateOf(permGranted(Manifest.permission.ACTIVITY_RECOGNITION)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { g ->
        ok = g
        Steps.snapshot { tick++ }
    }
    LaunchedEffect(Unit) { Steps.snapshot { tick++ } }
    var selKey by remember { mutableStateOf(Steps.key()) }
    var detail by remember { mutableStateOf(false) }
    val runs = remember(tick) { Runs.list() }
    val d = remember(tick, selKey) { Steps.day(selKey) }

    if (detail) {
        BackHandler { detail = false }
        MoveDetail(d, runs) { detail = false }
    } else {
        MoveMain(d, runs, tick, ok, selKey, { selKey = it }, { detail = true }) { launcher.launch(Manifest.permission.ACTIVITY_RECOGNITION) }
    }
}

@Composable
private fun MoveMain(d: Day, runs: List<Summary>, tick: Int, ok: Boolean, selKey: String, onSel: (String) -> Unit, onDetail: () -> Unit, onAllow: () -> Unit) {
    val scope = rememberCoroutineScope()
    val sc = rememberScrollState()
    val goal = Steps.goal()
    val kcal = Cal.forDay(d, runs)
    val score = Cal.score(d, runs)
    val streak = remember(tick) { Cal.streak(runs) }
    val todayKey = Steps.key()
    val wk = remember(todayKey) { weekKeys() }
    var range by remember { mutableStateOf(0) }
    val days30 = remember(tick) { Steps.days(30) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val vh = maxHeight
        val vw = maxWidth
        val vhPx = with(androidx.compose.ui.platform.LocalDensity.current) { vh.toPx() }
        Column(Modifier.fillMaxSize().verticalScroll(sc)) {
            // the top screen: week, ring, health. Everything below waits for a swipe up.
            Column(
                Modifier.fillMaxWidth().height(vh * 0.94f).graphicsLayer {
                    translationY = sc.value * 0.45f
                    alpha = (1f - sc.value / (vhPx * 0.75f)).coerceIn(0f, 1f)
                },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceEvenly
            ) {
                if (!ok) {
                    Row(Modifier.padding(horizontal = 16.dp).fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(C.card).clickable { onAllow() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        T("Tap to allow step counting", 15, C.text, FontWeight.Bold, Modifier.weight(1f))
                    }
                }
                // week strip: a mini ring per day
                Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    wk.forEachIndexed { i, k ->
                        val sel = k == selKey
                        val future = k > todayKey
                        val ds = remember(k, tick) { Steps.day(k) }
                        Column(Modifier.weight(1f).clickable(enabled = !future) { onSel(k) }, horizontalAlignment = Alignment.CenterHorizontally) {
                            Ring(if (future) 0f else ds.steps.toFloat() / goal.coerceAtLeast(1), 38.dp, 7.dp)
                            Spacer(Modifier.height(5.dp))
                            Box(Modifier.clip(RoundedCornerShape(50)).background(if (sel) C.accent else Color.Transparent).padding(horizontal = 10.dp, vertical = 2.dp)) {
                                T(DAY_L[i], 13, if (sel) C.onAccent else if (future) C.line else C.steel, FontWeight.Bold)
                            }
                        }
                    }
                }
                T(niceDay(selKey), 17, C.steelLt, FontWeight.Bold)
                // the big ring
                val side = min(vw.value - 48f, vh.value * 0.42f).dp
                StepRing(d.steps, goal, kcal, side, side * 0.24f, true, Modifier.clickable { onDetail() })
                // Move line
                val kShown = rememberFill(kcal.toFloat()).toInt()
                Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
                    T("Move", 16, C.text, FontWeight.ExtraBold)
                    Row(verticalAlignment = Alignment.Bottom) {
                        T(nf(kShown) + "/" + nf(Cal.goal()), 34, C.accent, FontWeight.ExtraBold)
                        T(" KCAL", 15, C.steel, FontWeight.Bold, Modifier.padding(bottom = 6.dp))
                    }
                }
                // health, kept minimal
                Column(Modifier.padding(horizontal = 24.dp).clip(RoundedCornerShape(20.dp)).clickable { onDetail() }) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        T("Health " + (score * 100).toInt() + "%", 17, C.text, FontWeight.ExtraBold, Modifier.weight(1f))
                        Icon(Icons.Filled.LocalFireDepartment, null, tint = if (streak > 0) C.accent else C.steel, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(4.dp))
                        T(if (streak == 1) "1 day" else "$streak days", 16, if (streak > 0) C.text else C.steel, FontWeight.Bold)
                    }
                    Spacer(Modifier.height(6.dp))
                    HealthBar(score, height = 26.dp)
                }
            }

            // daily activity: hour by hour, in kcal
            val hours = remember(d.key, d.steps) { Steps.hours(d.key) }
            Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                T("DAILY ACTIVITY", 12, C.steel, FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                val tot = hours.sum()
                if (tot == 0) {
                    T("Hours fill in from today on. Days before this update only have a total.", 13, C.steel)
                } else {
                    val per = hours.map { it * kcal.toFloat() / tot }
                    Bars(per, emptyList(), -1, height = 90.dp, allHi = true)
                    Spacer(Modifier.height(4.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        for (l in listOf("00:00", "06:00", "12:00", "18:00")) T(l, 11, C.steel, FontWeight.Bold)
                    }
                    val pk = hours.indices.maxByOrNull { hours[it] } ?: 0
                    Spacer(Modifier.height(6.dp))
                    T("Busiest hour: " + hourText(pk) + ", about " + nf(per[pk].toInt()) + " kcal", 13, C.text, FontWeight.Bold)
                }
            }
            // steps / distance / active / cadence
            Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                val km = d.steps * Steps.strideM() / 1000.0
                Row(Modifier.fillMaxWidth()) {
                    StatBig("Steps", nf(d.steps), "", Modifier.weight(1f))
                    StatBig("Distance", Fmt.f2(km), "KM", Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth()) {
                    StatBig("Active", d.activeMin.toString(), "MIN", Modifier.weight(1f))
                    StatBig("Cadence", if (d.activeMin > 0) (d.steps / d.activeMin).toString() else "-", "/MIN", Modifier.weight(1f))
                }
            }

            // history
            Segmented(listOf("7 days", "30 days"), range) { range = it }
            Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                val days = if (range == 0) days30.takeLast(7) else days30
                val labels = days.map { x -> if (range == 0) SimpleDateFormat("EEE", Locale.getDefault()).format(Date(parseKey(x.key))).take(2) else "" }
                val selIdx = days.indexOfFirst { it.key == selKey }
                Bars(days.map { it.steps.toFloat() }, labels, if (selIdx >= 0) selIdx else days.size - 1, height = 130.dp,
                    onTap = { i -> onSel(days[i].key); scope.launch { sc.animateScrollTo(0) } })
                Spacer(Modifier.height(4.dp))
                T("Tap a bar to see that day", 12, C.steel)
                Spacer(Modifier.height(8.dp))
                val avg = if (days.isEmpty()) 0 else days.sumOf { it.steps } / days.size
                T("Average " + nf(avg) + " steps a day", 14, C.steel, FontWeight.Medium)
            }
            Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                T("PREVIOUS DAYS", 12, C.steel, FontWeight.Bold)
                T("Tap a day to see its ring", 12, C.steel)
                Spacer(Modifier.height(6.dp))
                for (x in days30.reversed()) {
                    val on = x.key == selKey
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (on) C.card2 else androidx.compose.ui.graphics.Color.Transparent)
                            .clickable { onSel(x.key); scope.launch { sc.animateScrollTo(0) } }.padding(horizontal = 8.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        T(niceDay(x.key), 15, C.text, FontWeight.Medium, Modifier.weight(1f))
                        T(nf(x.steps) + " steps", 14, C.text, FontWeight.Medium, Modifier.width(104.dp), TextAlign.End)
                        T(nf(Cal.forDay(x, runs)) + " kcal", 13, C.steel, modifier = Modifier.width(78.dp), align = TextAlign.End)
                    }
                }
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
private fun Spec(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        T(label, 14, C.steel, FontWeight.Medium, Modifier.weight(1f))
        Text(value, color = C.text, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun Meter(label: String, frac: Float, text: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth()) {
            T(label, 14, C.text, FontWeight.Bold, Modifier.weight(1f))
            Text(text, color = C.steelLt, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
        Spacer(Modifier.height(6.dp))
        FillBar(frac, height = 18.dp, color = if (frac >= 1f) C.green else C.accent)
    }
}

/** Everything about one day: health first, then the numbers. */
@Composable
private fun MoveDetail(d: Day, runs: List<Summary>, onBack: () -> Unit) {
    val kg = Cal.kg()
    val stride = Steps.strideM()
    val km = d.steps * stride / 1000.0
    val kcal = Cal.forDay(d, runs)
    val score = Cal.score(d, runs)
    val goal = Steps.goal()
    val kg2 = Cal.goal()
    val dayRuns = runs.filter { Steps.key(it.start) == d.key }
    val runKm = dayRuns.sumOf { it.distM } / 1000.0
    val walkKcal = (0.57 * kg * km).toInt()
    val runKcal = (0.43 * kg * runKm).toInt()
    val hours = remember(d.key, d.steps) { Steps.hours(d.key) }
    val streak = remember(d.key) { Cal.streak(runs) }
    val isToday = d.key == Steps.key()
    val nowH = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(niceDay(d.key), onBack)

        Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                T("Health", 20, C.text, FontWeight.Bold, Modifier.weight(1f))
                T((score * 100).toInt().toString() + "%", 26, C.text, FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            HealthBar(score, height = 32.dp)
            Spacer(Modifier.height(10.dp))
            Meter("Steps", d.steps.toFloat() / goal, nf(d.steps) + " / " + nf(goal))
            Meter("Calories", kcal.toFloat() / kg2, nf(kcal) + " / " + nf(kg2) + " kcal")
            Meter("Active time", d.activeMin.toFloat() / Cal.ACTIVE_GOAL, d.activeMin.toString() + " / " + Cal.ACTIVE_GOAL + " min")
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.LocalFireDepartment, null, tint = if (streak > 0) C.accent else C.steel, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(6.dp))
                T(if (streak == 1) "1 day streak" else "$streak day streak", 16, if (streak > 0) C.text else C.steel, FontWeight.Bold)
            }
            Spacer(Modifier.height(4.dp))
            T("A day counts for the streak when you reach your steps goal or your calorie goal.", 12, C.steel)
        }

        Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
            T("THE NUMBERS", 12, C.steel, FontWeight.Bold)
            Spec("Steps", nf(d.steps))
            Spec("Distance", Fmt.f2(km) + " km")
            Spec("Stride", Fmt.f2(stride) + " m" + if (Prefs.i("height_cm", 0) > 0) " (from height)" else "")
            Spec("Active time", d.activeMin.toString() + " min")
            Spec("Cadence", if (d.activeMin > 0) (d.steps / d.activeMin).toString() + " steps/min" else "-")
            Spec("Active pace", if (km > 0.05 && d.activeMin > 0) paceText(d.activeMin * 60.0 / km) + " /km" else "-")
            Spec("Calories", nf(kcal) + " kcal")
            Spec("Per 1,000 steps", if (d.steps > 0) (kcal * 1000 / d.steps).toString() + " kcal" else "-")
            Spec("Weight used", (if (Cal.weight() > 0f) Fmt.f1(kg) else "70") + " kg" + if (Cal.weight() > 0f) "" else " (default)")
            Spec("Steps goal", (d.steps * 100 / goal.coerceAtLeast(1)).toString() + "%")
            Spec("Calorie goal", (kcal * 100 / kg2.coerceAtLeast(1)).toString() + "%")
        }

        Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
            T("HOW CALORIES ARE WORKED OUT", 12, C.steel, FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                "walk  0.57 x " + Fmt.f1(kg) + " kg x " + Fmt.f2(km) + " km = " + walkKcal + "\n" +
                    (if (dayRuns.isNotEmpty()) "runs  0.43 x " + Fmt.f1(kg) + " kg x " + Fmt.f2(runKm) + " km = +" + runKcal + "\n" else "") +
                    "total " + kcal + " kcal",
                color = C.steelLt, fontSize = 13.sp, fontFamily = FontFamily.Monospace, lineHeight = 20.sp
            )
            Spacer(Modifier.height(6.dp))
            T("An estimate: walking costs about 0.57 kcal per kg per km, and running about 1.0. Runs you record add the extra.", 12, C.steel)
            if (dayRuns.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                T(dayRuns.size.toString() + (if (dayRuns.size == 1) " run" else " runs") + " that day, " + Fmt.f2(runKm) + " km", 13, C.text, FontWeight.Bold)
            }
        }

        Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
            T("HOUR BY HOUR", 12, C.steel, FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (hours.sum() == 0) {
                T("Hours fill in from today on. Days before this update only have a total.", 13, C.steel)
            } else {
                Bars(hours.map { it.toFloat() }, emptyList(), if (isToday) nowH else -1, height = 110.dp)
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    for (l in listOf("12am", "6am", "12pm", "6pm", "12am")) T(l, 11, C.steel, FontWeight.Medium)
                }
                val pk = hours.indices.maxByOrNull { hours[it] } ?: 0
                Spacer(Modifier.height(6.dp))
                T("Busiest hour: " + hourText(pk) + " with " + nf(hours[pk]) + " steps", 13, C.text, FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

private fun paceText(secPerKm: Double): String {
    val s = secPerKm.toInt()
    return (s / 60).toString() + ":" + String.format(Locale.US, "%02d", s % 60)
}

private fun hourText(h: Int): String = (if (h % 12 == 0) 12 else h % 12).toString() + (if (h < 12) " am" else " pm")
