package com.breadwinner.wavestride

import android.Manifest
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun RecordScreen(autoStart: Boolean, onAutoDone: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val live by RunState.flow.collectAsState()
    val fix by Gps.last.collectAsState()
    val cam = remember { MapCam(zoom0 = 16.0).also { val a = Areas.current(); it.center(a.lat, a.lon) } }
    var follow by remember { mutableStateOf(true) }
    var locOk by remember { mutableStateOf(Gps.hasPermission()) }
    var walkMode by remember { mutableStateOf(Prefs.b("walk_mode", false)) }
    var askGps by remember { mutableStateOf(false) }
    var finishAsk by remember { mutableStateOf(false) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var voiceOn by remember { mutableStateOf(Prefs.b("voice", false)) }

    val locLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        locOk = Gps.hasPermission()
        Gps.retry()
    }

    DisposableEffect(Unit) {
        Gps.acquire()
        onDispose { Gps.release() }
    }
    LaunchedEffect(Unit) { while (true) { delay(1000); now = System.currentTimeMillis(); Gps.retry() } }
    LaunchedEffect(fix, follow) {
        val f = fix
        if (follow && f != null) cam.center(f.latitude, f.longitude)
    }

    val active = live.st != St.IDLE
    val view = LocalView.current
    DisposableEffect(active) {
        view.keepScreenOn = active && Prefs.b("awake", true)
        onDispose { view.keepScreenOn = false }
    }

    fun tryStart() {
        if (!locOk) { locLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)); return }
        if (!Gps.enabled()) { askGps = true; return }
        follow = true
        RunService.send(ctx, "START")
    }

    LaunchedEffect(autoStart, locOk) {
        if (autoStart && live.st == St.IDLE && live.countdown == 0) {
            onAutoDone()
            tryStart()
        }
    }

    val f = fix
    val tick = now // re-check every second
    val liveGps = Gps.gpsAt != 0L && android.os.SystemClock.elapsedRealtime() - Gps.gpsAt <= 20000L
    val gpsText = when {
        !locOk -> "Location not allowed"
        !Gps.enabled() -> "Location is switched off"
        liveGps && f != null -> "GPS ready · within " + f.accuracy.toInt() + " m"
        f != null -> "Rough position (about " + f.accuracy.toInt() + " m) · waiting for GPS"
        else -> "Finding GPS… step outside, a roof or walls block it"
    }
    val gpsGood = locOk && liveGps

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                MapView(
                    cam, Modifier.fillMaxSize(),
                    route = if (active) RunState.pts else null,
                    ver = live.ver,
                    youLat = f?.latitude ?: Double.NaN,
                    youLon = f?.longitude ?: Double.NaN,
                    onMoved = { follow = false }
                )
                Row(
                    Modifier.padding(12.dp).clip(RoundedCornerShape(20.dp)).background(C.bg.copy(alpha = 0.92f)).padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(if (gpsGood) C.green else C.steel))
                    Spacer(Modifier.width(8.dp))
                    T(gpsText, 12, C.text, FontWeight.Medium)
                }
                if (!active) {
                    Box(
                        Modifier.align(Alignment.TopEnd).padding(12.dp).size(40.dp).clip(CircleShape).background(C.bg.copy(alpha = 0.92f)).clickable { onClose() },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Filled.Close, null, tint = C.text) }
                }
                if (!follow) {
                    Box(
                        Modifier.align(Alignment.BottomEnd).padding(12.dp).size(46.dp).clip(CircleShape).background(C.card).clickable {
                            follow = true
                            val ff = fix
                            if (ff != null) cam.center(ff.latitude, ff.longitude)
                        },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Filled.MyLocation, null, tint = C.text) }
                }
            }

            Column(Modifier.fillMaxWidth().background(C.card).navigationBarsPadding().padding(horizontal = 18.dp, vertical = 14.dp)) {
                if (!active) {
                    if (!locOk) {
                        T("WaveStride needs your location to record runs.", 13, C.steelLt, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(10.dp))
                    }
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Box(
                            Modifier.size(96.dp).clip(CircleShape).background(C.go).clickable { tryStart() },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Filled.DirectionsRun, null, tint = C.onAccent, modifier = Modifier.size(38.dp))
                                T(if (locOk) "START" else "ALLOW", 12, C.onAccent, FontWeight.Bold)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GhostButton(
                            if (voiceOn) "Voice updates: on" else "Voice updates: off",
                            Modifier.weight(1f), Icons.Filled.VolumeUp
                        ) { voiceOn = !voiceOn; Prefs.put("voice", voiceOn) }
                        GhostButton(
                            Areas.current().name + " map",
                            Modifier.weight(1f), Icons.Filled.Map
                        ) { }
                    }
                    GhostButton(
                        if (walkMode) "Walk mode: on (saved as a walk)" else "Walk mode: off (saved as a run)",
                        Modifier.fillMaxWidth().padding(top = 10.dp), Icons.Filled.DirectionsWalk
                    ) { walkMode = !walkMode; Prefs.put("walk_mode", walkMode) }
                    NowPlayingCard(Modifier.padding(top = 10.dp))
                } else {
                    T("TIME", 11, C.steel, FontWeight.Bold)
                    T(Fmt.dur(live.ms), 58, C.text, FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Stat(Fmt.km(live.distM), "DISTANCE · km", big = true)
                        Stat(Fmt.pace(live.paceSec), "PACE · /km", big = true)
                        Stat(Fmt.pace(Fmt.paceOf(live.distM, live.ms)), "AVERAGE · /km", big = true)
                    }
                    NowPlayingCard(Modifier.padding(top = 10.dp))
                    Spacer(Modifier.height(14.dp))
                    if (live.st == St.RUNNING) {
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Box(
                                Modifier.size(80.dp).clip(CircleShape).background(C.go).clickable { RunService.send(ctx, "PAUSE") },
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Filled.Pause, null, tint = C.onAccent, modifier = Modifier.size(38.dp)) }
                        }
                    } else {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            PrimaryButton("Resume", Modifier.weight(1f), Icons.Filled.PlayArrow) { RunService.send(ctx, "RESUME") }
                            GhostButton("Finish", Modifier.weight(1f), Icons.Filled.Stop) { finishAsk = true }
                        }
                    }
                }
            }
        }

        if (live.countdown > 0) {
            Box(Modifier.fillMaxSize().background(C.bg.copy(alpha = 0.92f)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    T("GET READY", 14, C.steel, FontWeight.Bold)
                    T(live.countdown.toString(), 140, C.text, FontWeight.Bold)
                    GhostButton("Cancel", Modifier, null) { RunService.send(ctx, "DISCARD") }
                }
            }
        }
    }

    if (askGps) {
        AlertDialog(
            onDismissRequest = { askGps = false },
            confirmButton = {
                TextButton(onClick = {
                    askGps = false
                    try { ctx.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) } catch (e: Exception) { }
                }) { Text("Open settings", color = C.accent) }
            },
            dismissButton = { TextButton(onClick = { askGps = false }) { Text("Not now", color = C.steelLt) } },
            title = { Text("Switch location on", color = C.text) },
            text = { Text("Location is off, so WaveStride can't see where you run. Turn it on, then press Start again.", color = C.text) },
            containerColor = C.card
        )
    }

    if (finishAsk) {
        AlertDialog(
            onDismissRequest = { finishAsk = false },
            confirmButton = {
                TextButton(onClick = { finishAsk = false; RunService.send(ctx, "STOP") }) { Text("Save run", color = C.accent) }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { finishAsk = false; RunService.send(ctx, "DISCARD"); onClose() }) { Text("Discard", color = C.red) }
                    TextButton(onClick = { finishAsk = false }) { Text("Keep going", color = C.steelLt) }
                }
            },
            title = { Text("Finish this run?", color = C.text) },
            text = { Text(Fmt.km(live.distM) + " km in " + Fmt.dur(live.ms), color = C.text) },
            containerColor = C.card
        )
    }
}
