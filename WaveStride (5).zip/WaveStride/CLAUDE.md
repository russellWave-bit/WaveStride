# WaveStride — notes for Claude Code

Owner: BreadWinner (Russell), Harare. Phone-only (Samsung Galaxy Note 10 Plus), no PC. Keep replies short, warm, plain language. Call him "BreadWinner" now and then, never "Russell". Talk new ideas through first; build only when he says "build it". If something ends up smaller or different than he asked, say so plainly at the time.

## What it is
WaveStride: a personal Strava-style run tracker. No accounts, no social side, everything stays on the phone. Package `com.breadwinner.wavestride`, Kotlin + Jetpack Compose (BOM 2024.06.00, Material3), AGP 8.5.2, Kotlin 1.9.24, JDK 17, minSdk 29, target 34. No map or media libraries: maps, sharing and widgets are custom code.

## Building
No local Android compile is possible. GitHub Actions (`.github/workflows/build.yml`) builds on every push to `main`; the APK appears under Releases. Nothing has been compiled yet as of the first version: expect to fix a few compile errors from the "=== ERRORS ===" section of the build log. Check brackets/imports carefully before pushing.

## Files (app/src/main/java/com/breadwinner/wavestride)
- Data.kt: App/Prefs, models (Pt, Summary, Run), Fmt, Geo (mercator), Calc (best efforts, splits, climb), Runs (JSON storage + crash recovery), Stats, Tiers (personal ladder), Goals, Steps (step counter).
- Run.kt: Voice (TTS), Gps (shared GPS listener), RunState, RunService (foreground location service), StepsReceiver/StepsAlarm.
- Tiles.kt: OpenStreetMap tile cache, downloader, Areas (Harare default, other cities via presets or Nominatim search).
- Map.kt: MapView (pan/pinch, route, speed colours), RoutePreview, SpeedColors.
- Ui.kt: colours (object C), shared components (Shelf, SettingRow, SwitchRow, Chips, InfoDot, Ring, Bars...).
- MainActivity.kt (nav + bottom bar), Home.kt, Record.kt, Detail.kt, Move.kt (daily movement), You.kt (progress, records, tiers, goals), Settings.kt (More + offline Map screens).
- Share.kt: transparent route PNG and replay MP4 (MediaCodec, drawn in real time). Draw.kt: Android-canvas helpers.
- Music.kt: NotificationListener + MediaSession now-playing card and controls. Widgets.kt: five widgets drawn as bitmaps (steps, last run, week, start run, music).

## Decisions BreadWinner made
- Strava-like layout, steel grey and black with only a touch of orange. The map is Google-style (OSM standard) and does NOT follow the app colours.
- Route line: plain bright orange OR speed colours (setting). Crisp and solid, NEVER glowing, also on the picture and video.
- Home: first launch = big Start Run button; after that = preview of past runs. Thin movement strip at top that opens the Movement tab. Start Run is a round button in the bottom bar.
- Offline maps: Harare by default, option to pick another city. Missing tiles fetched on Wi-Fi only by default (he is data-limited).
- Spoken updates are an option (off by default), every 1/2/5 km.
- Personal tier ladder (Bronze to Diamond) per distance, against his own first effort. No leaderboards.
- Share: transparent PNG with stats, replay video. A transparent video is not possible on a phone, so video comes on a steel or green-screen background (told to him plainly).
- Five widgets: steps ring, last run, week chart, start run, music. Music card also on the run screen (needs notification access).
- Settings in labelled shelves with an icon beside every row; "i" info bubbles for anything complicated.

## Efficiency update (2026-11-15)
- StepService (Run.kt): foreground service type health, quiet MIN-priority notification, listens to TYPE_STEP_COUNTER all day, flushes to Steps.apply every 20 s. Setting "always_steps" (default on). Restarted from StepsReceiver (alarm/boot) and MainActivity.
- Manifest adds ACCESS_BACKGROUND_LOCATION, FOREGROUND_SERVICE_HEALTH, REQUEST_IGNORE_BATTERY_OPTIMIZATIONS. More > "Keep it tracking" shelf has the switch plus buttons to Location (all the time) and Battery (allow).
- Walk mode: pref `walk_mode`, toggle on the Record screen, only changes the saved title (Morning walk etc).
- GPS pill text explains indoors delay. Not compiled yet: check CI errors.

## Known limits / to check
- OSM tile policy discourages bulk downloads: downloads are capped to a small area (5/10/15 km), rate-limited, with a proper User-Agent. Keep it that way.
- Steps estimate active minutes and distance from the step counter; climb from GPS height is approximate.
- Samsung may kill recording with the screen off unless battery is set to Unrestricted (info bubble explains).
- Parked ideas: cycling, training plans, units in miles, auto-pause.

## Themes, calories, health bar (2026-11-18)
- Three themes in `Themes` (Ui.kt): Dark (steel + orange, default), Light (white with mint-to-leaf greens), Neon (matte black, lime/cyan/green). `C.*` are getters, so screens recolour at once. Setting `theme` (More > Look). `C.accent` = themed accent, `C.go` = Start/Record buttons, `C.route` = always plain orange. Draw.t* are themed colours for widgets; the old Draw constants stay fixed for the share picture/video.
- Bolder look: text weight bumped one step in `T()`, 2dp card borders, `Ring` strokes x1.45 with shaded sweep, thicker bars.
- Health.kt `Cal`: active kcal/day = 0.57 x kg x km walked (+0.43 x kg x km for recorded runs). Weight optional (70 kg if empty), height optional (also sets stride = 0.415 x height). Calorie goal chips 300-600. Health bar score = average of steps, calories, 30 active minutes. Streak = days in a row reaching the steps goal OR the calorie goal (today is free until it counts).
- Movement tab: calories ring, health bar card with streak; home strip shows steps + kcal. Sixth widget: HealthWidget.
- Kept simple on purpose (his words): no weight log, no calories-in. Not compiled yet: check CI errors.

## Movement redo (2026-11-18, from his sketch)
- Movement tab (Move.kt): Sun-first week strip (tap a day to see it), one big thick ring (`StepRing`: steps inside, kcal pill on the start of the arc), minimal health bar + streak under it; tap ring or health = full detail pane (health breakdown, nerdy numbers, calorie formula, hour by hour). 7/30-day chart and a tappable "Previous days" list sit below the fold with a parallax hero (swipe up).
- Home: `HomeRing` card uses the same `StepRing` plus health; tap opens Movement.
- Ring (Ui.kt) is now one solid colour (`C.ring.last()`) on a soft tinted track, stroke given by the caller. Rounded font: res/font/nunito.ttf (Nunito, OFL, variable) via `Round` in Ui.kt, used by `T()`.
- Hourly steps: Steps.hours(key), saved from this update on (older days have totals only). Pref "hours".
- Not compiled yet: check CI errors (likely spots: Font variationSettings opt-in, BoxWithConstraints scope).

## Whole-app restyle (2026-11-18)
- Every screen animates from zero on open: `rememberFill()` (Ui.kt) drives Ring, Bars, HealthBar, FillBar and the step/kcal counters. Tabs are re-composed on switch, so it replays each time.
- Material typography is rounded too (`roundTypography()` in MainActivity's MaterialTheme).
- Movement: mini-ring week strip, thick ring with arrow on arc start, "Move x/goal KCAL", hourly kcal "DAILY ACTIVITY", Steps/Distance/Active/Cadence block, no "swipe up" hint.
- Home: streak pill in header, ring card (health, kcal), week card, big last-run route card, recent runs.
- Widgets + logo restyled (2026-11-18): Draw.kt uses Nunito from assets/nunito.ttf via Typeface.Builder (variable 'wght'); Steps widget = thick ring + arrow + kcal; launcher icon = thick orange ring with arrow (dark #0B0D0F background); notification icon = ring arc.
