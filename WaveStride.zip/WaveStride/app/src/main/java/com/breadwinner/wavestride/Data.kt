package com.breadwinner.wavestride

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sinh
import kotlin.math.sqrt
import kotlin.math.atan2

/** The app-wide context, set once from every entry point (activity, service, receivers, widgets). */
object App {
    lateinit var ctx: Context
    fun init(c: Context) { if (!::ctx.isInitialized) ctx = c.applicationContext }
}

/** Small settings store. */
object Prefs {
    private fun sp() = App.ctx.getSharedPreferences("wavestride", Context.MODE_PRIVATE)
    fun b(k: String, d: Boolean): Boolean = sp().getBoolean(k, d)
    fun s(k: String, d: String): String = sp().getString(k, d) ?: d
    fun i(k: String, d: Int): Int = sp().getInt(k, d)
    fun f(k: String, d: Float): Float = sp().getFloat(k, d)
    fun l(k: String, d: Long): Long = sp().getLong(k, d)
    fun put(k: String, v: Any) {
        val e = sp().edit()
        when (v) {
            is Boolean -> e.putBoolean(k, v)
            is String -> e.putString(k, v)
            is Int -> e.putInt(k, v)
            is Float -> e.putFloat(k, v)
            is Long -> e.putLong(k, v)
            is Double -> e.putFloat(k, v.toFloat())
        }
        e.apply()
    }
}

/** A point on a run: position, height, moving time so far (ms) and distance so far (m). */
class Pt(val lat: Double, val lon: Double, val alt: Double, val mt: Long, val d: Double)

class Summary(
    val id: Long,
    val start: Long,
    val durMs: Long,
    val distM: Double,
    val gainM: Double,
    val mini: List<DoubleArray>,
    val best: Map<Int, Long>,
    val title: String
)

class Run(val sum: Summary, val pts: List<Pt>)

class Split(val km: Int, val distM: Double, val ms: Long)

object Fmt {
    fun f2(x: Double): String = String.format(Locale.US, "%.2f", x)
    fun f1(x: Double): String = String.format(Locale.US, "%.1f", x)
    fun km(m: Double): String = f2(m / 1000.0)
    fun dur(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec) else String.format(Locale.US, "%d:%02d", m, sec)
    }
    fun pace(secPerKm: Double): String {
        if (secPerKm <= 0.0 || secPerKm.isNaN() || secPerKm > 3600.0) return "--:--"
        val s = secPerKm.roundToInt()
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }
    fun paceOf(distM: Double, ms: Long): Double = if (distM < 10.0) 0.0 else ms / 1000.0 / (distM / 1000.0)
    fun date(ms: Long): String = SimpleDateFormat("EEE d MMM yyyy · HH:mm", Locale.getDefault()).format(Date(ms))
    fun dayMonth(ms: Long): String = SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(ms))
    fun title(start: Long): String {
        val c = Calendar.getInstance()
        c.timeInMillis = start
        val h = c.get(Calendar.HOUR_OF_DAY)
        val w = if (Prefs.b("walk_mode", false)) "walk" else "run"
        return when {
            h < 5 -> "Night $w"
            h < 12 -> "Morning $w"
            h < 17 -> "Afternoon $w"
            h < 21 -> "Evening $w"
            else -> "Night $w"
        }
    }
    fun spokenTime(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        val parts = ArrayList<String>()
        if (h > 0) parts.add("$h hour" + if (h == 1L) "" else "s")
        if (m > 0) parts.add("$m minute" + if (m == 1L) "" else "s")
        if (sec > 0 || parts.isEmpty()) parts.add("$sec second" + if (sec == 1L) "" else "s")
        return parts.joinToString(" ")
    }
    fun spokenPace(secPerKm: Double): String {
        if (secPerKm <= 0.0 || secPerKm.isNaN()) return ""
        val s = secPerKm.roundToInt()
        return "${s / 60} minutes ${s % 60} seconds per kilometre"
    }
}

object Geo {
    fun dist(a1: Double, o1: Double, a2: Double, o2: Double): Double {
        val r = 6371000.0
        val p1 = Math.toRadians(a1)
        val p2 = Math.toRadians(a2)
        val dp = p2 - p1
        val dl = Math.toRadians(o2 - o1)
        val a = sin(dp / 2) * sin(dp / 2) + cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2)
        return r * 2 * atan2(sqrt(a), sqrt(1 - a))
    }
    /** Normalised web-mercator: 0..1 across the world. */
    fun mx(lon: Double): Double = (lon + 180.0) / 360.0
    fun my(lat: Double): Double {
        val s = sin(Math.toRadians(lat)).coerceIn(-0.9999, 0.9999)
        return 0.5 - ln((1 + s) / (1 - s)) / (4 * PI)
    }
    fun lonOf(x: Double): Double = x * 360.0 - 180.0
    fun latOf(y: Double): Double = Math.toDegrees(atan(sinh(PI * (1 - 2 * y))))
}

object Calc {
    /** Fastest time (ms) over any stretch of [dist] metres inside the run, or -1. */
    fun bestEffort(p: List<Pt>, dist: Double): Long {
        if (p.size < 2 || p.last().d < dist) return -1
        var best = Long.MAX_VALUE
        var j = 0
        for (i in 1 until p.size) {
            while (j + 1 < i && p[i].d - p[j + 1].d >= dist) j++
            if (p[i].d - p[j].d >= dist) {
                val target = p[i].d - dist
                val a = p[j]
                val b = p[j + 1]
                val f = if (b.d - a.d > 0) (target - a.d) / (b.d - a.d) else 0.0
                val tStart = a.mt + ((b.mt - a.mt) * f).toLong()
                val t = p[i].mt - tStart
                if (t > 0 && t < best) best = t
            }
        }
        return if (best == Long.MAX_VALUE) -1 else best
    }

    fun splits(p: List<Pt>): List<Split> {
        val out = ArrayList<Split>()
        if (p.size < 2) return out
        var nextD = 1000.0
        var lastT = 0L
        var lastD = 0.0
        var k = 1
        for (i in 1 until p.size) {
            val a = p[i - 1]
            val b = p[i]
            while (b.d >= nextD && b.d > a.d) {
                val f = (nextD - a.d) / (b.d - a.d)
                val t = a.mt + ((b.mt - a.mt) * f).toLong()
                out.add(Split(k, 1000.0, t - lastT))
                lastT = t
                lastD = nextD
                k++
                nextD += 1000.0
            }
        }
        val endD = p.last().d
        val endT = p.last().mt
        if (endD - lastD >= 100.0) out.add(Split(k, endD - lastD, endT - lastT))
        return out
    }

    /** Climb, roughly: smoothed height, ignoring wobbles under 3 m. GPS height is rough, so this is approximate. */
    fun gain(p: List<Pt>): Double {
        if (p.size < 5) return 0.0
        val sm = DoubleArray(p.size) { i ->
            var s = 0.0
            var c = 0
            for (j in max(0, i - 4)..min(p.size - 1, i + 4)) { s += p[j].alt; c++ }
            s / c
        }
        var g = 0.0
        var ref = sm[0]
        for (v in sm) {
            if (v - ref >= 3.0) { g += v - ref; ref = v } else if (ref - v >= 3.0) { ref = v }
        }
        return g
    }

    fun mini(p: List<Pt>): List<DoubleArray> {
        if (p.isEmpty()) return emptyList()
        val n = 90
        val out = ArrayList<DoubleArray>()
        if (p.size <= n) { for (x in p) out.add(doubleArrayOf(x.lat, x.lon)); return out }
        for (i in 0 until n) {
            val x = p[(i.toLong() * (p.size - 1) / (n - 1)).toInt()]
            out.add(doubleArrayOf(x.lat, x.lon))
        }
        return out
    }
}

val EFFORTS = listOf(1000 to "1 km", 5000 to "5 km", 10000 to "10 km", 21097 to "Half marathon")

object Runs {
    private var cache: MutableList<Summary>? = null
    private fun dir(): File = File(App.ctx.filesDir, "runs").also { it.mkdirs() }

    private fun toJson(s: Summary): JSONObject {
        val o = JSONObject()
        o.put("id", s.id); o.put("start", s.start); o.put("dur", s.durMs); o.put("dist", s.distM)
        o.put("gain", s.gainM); o.put("title", s.title)
        val m = JSONArray()
        for (q in s.mini) m.put(JSONArray().put(q[0]).put(q[1]))
        o.put("mini", m)
        val b = JSONObject()
        for ((k, v) in s.best) b.put(k.toString(), v)
        o.put("best", b)
        return o
    }

    private fun fromJson(o: JSONObject): Summary {
        val mini = ArrayList<DoubleArray>()
        val m = o.optJSONArray("mini")
        if (m != null) for (i in 0 until m.length()) { val q = m.getJSONArray(i); mini.add(doubleArrayOf(q.getDouble(0), q.getDouble(1))) }
        val best = HashMap<Int, Long>()
        val b = o.optJSONObject("best")
        if (b != null) { val it = b.keys(); while (it.hasNext()) { val k = it.next(); best[k.toInt()] = b.getLong(k) } }
        return Summary(o.getLong("id"), o.getLong("start"), o.getLong("dur"), o.getDouble("dist"), o.optDouble("gain", 0.0), mini, best, o.optString("title", "Run"))
    }

    fun list(): List<Summary> {
        cache?.let { return it }
        val out = ArrayList<Summary>()
        try {
            val f = File(dir(), "index.json")
            if (f.exists()) {
                val a = JSONArray(f.readText())
                for (i in 0 until a.length()) out.add(fromJson(a.getJSONObject(i)))
            }
        } catch (e: Exception) { }
        out.sortByDescending { it.start }
        cache = out
        return out
    }

    private fun writeIndex() {
        try {
            val a = JSONArray()
            for (s in list()) a.put(toJson(s))
            File(dir(), "index.json").writeText(a.toString())
        } catch (e: Exception) { }
    }

    fun build(start: Long, ms: Long, pts: List<Pt>): Run {
        val dist = pts.lastOrNull()?.d ?: 0.0
        val best = HashMap<Int, Long>()
        for ((d, _) in EFFORTS) { val t = Calc.bestEffort(pts, d.toDouble()); if (t > 0) best[d] = t }
        return Run(Summary(start, start, ms, dist, Calc.gain(pts), Calc.mini(pts), best, Fmt.title(start)), pts)
    }

    fun save(r: Run) {
        try {
            val a = JSONArray()
            for (p in r.pts) a.put(JSONArray().put(p.lat).put(p.lon).put(p.alt).put(p.mt).put(p.d))
            File(dir(), "${r.sum.id}.json").writeText(a.toString())
        } catch (e: Exception) { }
        val l = list() as MutableList<Summary>
        l.removeAll { it.id == r.sum.id }
        l.add(r.sum)
        l.sortByDescending { it.start }
        writeIndex()
    }

    fun load(id: Long): Run? {
        val s = list().firstOrNull { it.id == id } ?: return null
        return try {
            val a = JSONArray(File(dir(), "$id.json").readText())
            val pts = ArrayList<Pt>(a.length())
            for (i in 0 until a.length()) {
                val q = a.getJSONArray(i)
                pts.add(Pt(q.getDouble(0), q.getDouble(1), q.getDouble(2), q.getLong(3), q.getDouble(4)))
            }
            Run(s, pts)
        } catch (e: Exception) { null }
    }

    fun delete(id: Long) {
        (list() as MutableList<Summary>).removeAll { it.id == id }
        try { File(dir(), "$id.json").delete() } catch (e: Exception) { }
        writeIndex()
    }

    // ----- a run in progress is copied to disk now and then, so a crash or a killed app doesn't lose it -----
    private fun liveFile() = File(dir(), "live.json")

    fun saveLive(start: Long, ms: Long, pts: List<Pt>) {
        try {
            val o = JSONObject()
            o.put("start", start); o.put("ms", ms)
            val a = JSONArray()
            for (p in pts) a.put(JSONArray().put(p.lat).put(p.lon).put(p.alt).put(p.mt).put(p.d))
            o.put("pts", a)
            liveFile().writeText(o.toString())
        } catch (e: Exception) { }
    }

    fun clearLive() { try { liveFile().delete() } catch (e: Exception) { } }

    /** If the app was killed mid-run, keep what was recorded. Returns the saved run's id, or 0. */
    fun recoverLive(): Long {
        val f = liveFile()
        if (!f.exists()) return 0
        return try {
            val o = JSONObject(f.readText())
            val a = o.getJSONArray("pts")
            val pts = ArrayList<Pt>()
            for (i in 0 until a.length()) {
                val q = a.getJSONArray(i)
                pts.add(Pt(q.getDouble(0), q.getDouble(1), q.getDouble(2), q.getLong(3), q.getDouble(4)))
            }
            f.delete()
            if (pts.size < 2 || pts.last().d < 100.0) return 0
            val r = build(o.getLong("start"), o.getLong("ms"), pts)
            save(r)
            r.sum.id
        } catch (e: Exception) { try { f.delete() } catch (x: Exception) { }; 0 }
    }
}

object Stats {
    fun dayStart(t: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = t
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }
    fun weekStart(t: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = dayStart(t)
        val dow = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7   // Monday = 0
        c.add(Calendar.DAY_OF_MONTH, -dow)
        return c.timeInMillis
    }
    fun monthStart(t: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = dayStart(t)
        c.set(Calendar.DAY_OF_MONTH, 1)
        return c.timeInMillis
    }
    fun yearStart(t: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = dayStart(t)
        c.set(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }
    fun addDays(t: Long, n: Int): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = t
        c.add(Calendar.DAY_OF_MONTH, n)
        return c.timeInMillis
    }
    fun inRange(l: List<Summary>, from: Long, to: Long): List<Summary> = l.filter { it.start in from until to }
    fun km(l: List<Summary>): Double = l.sumOf { it.distM } / 1000.0
    /** Distance (km) per day for [days] days starting at [from]. */
    fun perDay(l: List<Summary>, from: Long, days: Int): DoubleArray {
        val out = DoubleArray(days)
        for (i in 0 until days) {
            val a = addDays(from, i)
            val b = addDays(from, i + 1)
            out[i] = km(inRange(l, a, b))
        }
        return out
    }
    /** Distance (km) per week for the last [weeks] weeks, oldest first. */
    fun perWeek(l: List<Summary>, weeks: Int): DoubleArray {
        val ws = weekStart(System.currentTimeMillis())
        val out = DoubleArray(weeks)
        for (i in 0 until weeks) {
            val a = addDays(ws, -7 * (weeks - 1 - i))
            val b = addDays(a, 7)
            out[i] = km(inRange(l, a, b))
        }
        return out
    }
}

class Tier(val name: String, val color: Long, val factor: Double)

/** Your personal ladder: your first effort at a distance is the starting line; each tier is a step faster than that. */
object Tiers {
    val all = listOf(
        Tier("Bronze", 0xFFB07A3F, 1.00),
        Tier("Silver", 0xFFB7BDC4, 0.97),
        Tier("Gold", 0xFFE0B032, 0.93),
        Tier("Platinum", 0xFF8FB8C8, 0.88),
        Tier("Diamond", 0xFF7FE3F0, 0.80)
    )
    fun baseline(l: List<Summary>, d: Int): Long {
        val first = l.filter { it.best.containsKey(d) }.minByOrNull { it.start } ?: return -1
        return first.best[d] ?: -1
    }
    fun pb(l: List<Summary>, d: Int): Long {
        var b = Long.MAX_VALUE
        for (s in l) { val t = s.best[d]; if (t != null && t < b) b = t }
        return if (b == Long.MAX_VALUE) -1 else b
    }
    /** Index of the highest tier reached, or -1 if no effort yet. */
    fun level(l: List<Summary>, d: Int): Int {
        val base = baseline(l, d)
        val pb = pb(l, d)
        if (base < 0 || pb < 0) return -1
        var lv = 0
        for (i in all.indices) if (pb <= base * all[i].factor + 0.5) lv = i
        return lv
    }
    fun target(l: List<Summary>, d: Int, lv: Int): Long {
        val base = baseline(l, d)
        if (base < 0 || lv + 1 >= all.size) return -1
        return (base * all[lv + 1].factor).toLong()
    }
}

class Goal(val id: Long, val type: String, val period: String, val target: Double)

object Goals {
    fun load(): List<Goal> {
        val out = ArrayList<Goal>()
        try {
            val a = JSONArray(Prefs.s("goals", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Goal(o.getLong("id"), o.getString("type"), o.getString("period"), o.getDouble("target")))
            }
        } catch (e: Exception) { }
        return out
    }
    fun save(l: List<Goal>) {
        val a = JSONArray()
        for (g in l) a.put(JSONObject().put("id", g.id).put("type", g.type).put("period", g.period).put("target", g.target))
        Prefs.put("goals", a.toString())
    }
    /** How far along a goal is right now (km, or number of runs). */
    fun progress(g: Goal, l: List<Summary>): Double {
        val now = System.currentTimeMillis()
        val from = if (g.period == "week") Stats.weekStart(now) else Stats.monthStart(now)
        val r = Stats.inRange(l, from, Long.MAX_VALUE)
        return if (g.type == "km") Stats.km(r) else r.size.toDouble()
    }
}

class Day(val key: String, val steps: Int, val activeMin: Int)

/** Daily movement from the phone's own step counter. No GPS, very light on battery. */
object Steps {
    fun key(t: Long = System.currentTimeMillis()): String {
        val c = Calendar.getInstance()
        c.timeInMillis = t
        return String.format(Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    private fun load(): JSONObject = try { JSONObject(Prefs.s("steps", "{}")) } catch (e: Exception) { JSONObject() }

    fun day(k: String): Day {
        val a = load().optJSONArray(k)
        return if (a == null) Day(k, 0, 0) else Day(k, a.optInt(0), a.optInt(1) / 10)
    }
    fun today(): Day = day(key())

    /** The last [n] days, oldest first. */
    fun days(n: Int): List<Day> {
        val o = load()
        val out = ArrayList<Day>()
        val now = System.currentTimeMillis()
        for (i in n - 1 downTo 0) {
            val k = key(Stats.addDays(now, -i))
            val a = o.optJSONArray(k)
            out.add(if (a == null) Day(k, 0, 0) else Day(k, a.optInt(0), a.optInt(1) / 10))
        }
        return out
    }

    fun strideM(): Double = Prefs.f("stride", 0.75f).toDouble()
    fun goal(): Int = Prefs.i("stepgoal", 8000)

    private fun add(steps: Int, active: Double, now: Long) {
        val o = load()
        val k = key(now)
        val a = o.optJSONArray(k)
        val s = (a?.optInt(0) ?: 0) + steps
        val m = (a?.optInt(1) ?: 0) + (active * 10).toInt()
        o.put(k, JSONArray().put(s).put(m))
        // keep about a year
        if (o.length() > 400) {
            val keys = ArrayList<String>()
            val it = o.keys()
            while (it.hasNext()) keys.add(it.next())
            keys.sort()
            for (i in 0 until keys.size - 380) o.remove(keys[i])
        }
        Prefs.put("steps", o.toString())
    }

    fun allowed(): Boolean =
        androidx.core.content.ContextCompat.checkSelfPermission(App.ctx, android.Manifest.permission.ACTIVITY_RECOGNITION) == android.content.pm.PackageManager.PERMISSION_GRANTED

    fun apply(v: Float) {
        val now = System.currentTimeMillis()
        val last = Prefs.f("sc_last", -1f)
        val lt = Prefs.l("sc_time", 0L)
        Prefs.put("sc_last", v)
        Prefs.put("sc_time", now)
        if (last < 0f) return   // first reading only sets the starting line
        var d = v - last
        if (d < 0f) d = v       // the phone restarted, the counter began again
        if (d <= 0f || d > 60000f) return
        val dtMin = ((now - lt) / 60000.0).coerceAtLeast(0.5)
        val active = if (d / dtMin >= 40.0) min(dtMin, d / 105.0) else 0.0
        add(d.toInt(), active, now)
    }

    /** Read the counter once, update today's total, then call [done] on the main thread. */
    fun snapshot(done: (() -> Unit)? = null) {
        val sm = App.ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val s = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        if (s == null) { done?.invoke(); return }
        var got = false
        val h = Handler(Looper.getMainLooper())
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                if (got) return
                got = true
                sm.unregisterListener(this)
                try { apply(e.values[0]) } catch (x: Exception) { }
                done?.invoke()
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        val ok = try { sm.registerListener(l, s, SensorManager.SENSOR_DELAY_NORMAL) } catch (e: Exception) { false }
        if (!ok) { done?.invoke(); return }
        h.postDelayed({
            if (!got) { got = true; sm.unregisterListener(l); done?.invoke() }
        }, 4000)
    }
}
