package com.breadwinner.wavestride

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun DetailScreen(id: Long, fresh: Boolean, onBack: () -> Unit, onDeleted: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val run = remember(id) { Runs.load(id) }
    if (run == null) {
        Column(Modifier.fillMaxSize()) {
            Header("Run", onBack)
            Empty("This run could not be opened.")
        }
        return
    }
    val s = run.sum
    val cam = remember(id) { MapCam(zoom0 = 14.0).also { c -> run.pts.firstOrNull()?.let { c.center(it.lat, it.lon) } } }
    var speedStyle by remember { mutableStateOf(Prefs.i("route_speed", 0)) }
    val colors = remember(id) { SpeedColors.forRoute(run.pts) }
    var askDelete by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf("") }
    var pct by remember { mutableStateOf(0) }
    var ready by remember { mutableStateOf<ShareFile?>(null) }
    var failed by remember { mutableStateOf(false) }
    var showStats by remember { mutableStateOf(true) }

    val splits = remember(id) { Calc.splits(run.pts) }
    val fastest = splits.filter { it.distM >= 900.0 }.minOfOrNull { Fmt.paceOf(it.distM, it.ms) } ?: 0.0
    val all = remember { Runs.list() }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Header(if (fresh) "Run saved" else "Run", onBack) {
                Box(Modifier.size(40.dp).clip(CircleShape).clickable { askDelete = true }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Delete, null, tint = C.steelLt)
                }
            }
            MapView(
                cam, Modifier.fillMaxWidth().height(300.dp),
                route = run.pts, colors = if (speedStyle == 1) colors else null,
                fitRoute = true
            )
            Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
                T(s.title, 24, C.text, FontWeight.Bold)
                T(Fmt.date(s.start), 13, C.steel)
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth()) {
                    Stat(Fmt.km(s.distM), "Distance · km", Modifier.weight(1f), big = true)
                    Stat(Fmt.dur(s.durMs), "Moving time", Modifier.weight(1f), big = true)
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth()) {
                    Stat(Fmt.pace(Fmt.paceOf(s.distM, s.durMs)), "Average pace · /km", Modifier.weight(1f), big = true)
                    Stat(s.gainM.toInt().toString() + " m", "Climb (approx.)", Modifier.weight(1f), big = true)
                }
            }

            Shelf("Route look", Icons.Filled.Palette) {
                Chips(listOf("Plain orange", "Speed colours"), speedStyle, { speedStyle = it; Prefs.put("route_speed", it) })
                if (speedStyle == 1) {
                    Box(Modifier.padding(horizontal = 14.dp).padding(bottom = 12.dp)) { SpeedLegend() }
                }
            }

            if (splits.isNotEmpty()) {
                Card(Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                    T("SPLITS", 11, C.steel, FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    for (sp in splits) {
                        val p = Fmt.paceOf(sp.distM, sp.ms)
                        val frac = if (fastest > 0 && p > 0) (fastest / p).toFloat().coerceIn(0.2f, 1f) else 0.5f
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            T(if (sp.distM >= 900.0) sp.km.toString() else Fmt.f2(sp.distM / 1000.0), 13, C.steelLt, modifier = Modifier.width(40.dp))
                            Box(Modifier.weight(1f)) {
                                Box(Modifier.fillMaxWidth(frac).height(14.dp).clip(RoundedCornerShape(4.dp)).background(if (p == fastest) C.orange else C.steel))
                            }
                            T(Fmt.pace(p), 13, C.text, FontWeight.Medium, Modifier.width(58.dp), align = androidx.compose.ui.text.style.TextAlign.End)
                        }
                    }
                }
            }

            if (s.best.isNotEmpty()) {
                Card(Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                    T("BEST EFFORTS IN THIS RUN", 11, C.steel, FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    for ((d, label) in EFFORTS) {
                        val t = s.best[d] ?: continue
                        val isPb = Tiers.pb(all, d) == t
                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            T(label, 14, C.text, modifier = Modifier.weight(1f))
                            if (isPb) {
                                Icon(Icons.Filled.EmojiEvents, null, tint = C.orange, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                T("PB  ", 12, C.orange, FontWeight.Bold)
                            }
                            T(Fmt.dur(t), 15, C.text, FontWeight.Bold)
                        }
                    }
                }
            }

            Shelf("Share", Icons.Filled.Share) {
                SwitchRow(Icons.Filled.Image, "Show numbers on the picture", null, null, showStats) { showStats = it }
                Rule()
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    GhostButton("Route picture · transparent PNG", Modifier.fillMaxWidth(), Icons.Filled.Image) {
                        if (busy.isEmpty()) scope.launch {
                            busy = "Making your picture"
                            val f = withContext(Dispatchers.IO) { Share.png(ctx, run, showStats) }
                            busy = ""
                            if (f == null) failed = true else ready = f
                        }
                    }
                    GhostButton("Replay video · steel background", Modifier.fillMaxWidth(), Icons.Filled.Videocam) {
                        if (busy.isEmpty()) scope.launch {
                            busy = "Making your video"; pct = 0
                            val f = withContext(Dispatchers.IO) { Share.video(ctx, run, false) { p -> pct = p } }
                            busy = ""
                            if (f == null) failed = true else ready = f
                        }
                    }
                    GhostButton("Replay video · green screen", Modifier.fillMaxWidth(), Icons.Filled.Videocam) {
                        if (busy.isEmpty()) scope.launch {
                            busy = "Making your video"; pct = 0
                            val f = withContext(Dispatchers.IO) { Share.video(ctx, run, true) { p -> pct = p } }
                            busy = ""
                            if (f == null) failed = true else ready = f
                        }
                    }
                    T(
                        "A see-through video isn't possible on a phone, so the video comes on a steel or green background. Use \"green screen\" (chroma key) in a video editor to lay the route over your own footage.",
                        12, C.steel
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }

        if (busy.isNotEmpty()) {
            Box(Modifier.fillMaxSize().background(Color(0xCC0B0D0F)), contentAlignment = Alignment.Center) {
                Card(Modifier.padding(32.dp)) {
                    T(busy, 16, C.text, FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    T(if (busy.contains("video")) "$pct%  ·  this takes about 10 seconds" else "One moment", 13, C.steel)
                }
            }
        }
    }

    if (askDelete) {
        AlertDialog(
            onDismissRequest = { askDelete = false },
            confirmButton = {
                TextButton(onClick = {
                    askDelete = false
                    Runs.delete(id)
                    Widgets.updateAll()
                    onDeleted()
                }) { Text("Delete", color = C.red) }
            },
            dismissButton = { TextButton(onClick = { askDelete = false }) { Text("Keep it", color = C.steelLt) } },
            title = { Text("Delete this run?", color = C.text) },
            text = { Text("It will be removed from your history and records. This can't be undone.", color = C.text) },
            containerColor = C.card
        )
    }

    val rf = ready
    if (rf != null) {
        AlertDialog(
            onDismissRequest = { ready = null },
            confirmButton = { TextButton(onClick = { Share.send(ctx, rf); ready = null }) { Text("Share", color = C.orange) } },
            dismissButton = {
                Row {
                    TextButton(onClick = { Share.save(ctx, rf); ready = null }) { Text("Save to phone", color = C.steelLt) }
                    TextButton(onClick = { ready = null }) { Text("Close", color = C.steelLt) }
                }
            },
            title = { Text("Ready", color = C.text) },
            text = { Text(if (rf.mime.startsWith("video")) "Your replay video is ready." else "Your route picture is ready.", color = C.text) },
            containerColor = C.card
        )
    }

    if (failed) {
        AlertDialog(
            onDismissRequest = { failed = false },
            confirmButton = { TextButton(onClick = { failed = false }) { Text("OK", color = C.orange) } },
            title = { Text("That didn't work", color = C.text) },
            text = { Text("This phone couldn't make that file. Try the picture instead, or try again.", color = C.text) },
            containerColor = C.card
        )
    }
}

@Composable
fun SpeedLegend() {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))) {
            val cs = listOf(0f, 0.2f, 0.4f, 0.6f, 0.8f, 1f)
            for (c in cs) Box(Modifier.weight(1f).height(8.dp).background(SpeedColors.at(c)))
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            T("Slower", 11, C.steel)
            T("Faster", 11, C.steel)
        }
    }
}
