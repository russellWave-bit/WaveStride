package com.breadwinner.wavestride

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun nf(n: Int): String = String.format(Locale.US, "%,d", n)

@Composable
fun MoveScreen() {
    var tick by remember { mutableStateOf(0) }
    var ok by remember { mutableStateOf(permGranted(Manifest.permission.ACTIVITY_RECOGNITION)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { g ->
        ok = g
        Steps.snapshot { tick++ }
    }
    LaunchedEffect(Unit) { Steps.snapshot { tick++ } }
    var range by remember { mutableStateOf(0) }

    val today = remember(tick) { Steps.today() }
    val goal = Steps.goal()
    val week = remember(tick) { Steps.days(7) }
    val month = remember(tick) { Steps.days(30) }
    val stride = Steps.strideM()
    val km = today.steps * stride / 1000.0

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Movement", null) { InfoDot("Steps come from your phone's own step counter, so it needs no GPS and barely touches the battery. It only counts while the phone is on you, and it started counting when you installed WaveStride. Active minutes and distance are estimates from your steps.") }

        if (!ok) {
            Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                T("Allow step counting", 16, C.text, FontWeight.Bold)
                T("Android needs your OK before WaveStride can read the step counter.", 13, C.steel)
                Spacer(Modifier.height(10.dp))
                PrimaryButton("Allow", Modifier.fillMaxWidth()) { launcher.launch(Manifest.permission.ACTIVITY_RECOGNITION) }
            }
        }

        Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Ring((today.steps.toFloat() / goal.coerceAtLeast(1)), 130.dp, 12.dp) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.DirectionsWalk, null, tint = C.steelLt, modifier = Modifier.size(20.dp))
                        T(nf(today.steps), 22, C.text, FontWeight.Bold)
                        T("steps", 11, C.steel)
                    }
                }
                Spacer(Modifier.width(18.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Stat(today.activeMin.toString() + " min", "Active today")
                    Stat(Fmt.f2(km) + " km", "Walked (estimate)")
                    T("Goal " + nf(goal) + " steps", 12, C.steel)
                }
            }
        }

        Segmented(listOf("7 days", "30 days"), range) { range = it }
        Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
            val days = if (range == 0) week else month
            val labels = days.map { d ->
                if (range == 0) SimpleDateFormat("EEE", Locale.getDefault()).format(Date(parseKey(d.key))).take(2)
                else ""
            }
            Bars(days.map { it.steps.toFloat() }, labels, days.size - 1, height = 120.dp)
            Spacer(Modifier.height(8.dp))
            val avg = if (days.isEmpty()) 0 else days.sumOf { it.steps } / days.size
            T("Average " + nf(avg) + " steps a day", 13, C.steel)
        }

        Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
            T("LAST 7 DAYS", 11, C.steel, FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            for (d in week.reversed()) {
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    T(SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(Date(parseKey(d.key))), 14, C.text, modifier = Modifier.weight(1f))
                    T(nf(d.steps) + " steps", 14, C.text, FontWeight.Medium, Modifier.width(110.dp), TextAlign.End)
                    T(d.activeMin.toString() + " min", 13, C.steel, modifier = Modifier.width(64.dp), align = TextAlign.End)
                }
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

private fun parseKey(k: String): Long = try {
    SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(k)?.time ?: 0L
} catch (e: Exception) { 0L }
