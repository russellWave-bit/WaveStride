package com.breadwinner.wavestride

import android.app.Notification
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.delay

class NowPlaying(val title: String, val artist: String, val playing: Boolean, val art: Bitmap?)

/**
 * Reads what any music app is playing and works its buttons. Android requires "notification access" for this;
 * WaveStride reads only the music session, nothing else.
 */
object Music {
    fun enabled(): Boolean = try {
        NotificationManagerCompat.getEnabledListenerPackages(App.ctx).contains(App.ctx.packageName)
    } catch (e: Exception) { false }

    private fun sessions(): List<MediaController> = try {
        val sm = App.ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        sm.getActiveSessions(ComponentName(App.ctx, MusicListener::class.java))
    } catch (e: Exception) { emptyList() }

    private fun pick(): MediaController? {
        val l = sessions()
        return l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: l.firstOrNull()
    }

    fun now(): NowPlaying? {
        val c = pick() ?: return null
        val m = c.metadata ?: return null
        val title = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return null
        val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val art = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART) ?: m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        return NowPlaying(title, artist, c.playbackState?.state == PlaybackState.STATE_PLAYING, art)
    }

    fun playPause() {
        val c = pick() ?: return
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause() else c.transportControls.play()
    }

    fun next() { pick()?.transportControls?.skipToNext() }
    fun prev() { pick()?.transportControls?.skipToPrevious() }
}

/** Only needs to exist and be switched on in Android's settings; it also tells the music widget when the song changes. */
class MusicListener : NotificationListenerService() {
    private val h = Handler(Looper.getMainLooper())
    private val refresh = Runnable { try { Widgets.updateMusic() } catch (e: Exception) { } }

    override fun onCreate() {
        super.onCreate()
        App.init(this)
    }

    override fun onListenerConnected() { poke() }

    override fun onNotificationPosted(sbn: StatusBarNotification?) { if (isMedia(sbn)) poke() }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) { if (isMedia(sbn)) poke() }

    private fun isMedia(sbn: StatusBarNotification?): Boolean {
        val n = sbn?.notification ?: return false
        return n.category == Notification.CATEGORY_TRANSPORT || (n.extras?.containsKey("android.mediaSession") == true)
    }

    private fun poke() {
        h.removeCallbacks(refresh)
        h.postDelayed(refresh, 400)
    }
}

class MusicActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        App.init(context)
        when (intent.action) {
            "PLAYPAUSE" -> Music.playPause()
            "NEXT" -> Music.next()
            "PREV" -> Music.prev()
        }
        Handler(Looper.getMainLooper()).postDelayed({ try { Widgets.updateMusic() } catch (e: Exception) { } }, 700)
    }
}

/** The small now-playing card on the run screen. Shows nothing until music control is switched on and something is playing. */
@Composable
fun NowPlayingCard(modifier: Modifier = Modifier) {
    var np by remember { mutableStateOf<NowPlaying?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            np = if (Music.enabled()) Music.now() else null
            delay(1000)
        }
    }
    val n = np ?: return
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(C.card2).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)).background(C.line), contentAlignment = Alignment.Center) {
            val a = n.art
            if (a != null) Image(a.asImageBitmap(), null, Modifier.size(44.dp), contentScale = ContentScale.Crop)
            else Icon(Icons.Filled.MusicNote, null, tint = C.steelLt)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            T(n.title, 14, C.text, FontWeight.Bold)
            if (n.artist.isNotEmpty()) T(n.artist, 12, C.steel)
        }
        Box(Modifier.size(40.dp).clip(CircleShape).clickable { Music.prev() }, contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.SkipPrevious, null, tint = C.text)
        }
        Box(Modifier.size(44.dp).clip(CircleShape).background(C.orange).clickable { Music.playPause() }, contentAlignment = Alignment.Center) {
            Icon(if (n.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = Color.White)
        }
        Box(Modifier.size(40.dp).clip(CircleShape).clickable { Music.next() }, contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.SkipNext, null, tint = C.text)
        }
    }
}
