package com.breadwinner.wavestride

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** Plain Android-canvas drawing, used for widgets, the route picture and the replay video. */
object Draw {
    val ORANGE = 0xFFFC4C02.toInt()
    val GREEN = 0xFF3DAA5C.toInt()
    val RED = 0xFFE5484D.toInt()
    val STEEL = 0xFF8A95A0.toInt()
    val STEEL_LT = 0xFFC3CBD2.toInt()
    val LIGHT = 0xFFEDF0F2.toInt()
    val CARD = 0xFF161A1E.toInt()
    val CARD2 = 0xFF1E242A.toInt()
    val LINE = 0xFF2A3138.toInt()
    val BG = 0xFF0B0D0F.toInt()
    val PAPER = 0xFFF2EFE9.toInt()

    fun fill(color: Int): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        p.style = Paint.Style.FILL
        return p
    }

    fun stroke(color: Int, width: Float): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        p.style = Paint.Style.STROKE
        p.strokeWidth = width
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        return p
    }

    fun textPaint(color: Int, size: Float, bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT, shadow: Boolean = false): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        p.textSize = size
        p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        p.textAlign = align
        if (shadow) p.setShadowLayer(size * 0.08f, 0f, size * 0.05f, 0xAA000000.toInt())
        return p
    }

    /** Text that is cut short with "…" if it would run past [maxW]. */
    fun fit(s: String, p: Paint, maxW: Float): String {
        if (p.measureText(s) <= maxW) return s
        var t = s
        while (t.length > 1 && p.measureText("$t…") > maxW) t = t.substring(0, t.length - 1)
        return "$t…"
    }

    fun card(c: Canvas, w: Float, h: Float, radius: Float = 18f) {
        val r = RectF(0.5f, 0.5f, w - 0.5f, h - 0.5f)
        c.drawRoundRect(r, radius, radius, fill(CARD))
        c.drawRoundRect(r, radius, radius, stroke(LINE, 1f))
    }

    fun latlons(pts: List<Pt>, maxN: Int = 700): List<DoubleArray> {
        if (pts.size <= maxN) return pts.map { doubleArrayOf(it.lat, it.lon) }
        val out = ArrayList<DoubleArray>()
        for (i in 0 until maxN) {
            val p = pts[(i.toLong() * (pts.size - 1) / (maxN - 1)).toInt()]
            out.add(doubleArrayOf(p.lat, p.lon))
        }
        return out
    }

    /** Fits the points into [r], keeping the shape true, centred. Returns x,y pairs. */
    fun project(pts: List<DoubleArray>, r: RectF): FloatArray {
        var x0 = 2.0; var x1 = -1.0; var y0 = 2.0; var y1 = -1.0
        for (p in pts) {
            val x = Geo.mx(p[1]); val y = Geo.my(p[0])
            x0 = min(x0, x); x1 = max(x1, x); y0 = min(y0, y); y1 = max(y1, y)
        }
        val sx = max(x1 - x0, 1e-7)
        val sy = max(y1 - y0, 1e-7)
        val sc = min(r.width() / sx, r.height() / sy)
        val ox = r.left + (r.width() - sx * sc) / 2
        val oy = r.top + (r.height() - sy * sc) / 2
        val out = FloatArray(pts.size * 2)
        for (i in pts.indices) {
            out[2 * i] = (ox + (Geo.mx(pts[i][1]) - x0) * sc).toFloat()
            out[2 * i + 1] = (oy + (Geo.my(pts[i][0]) - y0) * sc).toFloat()
        }
        return out
    }

    /**
     * Draws the route (or its first [frac] part) as a crisp solid line. Returns where the end of the drawn part is.
     * [xy] is the output of [project], so the shape stays the same while it draws itself.
     */
    fun route(c: Canvas, xy: FloatArray, color: Int, width: Float, frac: Float = 1f, casing: Int = 0, casingW: Float = 0f): FloatArray {
        val n = xy.size / 2
        if (n < 2) return floatArrayOf(if (n == 1) xy[0] else 0f, if (n == 1) xy[1] else 0f)
        val total = (n - 1) * frac.coerceIn(0f, 1f)
        val k = min(floor(total).toInt(), n - 1)
        val f = total - k
        val path = Path()
        path.moveTo(xy[0], xy[1])
        for (i in 1..k) path.lineTo(xy[2 * i], xy[2 * i + 1])
        var hx = xy[2 * k]
        var hy = xy[2 * k + 1]
        if (k < n - 1 && f > 0f) {
            hx = xy[2 * k] + (xy[2 * k + 2] - xy[2 * k]) * f
            hy = xy[2 * k + 1] + (xy[2 * k + 3] - xy[2 * k + 1]) * f
            path.lineTo(hx, hy)
        }
        if (casingW > 0f) c.drawPath(path, stroke(casing, casingW))
        c.drawPath(path, stroke(color, width))
        return floatArrayOf(hx, hy)
    }

    fun dot(c: Canvas, x: Float, y: Float, r: Float, color: Int, ring: Int = 0xFFFFFFFF.toInt()) {
        c.drawCircle(x, y, r + r * 0.4f, fill(ring))
        c.drawCircle(x, y, r, fill(color))
    }
}
