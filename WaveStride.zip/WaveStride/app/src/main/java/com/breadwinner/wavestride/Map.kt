package com.breadwinner.wavestride

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

/** Where the map is looking: centre in 0..1 world units, and a zoom (fractional, like a pinch). */
class MapCam(cx0: Double = 0.5, cy0: Double = 0.5, zoom0: Double = 14.0) {
    var cx by mutableStateOf(cx0)
    var cy by mutableStateOf(cy0)
    var zoom by mutableStateOf(zoom0)

    fun center(lat: Double, lon: Double) { cx = Geo.mx(lon); cy = Geo.my(lat) }

    fun fit(pts: List<DoubleArray>, w: Float, h: Float, density: Float, pad: Float) {
        if (pts.isEmpty() || w <= 0f || h <= 0f) return
        var x0 = 2.0; var x1 = -1.0; var y0 = 2.0; var y1 = -1.0
        for (p in pts) {
            val x = Geo.mx(p[1]); val y = Geo.my(p[0])
            x0 = min(x0, x); x1 = max(x1, x); y0 = min(y0, y); y1 = max(y1, y)
        }
        val sx = max(x1 - x0, 1e-7)
        val sy = max(y1 - y0, 1e-7)
        val zx = ln(((w - 2 * pad) / (sx * 256.0 * density)).coerceAtLeast(1e-3)) / ln(2.0)
        val zy = ln(((h - 2 * pad) / (sy * 256.0 * density)).coerceAtLeast(1e-3)) / ln(2.0)
        zoom = min(zx, zy).coerceIn(3.0, 17.5)
        cx = (x0 + x1) / 2
        cy = (y0 + y1) / 2
    }
}

val MAP_PAPER = Color(0xFFF2EFE9)

/** A map made of saved tiles, with the route on top. Works fully offline for any area you downloaded. */
@Composable
fun MapView(
    cam: MapCam,
    modifier: Modifier = Modifier,
    route: List<Pt>? = null,
    ver: Int = 0,
    colors: List<Color>? = null,
    youLat: Double = Double.NaN,
    youLon: Double = Double.NaN,
    fitRoute: Boolean = false,
    markers: Boolean = true,
    interactive: Boolean = true,
    onMoved: (() -> Unit)? = null
) {
    val dens = LocalDensity.current.density
    var sz by remember { mutableStateOf(IntSize.Zero) }
    val tv by Tiles.ver.collectAsState()

    LaunchedEffect(sz, fitRoute, route?.size) {
        if (fitRoute && route != null && route.size > 1 && sz.width > 0) {
            cam.fit(route.map { doubleArrayOf(it.lat, it.lon) }, sz.width.toFloat(), sz.height.toFloat(), dens, 48f * dens)
        }
    }

    Box(modifier.clip(RoundedCornerShape(0.dp)).onSizeChanged { sz = it }) {
        Canvas(
            Modifier.fillMaxSize().pointerInput(interactive) {
                if (interactive) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val world = 256.0 * density * 2.0.pow(cam.zoom)
                        cam.cx -= pan.x / world
                        cam.cy = (cam.cy - pan.y / world).coerceIn(0.0, 1.0)
                        if (zoom != 1f) cam.zoom = (cam.zoom + ln(zoom.toDouble()) / ln(2.0)).coerceIn(3.0, 18.0)
                        onMoved?.invoke()
                    }
                }
            }
        ) {
            @Suppress("UNUSED_VARIABLE") val redraw = tv + ver
            val w = size.width
            val h = size.height
            val d = this.density
            val worldPx = 256.0 * d * 2.0.pow(cam.zoom)
            val zi = floor(cam.zoom).toInt().coerceIn(2, 17)
            val n = 1 shl zi
            val tilePx = (256.0 * d * 2.0.pow(cam.zoom - zi)).toFloat()
            val left = cam.cx - (w / 2) / worldPx
            val top = cam.cy - (h / 2) / worldPx
            val right = cam.cx + (w / 2) / worldPx
            val bottom = cam.cy + (h / 2) / worldPx

            drawRect(MAP_PAPER)

            val tx0 = floor(left * n).toInt()
            val tx1 = floor(right * n).toInt()
            val ty0 = floor(top * n).toInt().coerceAtLeast(0)
            val ty1 = floor(bottom * n).toInt().coerceAtMost(n - 1)
            val sizePx = IntSize(ceil(tilePx).toInt() + 1, ceil(tilePx).toInt() + 1)
            if ((tx1 - tx0 + 1).toLong() * (ty1 - ty0 + 1) < 120) {
                for (ty in ty0..ty1) {
                    for (tx in tx0..tx1) {
                        val wx = ((tx % n) + n) % n
                        val sx = ((tx.toDouble() / n - left) * worldPx).roundToInt()
                        val sy = ((ty.toDouble() / n - top) * worldPx).roundToInt()
                        val bm = Tiles.get(zi, wx, ty)
                        if (bm != null) {
                            drawImage(bm, dstOffset = IntOffset(sx, sy), dstSize = sizePx)
                        } else {
                            // not ready: show the blurrier parent tile until it arrives
                            for (l in 1..3) {
                                val pz = zi - l
                                if (pz < 2) break
                                val pb = Tiles.get(pz, wx shr l, ty shr l, load = l == 1)
                                if (pb != null) {
                                    val sw = 256 shr l
                                    drawImage(
                                        pb,
                                        srcOffset = IntOffset((wx and ((1 shl l) - 1)) * sw, (ty and ((1 shl l) - 1)) * sw),
                                        srcSize = IntSize(sw, sw),
                                        dstOffset = IntOffset(sx, sy),
                                        dstSize = sizePx
                                    )
                                    break
                                }
                            }
                        }
                    }
                }
            }

            if (route != null && route.size > 1) {
                val xs = FloatArray(route.size)
                val ys = FloatArray(route.size)
                for (i in route.indices) {
                    xs[i] = ((Geo.mx(route[i].lon) - left) * worldPx).toFloat()
                    ys[i] = ((Geo.my(route[i].lat) - top) * worldPx).toFloat()
                }
                val lw = 4.5f * d
                if (colors != null && colors.size >= route.size - 1) {
                    for (i in 1 until route.size) {
                        drawLine(colors[i - 1], Offset(xs[i - 1], ys[i - 1]), Offset(xs[i], ys[i]), strokeWidth = lw, cap = StrokeCap.Round)
                    }
                } else {
                    val path = Path()
                    path.moveTo(xs[0], ys[0])
                    for (i in 1 until route.size) path.lineTo(xs[i], ys[i])
                    drawPath(path, C.orange, style = Stroke(width = lw, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                if (markers) {
                    drawCircle(Color.White, 8.5f * d, Offset(xs[0], ys[0]))
                    drawCircle(C.green, 6f * d, Offset(xs[0], ys[0]))
                    val e = route.size - 1
                    drawCircle(Color.White, 8.5f * d, Offset(xs[e], ys[e]))
                    drawCircle(C.red, 6f * d, Offset(xs[e], ys[e]))
                }
            }

            if (!youLat.isNaN() && !youLon.isNaN()) {
                val px = ((Geo.mx(youLon) - left) * worldPx).toFloat()
                val py = ((Geo.my(youLat) - top) * worldPx).toFloat()
                drawCircle(Color.White, 10f * d, Offset(px, py))
                drawCircle(C.blue, 7f * d, Offset(px, py))
            }
        }
        Box(
            Modifier.align(Alignment.BottomStart).padding(6.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xCCFFFFFF)).padding(horizontal = 5.dp, vertical = 1.dp)
        ) { T("© OpenStreetMap contributors", 9, Color(0xFF444444)) }
    }
}

/** A small route drawing for lists and cards: cheap, no map needed. */
@Composable
fun RoutePreview(mini: List<DoubleArray>, modifier: Modifier = Modifier, line: Color = C.orange, bg: Color = MAP_PAPER) {
    Canvas(modifier) {
        drawRect(bg)
        val d = this.density
        val step = 28f * d
        var gx = step
        while (gx < size.width) { drawLine(Color(0x0F000000), Offset(gx, 0f), Offset(gx, size.height), 1f); gx += step }
        var gy = step
        while (gy < size.height) { drawLine(Color(0x0F000000), Offset(0f, gy), Offset(size.width, gy), 1f); gy += step }
        if (mini.size < 2) return@Canvas
        var x0 = 2.0; var x1 = -1.0; var y0 = 2.0; var y1 = -1.0
        for (p in mini) {
            val x = Geo.mx(p[1]); val y = Geo.my(p[0])
            x0 = min(x0, x); x1 = max(x1, x); y0 = min(y0, y); y1 = max(y1, y)
        }
        val sx = max(x1 - x0, 1e-7)
        val sy = max(y1 - y0, 1e-7)
        val pad = 14f * d
        val sc = min((size.width - 2 * pad) / sx, (size.height - 2 * pad) / sy)
        val ox = (size.width - sx * sc) / 2
        val oy = (size.height - sy * sc) / 2
        val path = Path()
        for (i in mini.indices) {
            val x = (ox + (Geo.mx(mini[i][1]) - x0) * sc).toFloat()
            val y = (oy + (Geo.my(mini[i][0]) - y0) * sc).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, line, style = Stroke(width = 3.5f * d, cap = StrokeCap.Round, join = StrokeJoin.Round))
        val a = mini.first()
        val b = mini.last()
        drawCircle(C.green, 4f * d, Offset((ox + (Geo.mx(a[1]) - x0) * sc).toFloat(), (oy + (Geo.my(a[0]) - y0) * sc).toFloat()))
        drawCircle(C.red, 4f * d, Offset((ox + (Geo.mx(b[1]) - x0) * sc).toFloat(), (oy + (Geo.my(b[0]) - y0) * sc).toFloat()))
    }
}

/** Colours a route by speed: blue (slow) through green and yellow to red (fast), judged against that run's own range. */
object SpeedColors {
    private val stops = listOf(Color(0xFF2D7DD2), Color(0xFF3DAA5C), Color(0xFFF2C14E), Color(0xFFE4572E))

    fun at(t: Float): Color {
        val x = t.coerceIn(0f, 1f) * (stops.size - 1)
        val i = min(x.toInt(), stops.size - 2)
        val f = x - i
        val a = stops[i]
        val b = stops[i + 1]
        return Color(a.red + (b.red - a.red) * f, a.green + (b.green - a.green) * f, a.blue + (b.blue - a.blue) * f, 1f)
    }

    fun forRoute(p: List<Pt>): List<Color> {
        if (p.size < 2) return emptyList()
        val sp = DoubleArray(p.size - 1)
        for (i in 1 until p.size) {
            val a = p[max(0, i - 4)]
            val b = p[i]
            val dt = (b.mt - a.mt) / 1000.0
            sp[i - 1] = if (dt > 0.5) (b.d - a.d) / dt else 0.0
        }
        val sorted = sp.sorted()
        val lo = sorted[(sorted.size * 0.1).toInt().coerceIn(0, sorted.size - 1)]
        val hi = sorted[(sorted.size * 0.9).toInt().coerceIn(0, sorted.size - 1)]
        val span = max(hi - lo, 0.2)
        return sp.map { at(((it - lo) / span).toFloat()) }
    }
}
