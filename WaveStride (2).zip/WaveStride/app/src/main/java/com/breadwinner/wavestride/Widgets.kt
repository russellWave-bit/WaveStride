package com.breadwinner.wavestride

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Bundle
import android.widget.RemoteViews
import java.util.Calendar
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** Six home screen widgets, each drawn as a picture at the size you give it. */
object Widgets {
    private val classes: List<Class<*>> = listOf(
        StepsWidget::class.java, HealthWidget::class.java, LastRunWidget::class.java, WeekWidget::class.java, StartWidget::class.java, MusicWidget::class.java
    )

    fun updateAll() { for (c in classes) kick(c) }
    fun updateMusic() { kick(MusicWidget::class.java) }

    private fun kick(cls: Class<*>) {
        try {
            val ctx = App.ctx
            val awm = AppWidgetManager.getInstance(ctx)
            val ids = awm.getAppWidgetIds(ComponentName(ctx, cls))
            if (ids.isEmpty()) return
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_UPDATE).setClass(ctx, cls)
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            ctx.sendBroadcast(i)
        } catch (e: Exception) { }
    }

    fun open(ctx: Context, action: String?, code: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
        if (action != null) i.action = action
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    /** Widget size in dp, from what the launcher says. */
    fun sizeDp(awm: AppWidgetManager, id: Int): Pair<Float, Float> {
        val o = awm.getAppWidgetOptions(id)
        val w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 110).coerceAtLeast(60)
        val h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 110).coerceAtLeast(60)
        return Pair(w.toFloat(), h.toFloat())
    }

    /** Draws in dp units, so shapes keep their proportions on any widget size. */
    fun render(ctx: Context, awm: AppWidgetManager, id: Int, draw: (Canvas, Float, Float) -> Unit): Bitmap {
        val (w, h) = sizeDp(awm, id)
        val k = min(ctx.resources.displayMetrics.density, 640f / max(w, h))
        val bm = Bitmap.createBitmap(max(1, (w * k).toInt()), max(1, (h * k).toInt()), Bitmap.Config.ARGB_8888)
        val c = Canvas(bm)
        c.scale(k, k)
        draw(c, w, h)
        return bm
    }

    fun nf(n: Int): String = String.format(Locale.US, "%,d", n)

    fun tri(c: Canvas, cx: Float, cy: Float, s: Float, right: Boolean, p: Paint) {
        val path = Path()
        if (right) { path.moveTo(cx - s * 0.7f, cy - s); path.lineTo(cx + s * 0.9f, cy); path.lineTo(cx - s * 0.7f, cy + s) }
        else { path.moveTo(cx + s * 0.7f, cy - s); path.lineTo(cx - s * 0.9f, cy); path.lineTo(cx + s * 0.7f, cy + s) }
        path.close()
        c.drawPath(path, p)
    }
}

abstract class ImgWidget : AppWidgetProvider() {
    abstract fun draw(c: Canvas, w: Float, h: Float)
    open fun action(): String? = null

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        App.init(context)
        for (id in appWidgetIds) push(context, appWidgetManager, id)
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle?) {
        App.init(context)
        push(context, appWidgetManager, appWidgetId)
    }

    private fun push(ctx: Context, awm: AppWidgetManager, id: Int) {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_img)
        try {
            rv.setImageViewBitmap(R.id.img, Widgets.render(ctx, awm, id) { c, w, h -> draw(c, w, h) })
        } catch (e: Exception) { }
        rv.setOnClickPendingIntent(R.id.root, Widgets.open(ctx, action(), 100 + id))
        awm.updateAppWidget(id, rv)
    }
}

/** Today's steps with a goal ring. */
class StepsWidget : ImgWidget() {
    override fun draw(c: Canvas, w: Float, h: Float) {
        Draw.card(c, w, h)
        val d = Steps.today()
        val goal = max(1, Steps.goal())
        val r = min(w, h) * 0.32f
        val cx = w / 2
        val cy = h * 0.46f
        val sw = r * 0.34f
        val rect = RectF(cx - r, cy - r, cx + r, cy + r)
        c.drawArc(rect, -90f, 360f, false, Draw.stroke(Draw.tCard2, sw))
        c.drawArc(rect, -90f, 360f * min(1f, d.steps.toFloat() / goal), false, Draw.stroke(Draw.tAccent, sw))
        c.drawText(Widgets.nf(d.steps), cx, cy + r * 0.16f, Draw.textPaint(Draw.tText, r * 0.52f, true, Paint.Align.CENTER))
        c.drawText("steps", cx, cy + r * 0.52f, Draw.textPaint(Draw.tSteel, r * 0.24f, false, Paint.Align.CENTER))
        c.drawText(d.activeMin.toString() + " min active", cx, h - h * 0.07f, Draw.textPaint(Draw.tSteelLt, min(w, h) * 0.085f, false, Paint.Align.CENTER))
    }
}

/** Your latest run: its route and numbers. */
class LastRunWidget : ImgWidget() {
    override fun draw(c: Canvas, w: Float, h: Float) {
        Draw.card(c, w, h)
        val r = Runs.list().firstOrNull()
        if (r == null) {
            c.drawText("No runs yet", w / 2, h * 0.48f, Draw.textPaint(Draw.tText, h * 0.14f, true, Paint.Align.CENTER))
            c.drawText("Tap to open WaveStride", w / 2, h * 0.66f, Draw.textPaint(Draw.tSteel, h * 0.1f, false, Paint.Align.CENTER))
            return
        }
        val pad = min(w, h) * 0.08f
        val side = h - 2 * pad
        val box = RectF(pad, pad, pad + side, pad + side)
        c.drawRoundRect(box, 12f, 12f, Draw.fill(Draw.PAPER))
        val inner = RectF(box.left + side * 0.1f, box.top + side * 0.1f, box.right - side * 0.1f, box.bottom - side * 0.1f)
        val xy = Draw.project(r.mini, inner)
        Draw.route(c, xy, Draw.ORANGE, max(2.5f, side * 0.035f))
        if (xy.size >= 4) {
            c.drawCircle(xy[0], xy[1], side * 0.03f, Draw.fill(Draw.GREEN))
            c.drawCircle(xy[xy.size - 2], xy[xy.size - 1], side * 0.03f, Draw.fill(Draw.RED))
        }
        val x = box.right + pad
        val maxW = w - x - pad
        c.drawText(Draw.fit(r.title, Draw.textPaint(Draw.tText, h * 0.12f, true), maxW), x, pad + h * 0.12f, Draw.textPaint(Draw.tText, h * 0.12f, true))
        c.drawText(Fmt.dayMonth(r.start), x, pad + h * 0.24f, Draw.textPaint(Draw.tSteel, h * 0.09f))
        val big = Draw.textPaint(Draw.tText, h * 0.27f, true)
        c.drawText(Fmt.km(r.distM), x, pad + h * 0.55f, big)
        c.drawText("km", x + big.measureText(Fmt.km(r.distM)) + 6f, pad + h * 0.55f, Draw.textPaint(Draw.tSteel, h * 0.1f))
        c.drawText(Fmt.dur(r.durMs) + "  ·  " + Fmt.pace(Fmt.paceOf(r.distM, r.durMs)) + " /km", x, pad + h * 0.72f, Draw.textPaint(Draw.tSteelLt, h * 0.09f))
    }
}

/** This week's distance, day by day. */
class WeekWidget : ImgWidget() {
    override fun draw(c: Canvas, w: Float, h: Float) {
        Draw.card(c, w, h)
        val runs = Runs.list()
        val ws = Stats.weekStart(System.currentTimeMillis())
        val per = Stats.perDay(runs, ws, 7)
        val idx = (Calendar.getInstance().get(Calendar.DAY_OF_WEEK) + 5) % 7
        val pad = min(w, h) * 0.09f
        c.drawText("THIS WEEK", pad, pad + h * 0.08f, Draw.textPaint(Draw.tSteel, h * 0.08f, true))
        val tot = Fmt.f1(per.sum())
        val big = Draw.textPaint(Draw.tText, h * 0.2f, true)
        c.drawText(tot, pad, pad + h * 0.3f, big)
        c.drawText("km", pad + big.measureText(tot) + 6f, pad + h * 0.3f, Draw.textPaint(Draw.tSteel, h * 0.09f))
        val top = pad + h * 0.38f
        val bottom = h - pad - h * 0.1f
        val mx = max(per.maxOrNull() ?: 0.0, 0.0001)
        val slot = (w - 2 * pad) / 7f
        val bw = slot * 0.6f
        val labels = listOf("M", "T", "W", "T", "F", "S", "S")
        for (i in 0 until 7) {
            val x = pad + slot * i + (slot - bw) / 2
            val bh = max(3f, ((bottom - top) * (per[i] / mx)).toFloat())
            c.drawRoundRect(RectF(x, bottom - bh, x + bw, bottom), 4f, 4f, Draw.fill(if (i == idx) Draw.tAccent else Draw.tSteel))
            c.drawText(labels[i], x + bw / 2, h - pad * 0.7f, Draw.textPaint(if (i == idx) Draw.tText else Draw.tSteel, h * 0.085f, i == idx, Paint.Align.CENTER))
        }
    }
}

/** One big button that starts recording straight away. */
class StartWidget : ImgWidget() {
    override fun action(): String? = "com.breadwinner.wavestride.START_RUN"

    override fun draw(c: Canvas, w: Float, h: Float) {
        Draw.card(c, w, h)
        val r = min(w, h) * 0.3f
        val cx = w / 2
        val cy = h * 0.43f
        c.drawCircle(cx, cy, r, Draw.fill(Draw.tGo))
        val s = r * 0.42f
        val p = Draw.fill(Draw.tOn)
        // two chevrons, like the app icon
        for (dx in listOf(-s * 0.55f, s * 0.55f)) {
            val path = Path()
            path.moveTo(cx + dx - s * 0.45f, cy - s)
            path.lineTo(cx + dx + s * 0.35f, cy)
            path.lineTo(cx + dx - s * 0.45f, cy + s)
            path.lineTo(cx + dx - s * 0.8f, cy + s)
            path.lineTo(cx + dx, cy)
            path.lineTo(cx + dx - s * 0.8f, cy - s)
            path.close()
            c.drawPath(path, p)
        }
        c.drawText("START RUN", cx, h - h * 0.1f, Draw.textPaint(Draw.tText, min(w, h) * 0.1f, true, Paint.Align.CENTER))
    }
}

/** What's playing, with previous / play / next. Needs the one-time notification access switch. */
class MusicWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        App.init(context)
        for (id in appWidgetIds) push(context, appWidgetManager, id)
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle?) {
        App.init(context)
        push(context, appWidgetManager, appWidgetId)
    }

    private fun act(ctx: Context, a: String, code: Int): PendingIntent =
        PendingIntent.getBroadcast(ctx, code, Intent(ctx, MusicActionReceiver::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun push(ctx: Context, awm: AppWidgetManager, id: Int) {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_music)
        val on = Music.enabled()
        val np = if (on) Music.now() else null
        try {
            rv.setImageViewBitmap(R.id.img, Widgets.render(ctx, awm, id) { c, w, h -> draw(c, w, h, on, np) })
        } catch (e: Exception) { }
        rv.setOnClickPendingIntent(R.id.root, Widgets.open(ctx, null, 200 + id))
        rv.setOnClickPendingIntent(R.id.b_prev, act(ctx, "PREV", 1))
        rv.setOnClickPendingIntent(R.id.b_play, act(ctx, "PLAYPAUSE", 2))
        rv.setOnClickPendingIntent(R.id.b_next, act(ctx, "NEXT", 3))
        awm.updateAppWidget(id, rv)
    }

    private fun draw(c: Canvas, w: Float, h: Float, on: Boolean, np: NowPlaying?) {
        Draw.card(c, w, h)
        val pad = 14f
        val maxW = w - 2 * pad
        val tp = Draw.textPaint(Draw.tText, 16f, true)
        val ap = Draw.textPaint(Draw.tSteel, 12f)
        if (!on) {
            c.drawText("Music control is off", pad, 26f, tp)
            c.drawText("Allow it in WaveStride, More", pad, 44f, ap)
            return
        }
        c.drawText(Draw.fit(np?.title ?: "Nothing playing", tp, maxW), pad, 26f, tp)
        if (np != null && np.artist.isNotEmpty()) c.drawText(Draw.fit(np.artist, ap, maxW), pad, 44f, ap)
        val band = h - 46f
        val cy = 46f + band / 2
        val third = w / 3
        val steel = Draw.fill(Draw.tSteelLt)
        val s = min(band, third) * 0.18f
        // previous: bar and a left triangle
        c.drawRect(third * 0.5f - s * 1.1f, cy - s, third * 0.5f - s * 0.7f, cy + s, steel)
        Widgets.tri(c, third * 0.5f + s * 0.2f, cy, s, false, steel)
        // play / pause on an orange disc
        val r = min(band, third) * 0.36f
        c.drawCircle(third * 1.5f, cy, r, Draw.fill(Draw.tGo))
        val white = Draw.fill(Draw.tOn)
        if (np != null && np.playing) {
            c.drawRect(third * 1.5f - r * 0.35f, cy - r * 0.38f, third * 1.5f - r * 0.1f, cy + r * 0.38f, white)
            c.drawRect(third * 1.5f + r * 0.1f, cy - r * 0.38f, third * 1.5f + r * 0.35f, cy + r * 0.38f, white)
        } else Widgets.tri(c, third * 1.5f + r * 0.05f, cy, r * 0.42f, true, white)
        // next: right triangle and a bar
        Widgets.tri(c, third * 2.5f - s * 0.2f, cy, s, true, steel)
        c.drawRect(third * 2.5f + s * 0.7f, cy - s, third * 2.5f + s * 1.1f, cy + s, steel)
    }
}


/** The health bar: today's score as a thick bar, the streak and the calories. */
class HealthWidget : ImgWidget() {
    override fun draw(c: Canvas, w: Float, h: Float) {
        Draw.card(c, w, h)
        val runs = Runs.list()
        val d = Steps.today()
        val sc = Cal.score(d, runs).coerceIn(0f, 1f)
        val kcal = Cal.forDay(d, runs)
        val streak = Cal.streak(runs)
        val pad = min(w, h) * 0.1f
        val col = if (sc < 0.34f) Draw.tRed else if (sc < 0.67f) 0xFFF2B01E.toInt() else Draw.tGreen
        c.drawText("HEALTH", pad, pad + h * 0.09f, Draw.textPaint(Draw.tSteel, h * 0.09f, true))
        c.drawText((sc * 100).toInt().toString() + "%", w - pad, pad + h * 0.16f, Draw.textPaint(Draw.tText, h * 0.2f, true, Paint.Align.RIGHT))
        val bh = h * 0.2f
        val by = h * 0.4f
        val track = RectF(pad, by, w - pad, by + bh)
        c.drawRoundRect(track, bh / 2, bh / 2, Draw.fill(Draw.tCard2))
        if (sc > 0.01f) c.drawRoundRect(RectF(pad, by, pad + (w - 2 * pad) * sc, by + bh), bh / 2, bh / 2, Draw.fill(col))
        c.drawText(Widgets.nf(kcal) + " kcal", pad, h - pad - h * 0.04f, Draw.textPaint(Draw.tText, h * 0.13f, true))
        val st = if (streak == 1) "1 day streak" else "$streak day streak"
        c.drawText(st, w - pad, h - pad - h * 0.04f, Draw.textPaint(if (streak > 0) Draw.tAccent else Draw.tSteel, h * 0.11f, true, Paint.Align.RIGHT))
    }
}
