package com.breadwinner.wavestride

import kotlin.math.min
import kotlin.math.roundToInt

/** Calories, the health bar and the streak. All simple estimates from the step counter and your runs. */
object Cal {
    /** Weight in kg. 0 means "not told", then 70 kg is used. */
    fun weight(): Float = Prefs.f("weight_kg", 0f)
    fun height(): Int = Prefs.i("height_cm", 0)
    fun kg(): Double = if (weight() > 0f) weight().toDouble() else 70.0
    fun goal(): Int = Prefs.i("calgoal", 400)
    const val ACTIVE_GOAL = 30

    /** Active calories for a day: walking costs about 0.57 per kg per km, running about 1.0 (so runs add the difference). */
    fun forDay(d: Day, runs: List<Summary>): Int {
        var k = 0.57 * kg() * (d.steps * Steps.strideM() / 1000.0)
        for (r in runs) if (Steps.key(r.start) == d.key) k += 0.43 * kg() * (r.distM / 1000.0)
        return k.roundToInt()
    }

    fun today(runs: List<Summary> = Runs.list()): Int = forDay(Steps.today(), runs)
    fun days(n: Int, runs: List<Summary> = Runs.list()): List<Int> = Steps.days(n).map { forDay(it, runs) }

    /** Health bar for a day, 0..1: steps, calories and active minutes, each counting a third. */
    fun score(d: Day, runs: List<Summary>): Float {
        val a = min(1f, d.steps.toFloat() / Steps.goal().coerceAtLeast(1))
        val b = min(1f, forDay(d, runs).toFloat() / goal().coerceAtLeast(1))
        val c = min(1f, d.activeMin.toFloat() / ACTIVE_GOAL)
        return (a + b + c) / 3f
    }

    /** A day counts when you reach your steps goal or your calorie goal. */
    fun counts(d: Day, runs: List<Summary>): Boolean = d.steps >= Steps.goal() || forDay(d, runs) >= goal()

    /** Days in a row that counted. Today is free until it is over: if it has not counted yet, we start from yesterday. */
    fun streak(runs: List<Summary> = Runs.list()): Int {
        val ds = Steps.days(120)
        var i = ds.size - 1
        if (!counts(ds[i], runs)) i--
        var n = 0
        while (i >= 0 && counts(ds[i], runs)) { n++; i-- }
        return n
    }
}
