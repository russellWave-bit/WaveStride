package com.breadwinner.wavestride

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale
import kotlin.math.max

/** Spoken updates (optional) through the phone's own voice. */
object Voice {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val pending = ArrayList<String>()

    /** Speaks only if the switch in settings is on. */
    fun say(text: String) { if (Prefs.b("voice", false)) force(text) }

    fun force(text: String) {
        if (tts == null) {
            tts = TextToSpeech(App.ctx) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    try { tts?.setLanguage(Locale.UK) } catch (e: Exception) { }
                    ready = true
                    for (t in pending) speak(t)
                    pending.clear()
                }
            }
        }
        if (ready) speak(text) else pending.add(text)
    }

    private fun speak(t: String) {
        try { tts?.speak(t, TextToSpeech.QUEUE_ADD, null, "ws") } catch (e: Exception) { }
    }
}

/** One shared GPS listener: the map uses it to find you, the run service to record. */
object Gps {
    val last = MutableStateFlow<Location?>(null)
    var sink: ((Location) -> Unit)? = null
    private var users = 0
    private var started = false

    private val l = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
            last.value = loc
            sink?.invoke(loc)
        }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("old callback")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(App.ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun enabled(): Boolean {
        val lm = App.ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return try { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) } catch (e: Exception) { false }
    }

    fun acquire() {
        users++
        if (!started) start()
    }

    fun release() {
        users = max(0, users - 1)
        if (users == 0) stop()
    }

    /** Call after location permission is granted while a screen is already waiting for GPS. */
    fun retry() { if (users > 0 && !started) start() }

    @SuppressLint("MissingPermission")
    private fun start() {
        if (!hasPermission()) return
        val lm = App.ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            if (last.value == null) {
                last.value = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            }
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, l, Looper.getMainLooper())
            started = true
        } catch (e: Exception) { }
    }

    private fun stop() {
        try {
            val lm = App.ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm.removeUpdates(l)
        } catch (e: Exception) { }
        started = false
    }
}

enum class St { IDLE, RUNNING, PAUSED }

data class Live(
    val st: St = St.IDLE,
    val distM: Double = 0.0,
    val ms: Long = 0,
    val paceSec: Double = 0.0,
    val ver: Int = 0,
    val countdown: Int = 0
)

object RunState {
    val flow = MutableStateFlow(Live())
    /** The route so far. Only touched on the main thread. */
    val pts = ArrayList<Pt>()
    var startAt = 0L
    /** Set to the new run's id when a run is saved; the screen opens it, then clears this. */
    val saved = MutableStateFlow(0L)
}

class RunService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var lastTick = 0L
    private var lastP: Pt? = null
    private var movingMs = 0L
    private var distM = 0.0
    private var lastKm = 0
    private var ticks = 0
    private var wl: PowerManager.WakeLock? = null

    private val tick = object : Runnable {
        override fun run() {
            onTick()
            h.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        App.init(this)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("run", "Run recording", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "START" -> begin()
            "PAUSE" -> pause()
            "RESUME" -> resume()
            "STOP" -> finish()
            "DISCARD" -> discard()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        Gps.sink = null
        try { wl?.release() } catch (e: Exception) { }
        super.onDestroy()
    }

    private fun act(a: String, code: Int): PendingIntent =
        PendingIntent.getService(this, code, Intent(this, RunService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun note(text: String): Notification {
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = NotificationCompat.Builder(this, "run")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("WaveStride")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
        val st = RunState.flow.value.st
        if (st == St.RUNNING) b.addAction(0, "Pause", act("PAUSE", 2))
        else if (st == St.PAUSED) b.addAction(0, "Resume", act("RESUME", 3))
        if (st != St.IDLE) b.addAction(0, "Finish", act("STOP", 4))
        return b.build()
    }

    private fun startFg(text: String) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) startForeground(11, note(text), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
            else startForeground(11, note(text))
        } catch (e: Exception) { }
    }

    private fun refreshNote() {
        val s = RunState.flow.value
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val label = (if (s.st == St.PAUSED) "Paused · " else "") + Fmt.km(s.distM) + " km · " + Fmt.dur(s.ms)
        nm.notify(11, note(label))
    }

    private fun begin() {
        startFg("Getting ready")
        RunState.pts.clear()
        movingMs = 0; distM = 0.0; lastP = null; lastKm = 0; ticks = 0
        RunState.startAt = System.currentTimeMillis()
        Gps.sink = { onFix(it) }
        Gps.acquire()
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wavestride:run")
            wl?.acquire(6 * 3600 * 1000L)
        } catch (e: Exception) { }
        val n = if (Prefs.b("countdown", true)) 3 else 0
        if (n > 0) countdown(n) else go()
    }

    private fun countdown(n: Int) {
        if (n <= 0) { go(); return }
        RunState.flow.value = Live(countdown = n)
        h.postDelayed({ if (RunState.flow.value.countdown > 0) countdown(n - 1) }, 1000)
    }

    private fun go() {
        RunState.startAt = System.currentTimeMillis()
        lastTick = SystemClock.elapsedRealtime()
        RunState.flow.value = Live(st = St.RUNNING)
        h.removeCallbacks(tick)
        h.postDelayed(tick, 1000)
        Voice.say("Run started")
        refreshNote()
    }

    private fun pause() {
        if (RunState.flow.value.st != St.RUNNING) return
        h.removeCallbacks(tick)
        onTick()
        RunState.flow.value = RunState.flow.value.copy(st = St.PAUSED, ver = RunState.flow.value.ver + 1)
        lastP = null
        Voice.say("Paused")
        refreshNote()
    }

    private fun resume() {
        if (RunState.flow.value.st != St.PAUSED) return
        lastTick = SystemClock.elapsedRealtime()
        RunState.flow.value = RunState.flow.value.copy(st = St.RUNNING, ver = RunState.flow.value.ver + 1)
        h.removeCallbacks(tick)
        h.postDelayed(tick, 1000)
        Voice.say("Resumed")
        refreshNote()
    }

    private fun onTick() {
        if (RunState.flow.value.st != St.RUNNING) return
        val now = SystemClock.elapsedRealtime()
        movingMs += now - lastTick
        lastTick = now
        ticks++
        if (ticks % 30 == 0) Runs.saveLive(RunState.startAt, movingMs, RunState.pts)
        publish()
        if (ticks % 5 == 0) refreshNote()
    }

    private fun paceNow(): Double {
        val p = RunState.pts
        if (p.size < 2) return 0.0
        val last = p[p.size - 1]
        if (movingMs - last.mt > 12000) return 0.0   // standing still
        var i = p.size - 1
        while (i > 0 && last.mt - p[i - 1].mt <= 25000) i--
        val a = p[i]
        val dd = last.d - a.d
        val dt = last.mt - a.mt
        return if (dd < 8.0 || dt <= 0) 0.0 else dt / 1000.0 / (dd / 1000.0)
    }

    private fun publish() {
        val cur = RunState.flow.value
        RunState.flow.value = cur.copy(distM = distM, ms = movingMs, paceSec = paceNow(), ver = cur.ver + 1)
    }

    private fun onFix(l: Location) {
        if (RunState.flow.value.st != St.RUNNING) return
        if (l.hasAccuracy() && l.accuracy > 30f) return
        val lp = lastP
        var d = distM
        if (lp != null) {
            val step = Geo.dist(lp.lat, lp.lon, l.latitude, l.longitude)
            val dt = (movingMs - lp.mt) / 1000.0
            if (step < 2.5) return                       // hardly moved
            if (dt > 0.3 && step / dt > 11.5) return     // a GPS jump, not a runner
            d += step
        }
        distM = d
        val p = Pt(l.latitude, l.longitude, if (l.hasAltitude()) l.altitude else 0.0, movingMs, distM)
        RunState.pts.add(p)
        lastP = p
        val kmDone = (distM / 1000.0).toInt()
        if (kmDone > lastKm) { lastKm = kmDone; announce(kmDone) }
        publish()
    }

    private fun announce(km: Int) {
        val every = max(1, Prefs.i("voice_every", 1))
        if (!Prefs.b("voice", false) || km % every != 0) return
        val unit = if (km == 1) "kilometre" else "kilometres"
        Voice.force("$km $unit. Time ${Fmt.spokenTime(movingMs)}. Average pace ${Fmt.spokenPace(Fmt.paceOf(distM, movingMs))}.")
    }

    private fun cleanup() {
        h.removeCallbacksAndMessages(null)
        Gps.sink = null
        Gps.release()
        try { wl?.release() } catch (e: Exception) { }
        wl = null
    }

    private fun finish() {
        val st = RunState.flow.value.st
        val pts = ArrayList(RunState.pts)
        val ms = movingMs
        val dist = distM
        cleanup()
        RunState.flow.value = Live()
        var saved = 0L
        if (st != St.IDLE && pts.size >= 2 && dist >= 50.0) {
            val r = Runs.build(RunState.startAt, ms, pts)
            Runs.save(r)
            saved = r.sum.id
            Voice.say("Run finished. ${Fmt.km(dist)} kilometres in ${Fmt.spokenTime(ms)}.")
        } else if (st != St.IDLE) {
            Toast.makeText(this, "That was too short to save", Toast.LENGTH_SHORT).show()
        }
        Runs.clearLive()
        RunState.pts.clear()
        if (saved != 0L) RunState.saved.value = saved
        Widgets.updateAll()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun discard() {
        cleanup()
        RunState.flow.value = Live()
        RunState.pts.clear()
        Runs.clearLive()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    companion object {
        fun send(ctx: Context, action: String) {
            val i = Intent(ctx, RunService::class.java).setAction(action)
            if (action == "START") ContextCompat.startForegroundService(ctx, i) else ctx.startService(i)
        }
    }
}

/** Wakes up about every half hour, reads the step counter, and refreshes the widgets. Also restarts that after a reboot. */
class StepsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        App.init(context)
        StepsAlarm.schedule()
        StepService.start(context)
        val pr = goAsync()
        Steps.snapshot {
            try { Widgets.updateAll() } catch (e: Exception) { }
            pr.finish()
        }
    }
}

object StepsAlarm {
    fun schedule() {
        try {
            val am = App.ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                App.ctx, 77,
                Intent(App.ctx, StepsReceiver::class.java).setAction("STEPS_TICK"),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 30 * 60 * 1000L, pi)
        } catch (e: Exception) { }
    }
}


/** Keeps the phone's step counter listening all day, with one quiet notification, so no walk goes uncounted. */
class StepService : Service(), android.hardware.SensorEventListener {
    private val h = Handler(Looper.getMainLooper())
    private var pending = -1f
    private var lastWidget = 0L
    private var registered = false

    private val flush = object : Runnable {
        override fun run() {
            flushNow()
            h.postDelayed(this, 20000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        App.init(this)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("steps", "Step counting", NotificationManager.IMPORTANCE_MIN))
    }

    private fun note(): Notification {
        val open = PendingIntent.getActivity(this, 5, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, "steps")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("WaveStride is counting your steps")
            .setContentText(String.format(Locale.US, "%,d steps today", Steps.today().steps))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(open)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 30) startForeground(12, note(), ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH)
            else startForeground(12, note())
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Prefs.b("always_steps", true) || !Steps.allowed()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!registered) {
            val sm = getSystemService(Context.SENSOR_SERVICE) as android.hardware.SensorManager
            val s = sm.getDefaultSensor(android.hardware.Sensor.TYPE_STEP_COUNTER)
            if (s == null) { stopSelf(); return START_NOT_STICKY }
            registered = try { sm.registerListener(this, s, android.hardware.SensorManager.SENSOR_DELAY_NORMAL) } catch (e: Exception) { false }
            h.removeCallbacks(flush)
            h.postDelayed(flush, 20000)
        }
        return START_STICKY
    }

    override fun onSensorChanged(e: android.hardware.SensorEvent) {
        pending = e.values[0]
    }

    override fun onAccuracyChanged(s: android.hardware.Sensor?, a: Int) {}

    private fun flushNow() {
        if (pending < 0f) return
        val v = pending
        pending = -1f
        try { Steps.apply(v) } catch (e: Exception) { }
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(12, note())
        } catch (e: Exception) { }
        val now = System.currentTimeMillis()
        if (now - lastWidget > 120000L) {
            lastWidget = now
            try { Widgets.updateAll() } catch (e: Exception) { }
        }
    }

    override fun onDestroy() {
        flushNow()
        h.removeCallbacksAndMessages(null)
        try {
            val sm = getSystemService(Context.SENSOR_SERVICE) as android.hardware.SensorManager
            sm.unregisterListener(this)
        } catch (e: Exception) { }
        super.onDestroy()
    }

    companion object {
        fun start(ctx: Context) {
            try {
                if (!Prefs.b("always_steps", true) || !Steps.allowed()) return
                ContextCompat.startForegroundService(ctx, Intent(ctx, StepService::class.java))
            } catch (e: Exception) { }
        }
        fun stop(ctx: Context) {
            try { ctx.stopService(Intent(ctx, StepService::class.java)) } catch (e: Exception) { }
        }
    }
}
