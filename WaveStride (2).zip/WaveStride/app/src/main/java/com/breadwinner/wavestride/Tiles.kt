package com.breadwinner.wavestride

import android.content.Context
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import kotlin.math.cos

class Place(val name: String, val lat: Double, val lon: Double)

object Areas {
    val presets = listOf(
        Place("Harare", -17.8292, 31.0522),
        Place("Bulawayo", -20.1500, 28.5833),
        Place("Mutare", -18.9707, 32.6709),
        Place("Gweru", -19.4500, 29.8167),
        Place("Masvingo", -20.0637, 30.8277),
        Place("Victoria Falls", -17.9243, 25.8572),
        Place("Lusaka", -15.3875, 28.3228),
        Place("Johannesburg", -26.2041, 28.0473),
        Place("Cape Town", -33.9249, 18.4241),
        Place("Nairobi", -1.2921, 36.8219),
        Place("London", 51.5074, -0.1278)
    )

    fun current(): Place = Place(
        Prefs.s("area_name", "Harare"),
        Prefs.s("area_lat", "-17.8292").toDoubleOrNull() ?: -17.8292,
        Prefs.s("area_lon", "31.0522").toDoubleOrNull() ?: 31.0522
    )

    fun set(p: Place) {
        Prefs.put("area_name", p.name)
        Prefs.put("area_lat", p.lat.toString())
        Prefs.put("area_lon", p.lon.toString())
    }

    fun radiusKm(): Int = Prefs.i("area_km", 10)

    /** Look a place up by name (needs the internet, one small request). Run off the main thread. */
    fun search(q: String): List<Place> {
        val out = ArrayList<Place>()
        try {
            val u = URL("https://nominatim.openstreetmap.org/search?format=json&limit=6&q=" + URLEncoder.encode(q, "UTF-8"))
            val c = u.openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 10000
            c.setRequestProperty("User-Agent", Tiles.UA)
            if (c.responseCode == 200) {
                val a = JSONArray(c.inputStream.bufferedReader().readText())
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    val name = o.optString("display_name", "").split(",").map { it.trim() }.take(2).joinToString(", ")
                    out.add(Place(name, o.getString("lat").toDouble(), o.getString("lon").toDouble()))
                }
            }
            c.disconnect()
        } catch (e: Exception) { }
        return out
    }
}

class DlState(val running: Boolean = false, val done: Int = 0, val total: Int = 0, val failed: Int = 0, val msg: String = "")

/** Map tiles (OpenStreetMap, Google-style look): kept on the phone, shown from there, fetched only when the rules in settings allow it. */
object Tiles {
    const val UA = "WaveStride/1.0 (personal Android run tracker; small cached area)"
    private const val Z_MIN = 11
    private const val Z_MAX = 16

    private val mem = LruCache<String, ImageBitmap>(140)
    val ver = MutableStateFlow(0)
    private val pending = HashSet<String>()
    private val failedAt = HashMap<String, Long>()
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    val dl = MutableStateFlow(DlState())
    @Volatile private var cancel = false

    private fun dir(): File = File(App.ctx.filesDir, "tiles")
    private fun file(z: Int, x: Int, y: Int): File = File(dir(), "$z/$x/$y.png")

    /** The tile if it is ready; otherwise null, and it is loaded (or fetched, if allowed) in the background. */
    fun get(z: Int, x: Int, y: Int, load: Boolean = true): ImageBitmap? {
        val k = "$z/$x/$y"
        val m = mem.get(k)
        if (m != null) return m
        if (load && !pending.contains(k)) {
            val fa = failedAt[k]
            if (fa == null || System.currentTimeMillis() - fa > 60000) {
                pending.add(k)
                pool.execute {
                    val bm = loadOrFetch(z, x, y)
                    main.post {
                        pending.remove(k)
                        if (bm != null) { mem.put(k, bm); ver.value = ver.value + 1 } else failedAt[k] = System.currentTimeMillis()
                    }
                }
            }
        }
        return null
    }

    private fun loadOrFetch(z: Int, x: Int, y: Int): ImageBitmap? {
        val f = file(z, x, y)
        if (!f.exists()) {
            if (!netOk()) return null
            if (!fetchFile(z, x, y)) return null
        }
        val bm = BitmapFactory.decodeFile(f.path)
        if (bm == null) { try { f.delete() } catch (e: Exception) { }; return null }
        return bm.asImageBitmap()
    }

    private fun fetchFile(z: Int, x: Int, y: Int): Boolean {
        val f = file(z, x, y)
        return try {
            f.parentFile?.mkdirs()
            val c = URL("https://tile.openstreetmap.org/$z/$x/$y.png").openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 10000
            c.setRequestProperty("User-Agent", UA)
            if (c.responseCode != 200) { c.disconnect(); return false }
            val tmp = File(f.path + ".tmp")
            c.inputStream.use { ins -> tmp.outputStream().use { out -> ins.copyTo(out) } }
            c.disconnect()
            tmp.renameTo(f)
        } catch (e: Exception) { false }
    }

    fun onWifi(): Boolean {
        val cm = App.ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        val cap = cm.getNetworkCapabilities(n) ?: return false
        return cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || cap.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    fun online(): Boolean {
        val cm = App.ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        val cap = cm.getNetworkCapabilities(n) ?: return false
        return cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /** Whether missing tiles may be fetched right now, by the rule in settings (default: Wi-Fi only). */
    private fun netOk(): Boolean {
        val rule = Prefs.s("fetch", "wifi")
        if (rule == "never") return false
        if (!online()) return false
        return if (rule == "any") true else onWifi()
    }

    private fun range(lat: Double, lon: Double, r: Double, z: Int): IntArray {
        val dLat = r / 111.32
        val dLon = r / (111.32 * cos(Math.toRadians(lat)))
        val n = 1 shl z
        val x0 = (Geo.mx(lon - dLon) * n).toInt().coerceIn(0, n - 1)
        val x1 = (Geo.mx(lon + dLon) * n).toInt().coerceIn(0, n - 1)
        val y0 = (Geo.my(lat + dLat) * n).toInt().coerceIn(0, n - 1)
        val y1 = (Geo.my(lat - dLat) * n).toInt().coerceIn(0, n - 1)
        return intArrayOf(x0, x1, y0, y1)
    }

    fun count(lat: Double, lon: Double, r: Double): Int {
        var c = 0
        for (z in Z_MIN..Z_MAX) {
            val q = range(lat, lon, r, z)
            c += (q[1] - q[0] + 1) * (q[3] - q[2] + 1)
        }
        return c
    }

    fun download(lat: Double, lon: Double, r: Double) {
        if (dl.value.running) return
        cancel = false
        val list = ArrayList<IntArray>()
        for (z in Z_MIN..Z_MAX) {
            val q = range(lat, lon, r, z)
            for (x in q[0]..q[1]) for (y in q[2]..q[3]) list.add(intArrayOf(z, x, y))
        }
        dl.value = DlState(true, 0, list.size)
        Thread {
            var done = 0
            var failed = 0
            var msg = "Done"
            for (t in list) {
                if (cancel) { msg = "Stopped"; break }
                if (!file(t[0], t[1], t[2]).exists()) {
                    if (!fetchFile(t[0], t[1], t[2])) failed++
                    try { Thread.sleep(80) } catch (e: Exception) { }
                }
                done++
                if (failed >= 20 && failed * 2 > done) { msg = "No connection, stopped"; break }
                if (done % 10 == 0) dl.value = DlState(true, done, list.size, failed)
            }
            if (msg == "Done" && failed > 0) msg = "Done, $failed tiles missed"
            dl.value = DlState(false, done, list.size, failed, msg)
            ver.value = ver.value + 1
        }.start()
    }

    fun cancelDownload() { cancel = true }

    fun sizeBytes(): Long {
        return try { dir().walkTopDown().filter { it.isFile }.sumOf { it.length() } } catch (e: Exception) { 0L }
    }

    fun clear() {
        try { dir().deleteRecursively() } catch (e: Exception) { }
        mem.evictAll()
        failedAt.clear()
        ver.value = ver.value + 1
    }
}
