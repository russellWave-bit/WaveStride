package com.breadwinner.wavestride

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Environment
import android.provider.MediaStore
import android.view.Surface
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import kotlin.math.max

class ShareFile(val file: File, val mime: String)

/** The route picture (transparent PNG) and the replay video. */
object Share {
    private fun dir(ctx: Context): File = File(ctx.cacheDir, "share").also { it.mkdirs() }

    private const val WHITE = -1

    // ---------------------------------------------------------------- picture
    fun png(ctx: Context, run: Run, stats: Boolean): ShareFile? {
        return try {
            val w = 1080
            val h = 1350
            val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(bm)   // starts fully transparent
            val rect = if (stats) RectF(130f, 120f, 950f, 880f) else RectF(110f, 150f, 970f, 1200f)
            val xy = Draw.project(Draw.latlons(run.pts), rect)
            // a solid white edge keeps the orange readable on any photo; it is a hard edge, not a glow
            Draw.route(c, xy, Draw.ORANGE, 16f, 1f, WHITE, 30f)
            if (xy.size >= 4) {
                Draw.dot(c, xy[0], xy[1], 15f, Draw.GREEN)
                Draw.dot(c, xy[xy.size - 2], xy[xy.size - 1], 15f, Draw.RED)
            }
            if (stats) {
                val s = run.sum
                c.drawText(Fmt.km(s.distM) + " km", w / 2f, 1075f, Draw.textPaint(WHITE, 170f, true, Paint.Align.CENTER, true))
                c.drawText(Fmt.dur(s.durMs) + "   ·   " + Fmt.pace(Fmt.paceOf(s.distM, s.durMs)) + " /km", w / 2f, 1175f, Draw.textPaint(WHITE, 62f, false, Paint.Align.CENTER, true))
                val small = Draw.textPaint(0xCCFFFFFF.toInt(), 40f, true, Paint.Align.CENTER, true)
                c.drawText(Fmt.dayMonth(s.start) + "  ·  WaveStride", w / 2f, 1260f, small)
            }
            val f = File(dir(ctx), "route_${run.sum.id}.png")
            f.outputStream().use { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bm.recycle()
            ShareFile(f, "image/png")
        } catch (e: Throwable) { null }
    }

    // ---------------------------------------------------------------- video
    private fun ease(x: Float): Float = x * x * (3 - 2 * x)

    /**
     * The route draws itself with a running dot while the numbers count up, then a quick finish flash.
     * Plain steel background, or a green screen to cut out in a video editor. Takes about 7 seconds to make.
     */
    fun video(ctx: Context, run: Run, green: Boolean, onPct: (Int) -> Unit): ShareFile? {
        val vw = 720
        val vh = 1280
        val fps = 30
        val total = 7 * fps
        val out = File(dir(ctx), "replay_${run.sum.id}${if (green) "_green" else ""}.mp4")
        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var surface: Surface? = null
        var muxing = false
        return try {
            if (out.exists()) out.delete()
            val s = run.sum
            val xy = Draw.project(Draw.latlons(run.pts, 500), RectF(70f, 300f, 650f, 860f))

            val fmt = MediaFormat.createVideoFormat("video/avc", vw, vh)
            fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, 5_000_000)
            fmt.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            val cd = MediaCodec.createEncoderByType("video/avc")
            codec = cd
            cd.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val sf = cd.createInputSurface()
            surface = sf
            cd.start()
            val mx = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mx
            var track = -1
            var base = -1L
            val info = MediaCodec.BufferInfo()

            fun drain(end: Boolean) {
                if (end) cd.signalEndOfInputStream()
                var idle = 0
                while (true) {
                    val i = cd.dequeueOutputBuffer(info, if (end) 10000L else 0L)
                    if (i == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        if (!end) return
                        idle++
                        if (idle > 300) return
                    } else if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        track = mx.addTrack(cd.outputFormat)
                        mx.start()
                        muxing = true
                    } else if (i >= 0) {
                        val buf = cd.getOutputBuffer(i)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                        if (info.size > 0 && muxing && buf != null) {
                            if (base < 0) base = info.presentationTimeUs
                            info.presentationTimeUs = max(0L, info.presentationTimeUs - base)
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            mx.writeSampleData(track, buf, info)
                        }
                        cd.releaseOutputBuffer(i, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                    }
                }
            }

            val bg = Paint()
            bg.shader = LinearGradient(0f, 0f, 0f, vh.toFloat(), 0xFF2A323A.toInt(), 0xFF0B0D0F.toInt(), Shader.TileMode.CLAMP)
            val gridP = Draw.stroke(0x14FFFFFF, 1f)
            val faint = Draw.stroke(0x33FFFFFF, 1f)
            val startNs = System.nanoTime()

            for (f in 0 until total) {
                // draw in real time: the encoder stamps each frame with the moment it was drawn
                val target = startNs + f * (1_000_000_000L / fps)
                while (System.nanoTime() < target) { try { Thread.sleep(1) } catch (e: Exception) { } }
                val c = sf.lockCanvas(null)
                try {
                    val t = f / fps.toFloat()
                    if (green) c.drawColor(0xFF00B140.toInt()) else {
                        c.drawRect(0f, 0f, vw.toFloat(), vh.toFloat(), bg)
                        var gx = 0f
                        while (gx < vw) { c.drawLine(gx, 0f, gx, vh.toFloat(), gridP); gx += 60f }
                        var gy = 0f
                        while (gy < vh) { c.drawLine(0f, gy, vw.toFloat(), gy, gridP); gy += 60f }
                    }
                    val intro = (t / 0.5f).coerceIn(0f, 1f)
                    val p = ease(((t - 0.5f) / 4.6f).coerceIn(0f, 1f))

                    val hp = Draw.textPaint(Draw.STEEL_LT, 28f, true)
                    hp.alpha = (intro * 255).toInt()
                    c.drawText("WAVESTRIDE", 60f, 110f, hp)
                    val tp = Draw.textPaint(WHITE, 64f, true)
                    tp.alpha = (intro * 255).toInt()
                    c.drawText(s.title, 60f, 190f, tp)
                    val dp = Draw.textPaint(Draw.STEEL_LT, 32f)
                    dp.alpha = (intro * 255).toInt()
                    c.drawText(Fmt.date(s.start), 60f, 240f, dp)

                    if (!green) Draw.route(c, xy, 0x33FFFFFF, 12f, 1f)
                    val head = Draw.route(c, xy, Draw.ORANGE, 12f, p)
                    if (xy.size >= 4 && intro > 0.5f) Draw.dot(c, xy[0], xy[1], 11f, Draw.GREEN)
                    if (p < 1f) {
                        c.drawCircle(head[0], head[1], 20f, Draw.fill(WHITE))
                        c.drawCircle(head[0], head[1], 11f, Draw.fill(Draw.ORANGE))
                    } else if (xy.size >= 4) {
                        Draw.dot(c, xy[xy.size - 2], xy[xy.size - 1], 13f, Draw.RED)
                    }

                    // the numbers count up with the route
                    val nums = Draw.textPaint(WHITE, 72f, true, Paint.Align.CENTER)
                    val lab = Draw.textPaint(Draw.STEEL_LT, 26f, false, Paint.Align.CENTER)
                    c.drawText(Fmt.f2(s.distM * p / 1000.0), 130f, 1040f, nums)
                    c.drawText("KM", 130f, 1085f, lab)
                    c.drawText(Fmt.dur((s.durMs * p).toLong()), 360f, 1040f, nums)
                    c.drawText("TIME", 360f, 1085f, lab)
                    c.drawText(Fmt.pace(Fmt.paceOf(s.distM, s.durMs)), 590f, 1040f, nums)
                    c.drawText("PACE /KM", 590f, 1085f, lab)

                    // finish flash and a thin ring from the finish point
                    val tf = t - 5.1f
                    if (tf in 0f..0.6f && xy.size >= 4) {
                        val a = ((1f - tf / 0.6f) * 255).toInt().coerceIn(0, 255)
                        val rp = Draw.stroke(Draw.LIGHT, 4f)
                        rp.alpha = a
                        c.drawCircle(xy[xy.size - 2], xy[xy.size - 1], 20f + 240f * (tf / 0.6f), rp)
                    }
                    if (tf in 0f..0.3f) {
                        val a = ((1f - tf / 0.3f) * 0.5f * 255).toInt().coerceIn(0, 255)
                        c.drawColor((a shl 24) or 0x00FFFFFF)
                    }
                } finally {
                    sf.unlockCanvasAndPost(c)
                }
                drain(false)
                onPct(f * 100 / total)
            }
            drain(true)
            onPct(100)
            ShareFile(out, "video/mp4")
        } catch (e: Throwable) {
            try { out.delete() } catch (x: Exception) { }
            null
        } finally {
            try { codec?.stop() } catch (e: Exception) { }
            try { codec?.release() } catch (e: Exception) { }
            try { surface?.release() } catch (e: Exception) { }
            try { if (muxing) muxer?.stop() } catch (e: Exception) { }
            try { muxer?.release() } catch (e: Exception) { }
        }
    }

    // ---------------------------------------------------------------- sending and saving
    fun send(ctx: Context, sf: ShareFile) {
        try {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", sf.file)
            val i = Intent(Intent.ACTION_SEND)
            i.type = sf.mime
            i.putExtra(Intent.EXTRA_STREAM, uri)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val ch = Intent.createChooser(i, "Share your run")
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(ch)
        } catch (e: Exception) {
            Toast.makeText(ctx, "Couldn't open sharing", Toast.LENGTH_SHORT).show()
        }
    }

    fun save(ctx: Context, sf: ShareFile) {
        try {
            val image = sf.mime.startsWith("image")
            val v = ContentValues()
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, sf.file.name)
            v.put(MediaStore.MediaColumns.MIME_TYPE, sf.mime)
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, (if (image) Environment.DIRECTORY_PICTURES else Environment.DIRECTORY_MOVIES) + "/WaveStride")
            val coll = if (image) MediaStore.Images.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val uri = ctx.contentResolver.insert(coll, v)
            if (uri == null) { Toast.makeText(ctx, "Couldn't save", Toast.LENGTH_SHORT).show(); return }
            ctx.contentResolver.openOutputStream(uri)?.use { o -> sf.file.inputStream().use { it.copyTo(o) } }
            Toast.makeText(ctx, "Saved in " + (if (image) "Pictures" else "Movies") + "/WaveStride", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, "Couldn't save", Toast.LENGTH_SHORT).show()
        }
    }
}
