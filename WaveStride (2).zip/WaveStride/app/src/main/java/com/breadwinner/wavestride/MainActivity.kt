package com.breadwinner.wavestride

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

sealed class Dest {
    object Home : Dest()
    object Move : Dest()
    object You : Dest()
    object More : Dest()
    object Record : Dest()
    object Maps : Dest()
    class Detail(val id: Long, val fresh: Boolean = false) : Dest()
}

class MainActivity : ComponentActivity() {
    private var startReq by mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        App.init(this)
        enableEdgeToEdge()
        StepsAlarm.schedule()
        StepService.start(this)
        // if the app was killed in the middle of a run, keep what was recorded
        val recovered = if (RunState.flow.value.st == St.IDLE && RunState.flow.value.countdown == 0) Runs.recoverLive() else 0L
        handleIntent(intent)
        setContent { WaveStrideApp(recovered, startReq) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == "com.breadwinner.wavestride.START_RUN") {
            startReq++
            i?.setAction(null)
        }
    }
}

@Composable
fun WaveStrideApp(recoveredId: Long, startReq: Int) {
    val ctx = LocalContext.current
    var dest by remember { mutableStateOf<Dest>(if (recoveredId != 0L) Dest.Detail(recoveredId, true) else Dest.Home) }
    val stack = remember { mutableStateListOf<Dest>() }
    var autoStart by remember { mutableStateOf(false) }
    var intro by remember { mutableStateOf(!Prefs.b("asked", false)) }

    fun go(d: Dest) { stack.add(dest); dest = d }
    fun tab(d: Dest) { stack.clear(); dest = d }
    fun back() { if (stack.isNotEmpty()) dest = stack.removeAt(stack.size - 1) else dest = Dest.Home }

    val perms = remember {
        val l = ArrayList<String>()
        l.add(Manifest.permission.ACCESS_FINE_LOCATION)
        l.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        l.add(Manifest.permission.ACTIVITY_RECOGNITION)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        l
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        Gps.retry()
        StepService.start(ctx)
        Steps.snapshot { Widgets.updateAll() }
    }

    LaunchedEffect(Unit) { Steps.snapshot { Widgets.updateAll() } }

    LaunchedEffect(startReq) {
        if (startReq > 0) { autoStart = true; tab(Dest.Record) }
    }

    val saved by RunState.saved.collectAsState()
    LaunchedEffect(saved) {
        if (saved != 0L) {
            val id = saved
            RunState.saved.value = 0L
            stack.clear()
            dest = Dest.Detail(id, true)
        }
    }

    BackHandler(enabled = dest !is Dest.Home || stack.isNotEmpty()) { back() }

    val pal = Themes.cur
    val view = androidx.compose.ui.platform.LocalView.current
    androidx.compose.runtime.SideEffect {
        try {
            val w = (view.context as android.app.Activity).window
            androidx.core.view.WindowCompat.getInsetsController(w, view).apply { isAppearanceLightStatusBars = !pal.dark; isAppearanceLightNavigationBars = !pal.dark }
        } catch (e: Exception) { }
    }
    MaterialTheme(
        colorScheme = if (pal.dark) darkColorScheme(primary = C.accent, background = C.bg, surface = C.card, onSurface = C.text, onBackground = C.text)
        else lightColorScheme(primary = C.accent, background = C.bg, surface = C.card, onSurface = C.text, onBackground = C.text)
    ) {
        Column(Modifier.fillMaxSize().background(C.bg).statusBarsPadding()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (val d = dest) {
                    is Dest.Home -> HomeScreen(
                        onRecord = { tab(Dest.Record) },
                        onOpen = { id -> go(Dest.Detail(id)) },
                        onMove = { tab(Dest.Move) },
                        onMaps = { go(Dest.Maps) }
                    )
                    is Dest.Move -> MoveScreen()
                    is Dest.You -> YouScreen(onOpen = { id -> go(Dest.Detail(id)) })
                    is Dest.More -> MoreScreen(onMaps = { go(Dest.Maps) })
                    is Dest.Record -> RecordScreen(autoStart = autoStart, onAutoDone = { autoStart = false }, onClose = { tab(Dest.Home) })
                    is Dest.Maps -> MapsScreen(onBack = { back() })
                    is Dest.Detail -> DetailScreen(d.id, d.fresh, onBack = { back() }, onDeleted = { tab(Dest.Home) })
                }
            }
            val showBar = dest is Dest.Home || dest is Dest.Move || dest is Dest.You || dest is Dest.More
            if (showBar) BottomBar(dest, onTab = { tab(it) }, onRecord = { tab(Dest.Record) })
        }

        if (intro) {
            AlertDialog(
                onDismissRequest = {},
                confirmButton = {
                    TextButton(onClick = {
                        intro = false
                        Prefs.put("asked", true)
                        launcher.launch(perms.toTypedArray())
                    }) { Text("Continue", color = C.accent) }
                },
                title = { Text("Welcome to WaveStride", color = C.text) },
                text = {
                    Text(
                        "Your own run tracker. Everything stays on your phone.\n\n" +
                            "Next, Android will ask for:\n" +
                            "• Location, to record your route\n" +
                            "• Physical activity, to count your steps\n" +
                            "• Notifications, to show the run while the screen is off",
                        color = C.text
                    )
                },
                containerColor = C.card
            )
        }
    }
}

@Composable
private fun BottomBar(dest: Dest, onTab: (Dest) -> Unit, onRecord: () -> Unit) {
    val live by RunState.flow.collectAsState()
    Row(
        Modifier.fillMaxWidth().background(C.card).navigationBarsPadding().padding(horizontal = 6.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
    ) {
        BarItem("Home", Icons.Filled.Home, dest is Dest.Home, Modifier.weight(1f)) { onTab(Dest.Home) }
        BarItem("Movement", Icons.Filled.DirectionsWalk, dest is Dest.Move, Modifier.weight(1f)) { onTab(Dest.Move) }
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(58.dp).clip(CircleShape).background(C.go).clickable { onRecord() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.DirectionsRun, null, tint = C.onAccent, modifier = Modifier.size(30.dp)) }
            if (live.st != St.IDLE) {
                Box(Modifier.align(Alignment.TopEnd).padding(end = 10.dp).size(12.dp).clip(CircleShape).background(C.green))
            }
        }
        BarItem("You", Icons.Filled.BarChart, dest is Dest.You, Modifier.weight(1f)) { onTab(Dest.You) }
        BarItem("More", Icons.Filled.Settings, dest is Dest.More, Modifier.weight(1f)) { onTab(Dest.More) }
    }
}

@Composable
private fun BarItem(label: String, icon: ImageVector, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clip(androidx.compose.foundation.shape.RoundedCornerShape(12.dp)).clickable { onClick() }.padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (on) C.text else C.steel, modifier = Modifier.size(24.dp))
        T(label, 11, if (on) C.text else C.steel, if (on) FontWeight.Bold else FontWeight.Medium)
    }
}

fun permGranted(p: String): Boolean = ContextCompat.checkSelfPermission(App.ctx, p) == PackageManager.PERMISSION_GRANTED
