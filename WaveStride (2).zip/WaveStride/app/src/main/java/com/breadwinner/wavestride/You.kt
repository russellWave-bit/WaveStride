package com.breadwinner.wavestride

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Terrain
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable
fun YouScreen(onOpen: (Long) -> Unit) {
    var tab by remember { mutableStateOf(0) }
    val runs = remember { Runs.list() }
    Column(Modifier.fillMaxSize()) {
        Header("You", null)
        Segmented(listOf("Progress", "Records", "Tiers", "Goals"), tab) { tab = it }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            when (tab) {
                0 -> ProgressTab(runs)
                1 -> RecordsTab(runs, onOpen)
                2 -> TiersTab(runs)
                else -> GoalsTab(runs)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun Totals(label: String, l: List<Summary>) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        T(label, 11, C.steel, FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth()) {
            Stat(Fmt.f1(Stats.km(l)), "km", Modifier.weight(1f))
            Stat(l.size.toString(), if (l.size == 1) "run" else "runs", Modifier.weight(1f))
            Stat(Fmt.dur(l.sumOf { it.durMs }), "time", Modifier.weight(1f))
            Stat(l.sumOf { it.gainM }.toInt().toString(), "m climb", Modifier.weight(1f))
        }
    }
}

@Composable
private fun ProgressTab(runs: List<Summary>) {
    if (runs.isEmpty()) { Empty("Your totals show up here after your first run."); return }
    val now = System.currentTimeMillis()
    Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
        Totals("THIS WEEK", Stats.inRange(runs, Stats.weekStart(now), Long.MAX_VALUE))
        Rule()
        Totals("THIS MONTH", Stats.inRange(runs, Stats.monthStart(now), Long.MAX_VALUE))
        Rule()
        Totals("THIS YEAR", Stats.inRange(runs, Stats.yearStart(now), Long.MAX_VALUE))
        Rule()
        Totals("ALL TIME", runs)
    }
    Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
        T("DISTANCE PER WEEK · km", 11, C.steel, FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        val per = Stats.perWeek(runs, 8)
        val ws = Stats.weekStart(now)
        val labels = (0 until 8).map { i -> Fmt.dayMonth(Stats.addDays(ws, -7 * (7 - i))).replace(" ", "\n") }
        Bars(per.map { it.toFloat() }, labels, 7, height = 110.dp)
    }
}

@Composable
private fun RecordRow(title: String, sub: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: (() -> Unit)?) {
    SettingRow(icon, title, sub, onClick = onClick) { T(value, 16, C.text, FontWeight.Bold) }
}

@Composable
private fun RecordsTab(runs: List<Summary>, onOpen: (Long) -> Unit) {
    if (runs.isEmpty()) { Empty("Your personal records show up here after your first run."); return }
    Shelf("Fastest efforts", Icons.Filled.Timer) {
        var first = true
        for ((d, label) in EFFORTS) {
            val best = runs.filter { it.best.containsKey(d) }.minByOrNull { it.best[d] ?: Long.MAX_VALUE }
            if (!first) Rule()
            first = false
            if (best == null) RecordRow(label, "Not yet. Run $label or more to set one.", "–", Icons.Filled.EmojiEvents, null)
            else RecordRow(label, Fmt.date(best.start), Fmt.dur(best.best[d] ?: 0L), Icons.Filled.EmojiEvents) { onOpen(best.id) }
        }
    }
    Shelf("Biggest", Icons.Filled.Flag) {
        val longest = runs.maxByOrNull { it.distM }
        val climb = runs.maxByOrNull { it.gainM }
        val speed = runs.filter { it.distM >= 1000.0 }.minByOrNull { Fmt.paceOf(it.distM, it.durMs) }
        if (longest != null) RecordRow("Longest run", Fmt.date(longest.start), Fmt.km(longest.distM) + " km", Icons.Filled.Flag) { onOpen(longest.id) }
        if (speed != null) { Rule(); RecordRow("Fastest average pace", Fmt.date(speed.start), Fmt.pace(Fmt.paceOf(speed.distM, speed.durMs)) + " /km", Icons.Filled.Speed) { onOpen(speed.id) } }
        if (climb != null && climb.gainM > 0) { Rule(); RecordRow("Most climbing", Fmt.date(climb.start), climb.gainM.toInt().toString() + " m", Icons.Filled.Terrain) { onOpen(climb.id) } }
    }
}

@Composable
private fun TiersTab(runs: List<Summary>) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        T("Your own ladder", 16, C.text, FontWeight.Bold, Modifier.weight(1f))
        InfoDot("There are no leaderboards here. For each distance, your first effort is your starting line (Bronze). Each tier up means beating that first time by a bit more: Silver 3% faster, Gold 7%, Platinum 12%, Diamond 20%. You are only racing yourself.")
    }
    for ((d, label) in EFFORTS) {
        val lv = Tiers.level(runs, d)
        val pb = Tiers.pb(runs, d)
        val base = Tiers.baseline(runs, d)
        Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (lv >= 0) Medal(Color(Tiers.all[lv].color), 52.dp)
                else Box(Modifier.size(52.dp).clip(CircleShape).background(C.card2))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    T(label, 17, C.text, FontWeight.Bold)
                    if (lv >= 0) T(Tiers.all[lv].name + " · best " + Fmt.dur(pb), 13, C.steelLt)
                    else T("Run " + label + " to start this ladder", 13, C.steel)
                }
            }
            if (lv >= 0) {
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Tiers.all.forEachIndexed { i, t ->
                        Box(
                            Modifier.size(26.dp).clip(CircleShape).background(if (i <= lv) Color(t.color) else C.card2),
                            contentAlignment = Alignment.Center
                        ) { T((i + 1).toString(), 11, if (i <= lv) Color(0xCC000000) else C.steel, FontWeight.Bold) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                val next = Tiers.target(runs, d, lv)
                if (next > 0) {
                    T(Tiers.all[lv + 1].name + " needs " + Fmt.dur(next) + " (" + Fmt.dur((pb - next).coerceAtLeast(0)) + " faster than now)", 12, C.steel)
                } else T("Top tier reached. Start line was " + Fmt.dur(base) + ".", 12, C.steel)
            }
        }
    }
}

@Composable
private fun GoalsTab(runs: List<Summary>) {
    var goals by remember { mutableStateOf(Goals.load()) }
    var add by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        T("Your goals", 16, C.text, FontWeight.Bold, Modifier.weight(1f))
        PrimaryButton("Add goal", Modifier, Icons.Filled.Add) { add = true }
    }
    if (goals.isEmpty()) Empty("No goals yet. Try \"run 20 km this month\".")
    for (g in goals) {
        val p = Goals.progress(g, runs)
        val frac = (p / g.target).toFloat().coerceIn(0f, 1f)
        val unit = if (g.type == "km") "km" else if (g.target == 1.0) "run" else "runs"
        val per = if (g.period == "week") "this week" else "this month"
        Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T((if (g.type == "km") "Run " else "Do ") + trimNum(g.target) + " " + unit + " " + per, 15, C.text, FontWeight.Bold)
                    T(trimNum(p) + " of " + trimNum(g.target) + " " + unit + if (frac >= 1f) "  ·  Done" else "", 12, if (frac >= 1f) C.green else C.steel)
                }
                Box(Modifier.size(36.dp).clip(CircleShape).clickable { goals = goals.filter { it.id != g.id }; Goals.save(goals) }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Delete, null, tint = C.steel)
                }
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp)).background(C.card2)) {
                Box(Modifier.fillMaxWidth(frac).height(14.dp).clip(RoundedCornerShape(7.dp)).background(if (frac >= 1f) C.green else C.accent))
            }
        }
    }
    if (add) {
        var type by remember { mutableStateOf(0) }
        var period by remember { mutableStateOf(1) }
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { add = false },
            confirmButton = {
                TextButton(onClick = {
                    val v = text.replace(',', '.').toDoubleOrNull()
                    if (v != null && v > 0) {
                        goals = goals + Goal(System.currentTimeMillis(), if (type == 0) "km" else "runs", if (period == 0) "week" else "month", v)
                        Goals.save(goals)
                        add = false
                    }
                }) { Text("Save goal", color = C.accent) }
            },
            dismissButton = { TextButton(onClick = { add = false }) { Text("Cancel", color = C.steelLt) } },
            title = { Text("New goal", color = C.text) },
            text = {
                Column {
                    Chips(listOf("Distance (km)", "Number of runs"), type, { type = it })
                    Chips(listOf("Each week", "Each month"), period, { period = it })
                    OutlinedTextField(
                        value = text, onValueChange = { text = it }, singleLine = true,
                        label = { Text(if (type == 0) "How many km?" else "How many runs?") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )
                }
            },
            containerColor = C.card
        )
    }
}

private fun trimNum(x: Double): String = if (x == Math.floor(x)) x.toInt().toString() else Fmt.f1(x)
