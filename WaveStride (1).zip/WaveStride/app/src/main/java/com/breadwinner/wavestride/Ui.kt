package com.breadwinner.wavestride

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** One look: colours for a theme. */
class Palette(
    val dark: Boolean, val bg: Color, val card: Color, val card2: Color, val line: Color, val steel: Color, val steelLt: Color,
    val text: Color, val accent: Color, val go: Color, val onAccent: Color, val green: Color, val red: Color, val ring: List<Color>
)

object Themes {
    val DARK = Palette(
        true, Color(0xFF0B0D0F), Color(0xFF161A1E), Color(0xFF1E242A), Color(0xFF2A3138), Color(0xFF8A95A0), Color(0xFFC3CBD2),
        Color(0xFFEDF0F2), Color(0xFFFC4C02), Color(0xFFFC4C02), Color.White, Color(0xFF3DAA5C), Color(0xFFE5484D),
        listOf(Color(0xFFFC4C02), Color(0xFFFF7A3D))
    )
    val LIGHT = Palette(
        false, Color(0xFFF3F8F1), Color(0xFFFFFFFF), Color(0xFFE4F0E2), Color(0xFFCFE0CC), Color(0xFF5F7566), Color(0xFF34503F),
        Color(0xFF12201A), Color(0xFF2E9E57), Color(0xFFFC4C02), Color.White, Color(0xFF2E9E57), Color(0xFFE5484D),
        listOf(Color(0xFFB8E6C1), Color(0xFF6CCB8A), Color(0xFF2E9E57))
    )
    val NEON = Palette(
        true, Color(0xFF050505), Color(0xFF101010), Color(0xFF191919), Color(0xFF2C2C2C), Color(0xFF8C8C8C), Color(0xFFD0D0D0),
        Color(0xFFF5F5F5), Color(0xFFC6FF1A), Color(0xFFC6FF1A), Color(0xFF0A0A0A), Color(0xFF39FF88), Color(0xFFFF3D6E),
        listOf(Color(0xFF18E0FF), Color(0xFF39FF88), Color(0xFFC6FF1A))
    )
    var mode by mutableStateOf(Prefs.i("theme", 0))
    val cur: Palette get() = when (mode) { 1 -> LIGHT; 2 -> NEON; else -> DARK }
    fun set(m: Int) { mode = m; Prefs.put("theme", m); Widgets.updateAll() }
}

/** Colours the screens use. They follow the chosen theme. */
object C {
    val bg get() = Themes.cur.bg
    val card get() = Themes.cur.card
    val card2 get() = Themes.cur.card2
    val line get() = Themes.cur.line
    val steel get() = Themes.cur.steel
    val steelLt get() = Themes.cur.steelLt
    val text get() = Themes.cur.text
    val accent get() = Themes.cur.accent
    val go get() = Themes.cur.go
    val onAccent get() = Themes.cur.onAccent
    val green get() = Themes.cur.green
    val red get() = Themes.cur.red
    val ring get() = Themes.cur.ring
    val route = Color(0xFFFC4C02)   // the route line is always plain orange
    val blue = Color(0xFF4285F4)
}

private fun bolder(w: FontWeight): FontWeight = when (w) { FontWeight.Normal -> FontWeight.Medium; FontWeight.Medium -> FontWeight.SemiBold; FontWeight.SemiBold -> FontWeight.Bold; FontWeight.Bold -> FontWeight.ExtraBold; else -> w }

@Composable
fun T(
    text: String,
    size: Int = 14,
    color: Color = C.text,
    weight: FontWeight = FontWeight.Normal,
    modifier: Modifier = Modifier,
    align: TextAlign? = null
) {
    Text(text, modifier = modifier, color = color, fontSize = size.sp, fontWeight = bolder(weight), textAlign = align, lineHeight = (size + 5).sp)
}

@Composable
fun InfoDot(text: String) {
    var open by remember { mutableStateOf(false) }
    Box(
        Modifier.size(20.dp).clip(CircleShape).background(C.card2).border(1.dp, C.line, CircleShape).clickable { open = true },
        contentAlignment = Alignment.Center
    ) { T("i", 12, C.steelLt, FontWeight.Bold) }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            confirmButton = { TextButton(onClick = { open = false }) { Text("Got it", color = C.accent) } },
            text = { Text(text, color = C.text) },
            containerColor = C.card
        )
    }
}

@Composable
fun Header(title: String, onBack: (() -> Unit)?, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            Box(Modifier.size(40.dp).clip(CircleShape).clickable { onBack() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.ArrowBack, null, tint = C.text)
            }
            Spacer(Modifier.width(6.dp))
        } else Spacer(Modifier.width(6.dp))
        T(title, 22, C.text, FontWeight.Bold, Modifier.weight(1f))
        trailing()
    }
}

@Composable
fun Card(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val m = modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(C.card).border(2.dp, C.line, RoundedCornerShape(20.dp))
    Column(if (onClick != null) m.clickable { onClick() }.padding(14.dp) else m.padding(14.dp), content = content)
}

/** A labelled shelf with an icon: settings are grouped like this everywhere. */
@Composable
fun Shelf(title: String, icon: ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp)) {
        Row(Modifier.padding(start = 4.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = C.steel, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            T(title.uppercase(), 12, C.steel, FontWeight.Bold)
        }
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(C.card).border(2.dp, C.line, RoundedCornerShape(20.dp)),
            content = content
        )
    }
}

@Composable
fun Rule() { Box(Modifier.fillMaxWidth().height(1.dp).background(C.line)) }

@Composable
fun SettingRow(
    icon: ImageVector,
    title: String,
    sub: String? = null,
    info: String? = null,
    chevron: Boolean = false,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit = {}
) {
    Row(
        Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable { onClick() } else Modifier).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(C.card2), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = C.steelLt, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            T(title, 15, C.text, FontWeight.Medium)
            if (sub != null) T(sub, 12, C.steel)
        }
        if (info != null) { Spacer(Modifier.width(8.dp)); InfoDot(info) }
        trailing()
        if (chevron) Icon(Icons.Filled.ChevronRight, null, tint = C.steel)
    }
}

@Composable
fun SwitchRow(icon: ImageVector, title: String, sub: String? = null, info: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    SettingRow(icon, title, sub, info, onClick = { onChange(!checked) }) {
        Spacer(Modifier.width(8.dp))
        Switch(
            checked = checked, onCheckedChange = { onChange(it) },
            colors = SwitchDefaults.colors(checkedThumbColor = C.onAccent, checkedTrackColor = C.accent, uncheckedThumbColor = C.steelLt, uncheckedTrackColor = C.card2, uncheckedBorderColor = C.line)
        )
    }
}

@Composable
fun Chips(options: List<String>, sel: Int, onSel: (Int) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, o ->
            val on = i == sel
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(if (on) C.accent else C.card2)
                    .border(1.dp, if (on) C.accent else C.line, RoundedCornerShape(10.dp)).clickable { onSel(i) }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) { T(o, 13, if (on) C.onAccent else C.steelLt, FontWeight.Medium, align = TextAlign.Center) }
        }
    }
}

@Composable
fun Segmented(options: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp).clip(RoundedCornerShape(12.dp)).background(C.card).border(1.dp, C.line, RoundedCornerShape(12.dp)).padding(3.dp)
    ) {
        options.forEachIndexed { i, o ->
            val on = i == sel
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(9.dp)).background(if (on) C.card2 else Color.Transparent).clickable { onSel(i) }.padding(vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) { T(o, 13, if (on) C.text else C.steel, if (on) FontWeight.Bold else FontWeight.Medium) }
        }
    }
}

@Composable
fun PrimaryButton(text: String, modifier: Modifier = Modifier, icon: ImageVector? = null, color: Color = C.accent, onClick: () -> Unit) {
    Row(
        modifier.clip(RoundedCornerShape(14.dp)).background(color).clickable { onClick() }.padding(horizontal = 18.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) { Icon(icon, null, tint = C.onAccent, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        T(text, 15, C.onAccent, FontWeight.Bold)
    }
}

@Composable
fun GhostButton(text: String, modifier: Modifier = Modifier, icon: ImageVector? = null, onClick: () -> Unit) {
    Row(
        modifier.clip(RoundedCornerShape(14.dp)).background(C.card2).border(1.dp, C.line, RoundedCornerShape(14.dp)).clickable { onClick() }.padding(horizontal = 16.dp, vertical = 13.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) { Icon(icon, null, tint = C.steelLt, modifier = Modifier.size(19.dp)); Spacer(Modifier.width(8.dp)) }
        T(text, 14, C.text, FontWeight.Medium)
    }
}

@Composable
fun Stat(value: String, label: String, modifier: Modifier = Modifier, big: Boolean = false) {
    Column(modifier) {
        T(value, if (big) 30 else 20, C.text, FontWeight.Bold)
        T(label, 12, C.steel)
    }
}

/** A progress ring: thick and crisp, no glow. In the green and neon themes it shades along its length. */
@Composable
fun Ring(progress: Float, size: Dp, stroke: Dp, color: Color? = null, content: @Composable () -> Unit = {}) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        val shades = if (color == null) C.ring else listOf(color, color)
        val track = C.card2
        Canvas(Modifier.fillMaxSize()) {
            val sw = stroke.toPx() * 1.45f
            val inset = sw / 2
            val s = Size(this.size.width - sw, this.size.height - sw)
            drawArc(track, -90f, 360f, false, Offset(inset, inset), s, style = Stroke(sw))
            val sweep = 360f * progress.coerceIn(0f, 1f)
            if (sweep > 0f) {
                val cols = if (shades.size >= 2) shades else listOf(shades[0], shades[0])
                val brush = Brush.sweepGradient(cols + cols.last(), center)
                rotate(-90f, center) { drawArc(brush, 0f, sweep, false, Offset(inset, inset), s, style = Stroke(sw, cap = StrokeCap.Round)) }
            }
        }
        content()
    }
}

/** Simple bar chart. [hi] is the bar drawn in orange. */
@Composable
fun Bars(values: List<Float>, labels: List<String>, hi: Int, modifier: Modifier = Modifier, height: Dp = 110.dp) {
    val mx = (values.maxOrNull() ?: 0f).coerceAtLeast(0.0001f)
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.Bottom) {
        values.forEachIndexed { i, v ->
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.height(height), contentAlignment = Alignment.BottomCenter) {
                    Box(
                        Modifier.fillMaxWidth().height((height.value * (v / mx)).coerceAtLeast(3f).dp)
                            .clip(RoundedCornerShape(topStart = 9.dp, topEnd = 9.dp)).background(if (i == hi) C.accent else C.steel)
                    )
                }
                Spacer(Modifier.height(4.dp))
                T(labels.getOrElse(i) { "" }, 10, if (i == hi) C.text else C.steel, align = TextAlign.Center)
            }
        }
    }
}

/** The health bar: a thick bar that fills and changes colour, red then gold then green. */
@Composable
fun HealthBar(score: Float, modifier: Modifier = Modifier, height: Dp = 26.dp) {
    val sc = score.coerceIn(0f, 1f)
    val col = if (sc < 0.34f) C.red else if (sc < 0.67f) Color(0xFFF2B01E) else C.green
    Box(modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(height / 2)).background(C.card2).border(2.dp, C.line, RoundedCornerShape(height / 2))) {
        if (sc > 0.01f) Box(Modifier.fillMaxWidth(sc).height(height).clip(RoundedCornerShape(height / 2)).background(col))
    }
}

@Composable
fun Medal(color: Color, size: Dp = 44.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(color).border(3.dp, Color(0x55000000), CircleShape), contentAlignment = Alignment.Center) {
        Icon(Icons.Filled.Star, null, tint = Color(0xCC000000), modifier = Modifier.size(size * 0.5f))
    }
}

@Composable
fun Empty(text: String) {
    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
        T(text, 14, C.steel, align = TextAlign.Center)
    }
}
