package com.breadwinner.wavestride

import android.Manifest
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.Map
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import java.util.Calendar

@Composable
fun HomeScreen(onRecord: () -> Unit, onOpen: (Long) -> Unit, onMove: () -> Unit, onMaps: () -> Unit) {
    val runs = remember { Runs.list() }
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { Steps.snapshot { tick++ } }
    val today = remember(tick) { Steps.today() }
    val live by RunState.flow.collectAsState()
    val haveMaps = remember { Tiles.sizeBytes() > 0L }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { Header("WaveStride", null) }
        item { MoveStrip(today, onMove) }
        if (live.st != St.IDLE || live.countdown > 0) {
            item {
                Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp), onClick = onRecord) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(C.green))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            T(if (live.st == St.PAUSED) "Run paused" else "Run in progress", 15, C.text, FontWeight.Bold)
                            T(Fmt.km(live.distM) + " km · " + Fmt.dur(live.ms), 13, C.steel)
                        }
                        Icon(Icons.Filled.ChevronRight, null, tint = C.steel)
                    }
                }
            }
        }
        if (!haveMaps) {
            item {
                Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp), onClick = onMaps) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Map, null, tint = C.steelLt)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            T("Get your offline map", 15, C.text, FontWeight.Bold)
                            T("Download " + Areas.current().name + " once over Wi-Fi. After that maps cost no data.", 12, C.steel)
                        }
                        Icon(Icons.Filled.ChevronRight, null, tint = C.steel)
                    }
                }
            }
        }
        if (runs.isEmpty()) {
            item { FirstRun(onRecord) }
        } else {
            item { WeekCard(runs) }
            item { T("Recent runs", 16, C.text, FontWeight.Bold, Modifier.padding(start = 18.dp, top = 12.dp, bottom = 4.dp)) }
            items(runs.take(40)) { s -> RunCard(s) { onOpen(s.id) } }
        }
    }
}

@Composable
private fun MoveStrip(today: Day, onMove: () -> Unit) {
    val ok = permGranted(Manifest.permission.ACTIVITY_RECOGNITION)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(C.card)
            .border(2.dp, C.line, RoundedCornerShape(14.dp)).clickable { onMove() }.padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.DirectionsWalk, null, tint = C.steelLt, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        if (ok) {
            T(String.format(java.util.Locale.US, "%,d", today.steps) + " steps  ·  " + Cal.forDay(today, Runs.list()) + " kcal", 14, C.text, FontWeight.Medium, Modifier.weight(1f))
        } else {
            T("Tap to allow step counting", 14, C.text, FontWeight.Medium, Modifier.weight(1f))
        }
        Icon(Icons.Filled.ChevronRight, null, tint = C.steel, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun FirstRun(onRecord: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(150.dp).clip(CircleShape).background(C.go).clickable { onRecord() },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.DirectionsRun, null, tint = C.onAccent, modifier = Modifier.size(54.dp))
                T("START RUN", 15, C.onAccent, FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(22.dp))
        T("Your first run starts here", 20, C.text, FontWeight.Bold, align = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        T("WaveStride records your route, pace and distance. No account, no sign-up. Runs stay on your phone.", 14, C.steel, align = TextAlign.Center)
    }
}

@Composable
private fun WeekCard(runs: List<Summary>) {
    val now = System.currentTimeMillis()
    val ws = Stats.weekStart(now)
    val per = Stats.perDay(runs, ws, 7)
    val idx = (Calendar.getInstance().get(Calendar.DAY_OF_WEEK) + 5) % 7
    val tot = per.sum()
    val count = Stats.inRange(runs, ws, Long.MAX_VALUE).size
    Card(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
        T("THIS WEEK", 11, C.steel, FontWeight.Bold)
        Row(verticalAlignment = Alignment.Bottom) {
            T(Fmt.f1(tot), 30, C.text, FontWeight.Bold)
            T("  km  ·  $count run" + if (count == 1) "" else "s", 14, C.steel, modifier = Modifier.padding(bottom = 5.dp))
        }
        Spacer(Modifier.height(10.dp))
        Bars(per.map { it.toFloat() }, listOf("M", "T", "W", "T", "F", "S", "S"), idx, height = 70.dp)
    }
}

@Composable
fun RunCard(s: Summary, onClick: () -> Unit) {
    Card(Modifier.padding(horizontal = 14.dp, vertical = 5.dp), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RoutePreview(s.mini, Modifier.size(96.dp).clip(RoundedCornerShape(12.dp)))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                T(s.title, 16, C.text, FontWeight.Bold)
                T(Fmt.date(s.start), 12, C.steel)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column { T(Fmt.km(s.distM), 17, C.text, FontWeight.Bold); T("km", 11, C.steel) }
                    Column { T(Fmt.pace(Fmt.paceOf(s.distM, s.durMs)), 17, C.text, FontWeight.Bold); T("/km", 11, C.steel) }
                    Column { T(Fmt.dur(s.durMs), 17, C.text, FontWeight.Bold); T("time", 11, C.steel) }
                }
            }
        }
    }
}
